import SwiftUI
import Combine

/// Which backend generates the ad images. OpenAI is the default; Nano Banana (Google Gemini
/// 2.5 Flash Image) preserves a product's exact shape/pattern better and is cheaper per image.
enum ImageBackend: String, CaseIterable {
    case openAI
    case nanoBanana
    var label: String { self == .openAI ? "OpenAI (gpt-image-1)" : "Nano Banana (Gemini)" }
    var short: String { self == .openAI ? "OpenAI" : "Nano Banana" }
}

/// User-tunable settings (Settings sheet). Keys live in Keychain; everything else in UserDefaults.
@MainActor
final class AppSettings: ObservableObject {
    @AppStorage("concurrency") var concurrency: Int = 4
    @AppStorage("gptModel") var gptModel: String = "gpt-5.4"
    @AppStorage("contentLanguage") var contentLanguage: String = "English"
    @AppStorage("autoRetry") var autoRetry: Bool = true
    @AppStorage("defaultFont") var defaultFont: String = "SF Pro Display"

    /// Persistent cross-campaign learnings/rules the user accumulates after running real ads.
    /// Injected into every content-generation prompt so the AI honors them on every project.
    @AppStorage("adLearnings") var adLearnings: String = ""
    @AppStorage("defaultRatio") private var defaultRatioRaw: String = AdRatio.r45.rawValue

    // New-project defaults — seeded into the New Project form every time it opens.
    @AppStorage("defaultGoal") var defaultGoal: String = "Sales"           // "Sales" | "Leads"
    @AppStorage("defaultPersonas") var defaultPersonas: Int = 3            // N, 1–6
    @AppStorage("defaultCreatives") var defaultCreatives: Int = 5          // M, 3–10
    @AppStorage("defaultHookStyle") private var defaultHookStyleRaw: String = HookStyle.normal1.rawValue

    /// Visual preset auto-seeded onto every new creative's on-image hook text.
    /// Read by `TextLayer.seed` straight from UserDefaults (same backing store).
    var defaultHookStyle: HookStyle {
        get { HookStyle(rawValue: defaultHookStyleRaw) ?? .normal1 }
        set { defaultHookStyleRaw = newValue.rawValue }
    }
    @AppStorage("exportBookmark") private var exportBookmarkData: Data = Data()
    @AppStorage("imageBackend") private var imageBackendRaw: String = ImageBackend.openAI.rawValue

    /// Which backend generates images (OpenAI vs Nano Banana).
    var imageBackend: ImageBackend {
        get { ImageBackend(rawValue: imageBackendRaw) ?? .openAI }
        set { imageBackendRaw = newValue.rawValue; objectWillChange.send() }
    }

    /// Aspect ratio seeded into every creative of a newly generated project / persona.
    var defaultRatio: AdRatio {
        get { AdRatio(rawValue: defaultRatioRaw) ?? .r45 }
        set { defaultRatioRaw = newValue.rawValue }
    }

    // The single OpenAI key (used for both GPT strategy and gpt-image generation).
    // Surfaced through a @Published mirror so the UI can observe changes.
    @Published var openaiKey: String = Keychain.get(Keychain.Account.openai) ?? ""

    // Google Gemini key — only used when the image backend is Nano Banana.
    @Published var geminiKey: String = Keychain.get(Keychain.Account.gemini) ?? ""

    static let modelOptions = ["gpt-5.5", "gpt-5.4", "gpt-5.4-mini", "gpt-4o", "gpt-4.1", "gpt-4o-mini", "gpt-4.1-mini"]
    static let languageOptions = ["English", "Vietnamese"]
    static let fontOptions = ["Inter", "Montserrat", "Be Vietnam Pro", "Playfair Display", "SF Pro Display", "SF Pro Text", "New York", "Helvetica Neue", "Georgia"]

    /// The key actually used for API calls: a hardcoded `Secrets.openAIKey` wins if set,
    /// otherwise the key entered in Settings (Keychain).
    var effectiveOpenAIKey: String {
        let hardcoded = Secrets.openAIKey.trimmingCharacters(in: .whitespacesAndNewlines)
        return hardcoded.isEmpty ? openaiKey.trimmingCharacters(in: .whitespacesAndNewlines) : hardcoded
    }
    var hasOpenAIKey: Bool { !effectiveOpenAIKey.isEmpty }
    var keyIsHardcoded: Bool { !Secrets.openAIKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }

    func saveOpenAIKey(_ key: String) {
        openaiKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
        Keychain.set(openaiKey, for: Keychain.Account.openai)
    }

    var effectiveGeminiKey: String { geminiKey.trimmingCharacters(in: .whitespacesAndNewlines) }
    var hasGeminiKey: Bool { !effectiveGeminiKey.isEmpty }

    func saveGeminiKey(_ key: String) {
        geminiKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
        Keychain.set(geminiKey, for: Keychain.Account.gemini)
    }

    /// True when the selected image backend has the key it needs.
    var hasImageKey: Bool { imageBackend == .nanoBanana ? hasGeminiKey : hasOpenAIKey }

    /// Resolve the chosen export folder (security-scoped). Defaults to the Desktop when unset.
    func exportFolder() -> URL? {
        guard !exportBookmarkData.isEmpty else {
            return FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first
        }
        var stale = false
        guard let url = try? URL(resolvingBookmarkData: exportBookmarkData,
                                 options: .withSecurityScope, relativeTo: nil,
                                 bookmarkDataIsStale: &stale) else { return nil }
        return url
    }

    var exportFolderDisplay: String {
        exportFolder().map { $0.path(percentEncoded: false) } ?? "Choose a folder…"
    }

    func setExportFolder(_ url: URL) {
        if let data = try? url.bookmarkData(options: .withSecurityScope,
                                            includingResourceValuesForKeys: nil, relativeTo: nil) {
            exportBookmarkData = data
            // `@AppStorage` inside an ObservableObject does NOT fire objectWillChange, so without this
            // the Settings label keeps showing "Choose a folder…" after picking — looking like the
            // picker is broken. (Same manual-publish workaround as `imageBackend`.)
            objectWillChange.send()
        }
    }
}
