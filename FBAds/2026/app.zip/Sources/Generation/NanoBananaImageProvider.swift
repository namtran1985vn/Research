import Foundation
import AppKit

/// Nano Banana (Google Gemini 2.5 Flash Image) backend. It preserves a product's exact shape and
/// surface pattern far better than gpt-image-1 when re-staging it in a new scene, and is cheaper per
/// image. Uses the `generateContent` endpoint with the product photo(s) attached as inline image
/// parts, then normalises the returned image to the requested target size.
struct NanoBananaImageProvider: ImageProvider {
    let apiKey: String

    private let model = "gemini-2.5-flash-image"
    private var endpoint: URL {
        URL(string: "https://generativelanguage.googleapis.com/v1beta/models/\(model):generateContent")!
    }

    func generate(prompt: String, references: [Data], target: CGSize) async throws -> Data {
        guard !apiKey.isEmpty else { throw APIError.missingKey(provider: "Gemini") }

        // Anchor the real product with the fidelity lock only when we actually attach a photo.
        let text = references.isEmpty ? prompt : prompt + ImageFidelity.suffix
        var parts: [[String: Any]] = [["text": text]]
        for ref in references.prefix(4) {
            let png = NSImage(data: ref)?.pngData() ?? ref
            parts.append(["inlineData": ["mimeType": "image/png", "data": png.base64EncodedString()]])
        }

        let body: [String: Any] = [
            "contents": [["role": "user", "parts": parts]],
            "generationConfig": ["responseModalities": ["IMAGE"]],
        ]

        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.timeoutInterval = 240
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue(apiKey, forHTTPHeaderField: "x-goog-api-key")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response): (Data, URLResponse)
        do { (data, response) = try await URLSession.shared.data(for: req) }
        catch { throw APIError.network(error.localizedDescription) }
        guard let http = response as? HTTPURLResponse else { throw APIError.empty }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError.from(status: http.statusCode, provider: "Gemini", data: data)
        }

        guard let b64 = Self.firstInlineImage(in: data) else {
            throw APIError.decoding("Gemini returned no image")
        }
        guard let raw = Data(base64Encoded: b64) else { throw APIError.decoding("image not base64") }
        return ImageCrop.normalizeToTarget(raw, target: target) ?? raw
    }

    /// Pull the first inline image's base64 out of a `generateContent` response.
    private static func firstInlineImage(in data: Data) -> String? {
        guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let candidates = obj["candidates"] as? [[String: Any]] else { return nil }
        for cand in candidates {
            guard let content = cand["content"] as? [String: Any],
                  let parts = content["parts"] as? [[String: Any]] else { continue }
            for part in parts {
                if let inline = part["inlineData"] as? [String: Any],
                   let d = inline["data"] as? String, !d.isEmpty { return d }
            }
        }
        return nil
    }
}
