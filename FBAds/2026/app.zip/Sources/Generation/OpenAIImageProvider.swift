import Foundation
import AppKit

/// gpt-image-1 backend. Uses the images *edit* endpoint when product reference photos
/// are present (to keep the product accurate) and the *generations* endpoint otherwise.
struct OpenAIImageProvider: ImageProvider {
    let apiKey: String

    /// Nearest gpt-image-1 size for the requested target (square → 1024×1024, else portrait).
    private func requestedSize(for target: CGSize) -> String {
        target.width == target.height ? "1024x1024" : "1024x1536"
    }

    /// Appended to every edit prompt so the model reproduces the real product faithfully.
    private let fidelitySuffix = ImageFidelity.suffix

    func generate(prompt: String, references: [Data], target: CGSize) async throws -> Data {
        guard !apiKey.isEmpty else { throw APIError.missingKey(provider: "OpenAI") }
        let size = requestedSize(for: target)
        let b64: String
        if references.isEmpty {
            b64 = try await generateFromScratch(prompt: prompt, size: size)
        } else {
            b64 = try await edit(prompt: prompt, references: references, size: size)
        }
        guard let raw = Data(base64Encoded: b64) else { throw APIError.decoding("image not base64") }
        return ImageCrop.normalizeToTarget(raw, target: target) ?? raw
    }

    // MARK: edits (with reference photos)

    private func edit(prompt: String, references: [Data], size: String) async throws -> String {
        let url = URL(string: "https://api.openai.com/v1/images/edits")!
        let boundary = "Boundary-\(UUID().uuidString)"
        var body = Data()
        func field(_ name: String, _ value: String) {
            body.append("--\(boundary)\r\n")
            body.append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n")
            body.append("\(value)\r\n")
        }
        field("model", "gpt-image-1")
        field("prompt", prompt + fidelitySuffix)
        field("size", size)
        field("n", "1")
        // Preserve the input product as closely as possible (shape, pattern, logos) and render at
        // high quality — without input_fidelity:high gpt-image-1 reinterprets the product loosely.
        field("input_fidelity", "high")
        field("quality", "high")
        for (i, ref) in references.prefix(4).enumerated() {
            let png = NSImage(data: ref)?.pngData() ?? ref
            body.append("--\(boundary)\r\n")
            body.append("Content-Disposition: form-data; name=\"image[]\"; filename=\"ref\(i).png\"\r\n")
            body.append("Content-Type: image/png\r\n\r\n")
            body.append(png)
            body.append("\r\n")
        }
        body.append("--\(boundary)--\r\n")

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 240
        req.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        req.httpBody = body
        return try await send(req)
    }

    // MARK: generations (no reference)

    private func generateFromScratch(prompt: String, size: String) async throws -> String {
        let url = URL(string: "https://api.openai.com/v1/images/generations")!
        let payload: [String: Any] = ["model": "gpt-image-1", "prompt": prompt,
                                      "size": size, "n": 1]
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 240
        req.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: payload)
        return try await send(req)
    }

    private func send(_ req: URLRequest) async throws -> String {
        let (data, response): (Data, URLResponse)
        do { (data, response) = try await URLSession.shared.data(for: req) }
        catch { throw APIError.network(error.localizedDescription) }
        guard let http = response as? HTTPURLResponse else { throw APIError.empty }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError.from(status: http.statusCode, provider: "OpenAI", data: data)
        }
        guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let arr = obj["data"] as? [[String: Any]],
              let b64 = arr.first?["b64_json"] as? String else {
            throw APIError.decoding("missing b64_json")
        }
        return b64
    }
}

extension Data {
    mutating func append(_ string: String) {
        if let d = string.data(using: .utf8) { append(d) }
    }
}
