import SwiftUI
import AppKit
import CoreImage
import CoreImage.CIFilterBuiltins

/// High-quality, non-destructive image adjustments via Core Image.
///
/// Quality choices (deliberately NOT the generic CIColorControls.brightness):
/// • Brightness → `CIExposureAdjust` — exposure in LINEAR light (EV stops), the way a camera adjusts
///   exposure. Far more natural than an additive brightness, which just washes the image toward grey.
/// • Shadows    → `CIHighlightShadowAdjust` — purpose-built, radius-based tonal recovery that lifts
///   (or deepens) shadows while leaving highlights alone.
/// • Clarity    → large-radius `CIUnsharpMask` — midtone LOCAL contrast (the "clarity" technique),
///   not small-radius edge sharpening.
/// • Saturation → `CIVibrance` — protects already-saturated colors / skin tones and resists clipping,
///   instead of a flat multiply that blows out reds.
/// The whole chain runs in a LINEAR-sRGB working space (float precision) with sRGB output, which is
/// what makes exposure/contrast look correct and avoids banding.
enum ImageAdjust {
    private static let context: CIContext = {
        var opts: [CIContextOption: Any] = [.useSoftwareRenderer: false]
        if let lin = CGColorSpace(name: CGColorSpace.linearSRGB) { opts[.workingColorSpace] = lin }
        if let srgb = CGColorSpace(name: CGColorSpace.sRGB) { opts[.outputColorSpace] = srgb }
        return CIContext(options: opts)
    }()

    /// Apply adjustments to an NSImage. Returns the input unchanged when neutral (zero cost).
    static func apply(_ image: NSImage, _ adj: ImageAdjustments) -> NSImage? {
        guard !adj.isIdentity else { return image }
        guard let cg = image.cgImage(forProposedRect: nil, context: nil, hints: nil),
              let out = apply(cg, adj) else { return image }
        return NSImage(cgImage: out, size: image.size)
    }

    /// Apply adjustments to a CGImage. Filter order is tonal → local-contrast → color, which is the
    /// standard high-quality pipeline order.
    static func apply(_ cg: CGImage, _ adj: ImageAdjustments) -> CGImage? {
        var ci = CIImage(cgImage: cg)
        let extent = ci.extent
        let dim = min(extent.width, extent.height)

        // 1) Brightness → exposure in linear light (±1.2 stops).
        if adj.brightness != 0 {
            let f = CIFilter.exposureAdjust()
            f.inputImage = ci
            f.ev = Float(adj.brightness / 100.0 * 1.2)
            if let o = f.outputImage { ci = o }
        }
        // 2) Shadows → lift (+) / deepen (−) shadows only; highlights untouched.
        if adj.shadows != 0 {
            let f = CIFilter.highlightShadowAdjust()
            f.inputImage = ci
            f.highlightAmount = 1.0                              // 1 = leave highlights as-is
            f.shadowAmount = Float(adj.shadows / 100.0)          // + brightens, − darkens
            f.radius = Float(max(1, dim * 0.02))                 // local radius → natural recovery
            if let o = f.outputImage { ci = o }
        }
        // 3) Clarity → midtone local contrast via LARGE-radius unsharp mask.
        if adj.clarity > 0 {
            let f = CIFilter.unsharpMask()
            f.inputImage = ci
            f.radius = Float(max(8, dim * 0.03))                 // large radius = local contrast
            f.intensity = Float(adj.clarity / 100.0 * 0.9)
            if let o = f.outputImage { ci = o.cropped(to: extent) }   // USM can grow the extent
        }
        // 4) Saturation → vibrance (protects saturated tones, avoids clipping).
        if adj.saturation != 0 {
            let f = CIFilter.vibrance()
            f.inputImage = ci
            f.amount = Float(adj.saturation / 100.0)
            if let o = f.outputImage { ci = o }
        }
        return context.createCGImage(ci, from: extent)
    }

    /// Downscale for a snappy live preview (full-res CI on every slider tick would be wasteful).
    static func downscaled(_ image: NSImage, maxDim: CGFloat) -> NSImage {
        let s = image.size
        guard s.width > 0, s.height > 0 else { return image }
        let scale = min(1, maxDim / max(s.width, s.height))
        guard scale < 1 else { return image }
        let newSize = NSSize(width: floor(s.width * scale), height: floor(s.height * scale))
        let out = NSImage(size: newSize)
        out.lockFocus()
        image.draw(in: NSRect(origin: .zero, size: newSize),
                   from: NSRect(origin: .zero, size: s), operation: .copy, fraction: 1)
        out.unlockFocus()
        return out
    }
}

// MARK: - Editor sheet (double-click a grid cell)

/// Live, non-destructive image editor. Sliders drive a downscaled preview; "Done" commits the
/// adjustments to the creative (persisted, applied to preview + export).
struct ImageAdjustSheet: View {
    @EnvironmentObject var store: AppStore
    let projectID: UUID
    let creativeID: UUID
    @Environment(\.dismiss) private var dismiss

    @State private var adj: ImageAdjustments
    @State private var rawBase: NSImage?
    @State private var preview: NSImage?

    init(projectID: UUID, creativeID: UUID, initial: ImageAdjustments) {
        self.projectID = projectID
        self.creativeID = creativeID
        _adj = State(initialValue: initial)
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Adjust image").font(.system(size: 15, weight: .bold)).foregroundStyle(Theme.ink)
                Spacer()
                Button("Reset") { adj = .init() }
                    .buttonStyle(.plain).foregroundStyle(adj.isIdentity ? Theme.ink4 : Theme.accent)
                    .disabled(adj.isIdentity)
            }
            .padding(.horizontal, 16).padding(.vertical, 12)
            Divider().overlay(Theme.border)

            ZStack {
                Theme.surface2
                if let img = preview ?? rawBase {
                    Image(nsImage: img).resizable().scaledToFit().padding(10)
                } else {
                    Spinner(size: 22, lineWidth: 2)
                }
            }
            .frame(height: 300).frame(maxWidth: .infinity).clipped()

            VStack(spacing: 13) {
                row("Brightness", $adj.brightness, -100...100)
                row("Shadows", $adj.shadows, -100...100)
                row("Saturation", $adj.saturation, -100...100)
                row("Clarity", $adj.clarity, 0...100)
            }
            .padding(16)
            Divider().overlay(Theme.border)

            HStack(spacing: 8) {
                Spacer()
                Button("Cancel") { dismiss() }.buttonStyle(.plain).foregroundStyle(Theme.ink2)
                AppButton(title: "Done", icon: "check", variant: .primary, size: .sm) {
                    store.setAdjustments(project: projectID, creative: creativeID, adj)
                    dismiss()
                }
            }
            .padding(.horizontal, 16).padding(.vertical, 12)
        }
        .frame(width: 460)
        .background(Theme.bgWindow)
        .task(id: adj) { await rerender() }
    }

    @ViewBuilder
    private func row(_ label: String, _ value: Binding<Double>, _ range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack {
                Text(label).font(.system(size: 12, weight: .semibold)).foregroundStyle(Theme.ink2)
                Spacer()
                Text("\(Int(value.wrappedValue))")
                    .font(.system(size: 11, design: .monospaced)).foregroundStyle(Theme.ink3)
            }
            Slider(value: value, in: range, step: 1)
                .tint(Theme.accent)
        }
    }

    /// Re-render the preview from the (downscaled) raw base whenever `adj` changes. `.task(id:)`
    /// cancels the prior run, and the short sleep debounces rapid slider drags.
    private func rerender() async {
        if rawBase == nil {
            let raw = await store.rawBaseImage(project: projectID, creative: creativeID)
            rawBase = raw.map { ImageAdjust.downscaled($0, maxDim: 900) }
        }
        guard let base = rawBase else { return }
        try? await Task.sleep(nanoseconds: 25_000_000)
        if Task.isCancelled { return }
        preview = adj.isIdentity ? base : ImageAdjust.apply(base, adj)
    }
}
