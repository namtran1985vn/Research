import Foundation
import AppKit
import CoreGraphics

/// Thin abstraction over the image backend (spec §6.3): one implementation today
/// (OpenAI gpt-image-1), but callers never depend on it directly so a future
/// provider can be swapped in without touching the engine or UI.
protocol ImageProvider {
    /// Returns PNG data for an ad image at the requested target size.
    func generate(prompt: String, references: [Data], target: CGSize) async throws -> Data
}

/// Appended to every reference-based prompt so any backend reproduces the real product faithfully,
/// including its exact silhouette (the geometry line stops a half-moon mat becoming a full circle).
enum ImageFidelity {
    static let suffix = "\n\nIMPORTANT: Reproduce the product exactly as shown in the reference photo — identical shape, proportions, colors, materials, surface patterns/textures, engravings, text and logos. Preserve its exact outline/silhouette: if the reference is a half-moon/semicircle, keep it a semicircle (straight edge at the bottom); never turn it into a full circle, oval, or rectangle. Do not redesign, restyle, or invent product details. Only the scene, lighting, and composition may change."
}

/// Crop / scale helpers to normalise any provider output to the requested target size.
enum ImageCrop {
    static func normalizeToTarget(_ data: Data, target: CGSize = CGSize(width: 1024, height: 1280)) -> Data? {
        guard let src = NSImage(data: data), let cg = src.cgImage(forProposedRect: nil, context: nil, hints: nil)
        else { return data }

        let srcW = CGFloat(cg.width), srcH = CGFloat(cg.height)
        // Aspect-fill the target, then center-crop.
        let scale = max(target.width / srcW, target.height / srcH)
        let scaledW = srcW * scale, scaledH = srcH * scale
        let dx = (target.width - scaledW) / 2
        let dy = (target.height - scaledH) / 2

        guard let ctx = CGContext(
            data: nil, width: Int(target.width), height: Int(target.height),
            bitsPerComponent: 8, bytesPerRow: 0,
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return data }
        ctx.interpolationQuality = .high
        ctx.draw(cg, in: CGRect(x: dx, y: dy, width: scaledW, height: scaledH))
        guard let out = ctx.makeImage() else { return data }
        let rep = NSBitmapImageRep(cgImage: out)
        return rep.representation(using: .png, properties: [:])
    }
}
