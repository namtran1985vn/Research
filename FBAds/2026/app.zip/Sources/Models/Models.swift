import Foundation
import CoreGraphics

/// Output aspect ratio for a creative's image.
enum AdRatio: String, Codable, CaseIterable, Hashable {
    case r45 = "4:5"
    case r11 = "1:1"
    var size: CGSize { self == .r45 ? CGSize(width: 1024, height: 1280) : CGSize(width: 1024, height: 1024) }
    var value: CGFloat { size.width / size.height }
    var label: String { rawValue }
}

// MARK: - Project (Campaign → Persona → Creatives)

struct Project: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String                 // campaign name, e.g. "Auria — Q3 Prospecting"
    var product: Product
    var personaCount: Int            // N
    var creativesPerPersona: Int     // M
    var offer: Offer
    var setupGuidance: SetupGuidance? = nil
    var ranking: [RankingEntry]
    var personas: [Persona]
    var pinned: Bool = false          // pinned projects sort to the top of the sidebar
    var createdAt: Date = Date()
    var updatedAt: Date = Date()

    /// Per-project memory: a durable, on-device-distilled record of the user's feedback, edits and
    /// preferences for THIS campaign, injected into later prompts so the AI "remembers" what was asked.
    /// `memory` is the compact distilled text (the only part sent online); `memoryRaw` holds freshly
    /// captured notes awaiting on-device distillation.
    var memory: String = ""
    var memoryRaw: [String] = []

    /// Transient runtime states (not persisted) — drive the loading / error UI.
    var isAnalyzing: Bool = false
    var analyzeFailed: Bool = false
    var analyzeErrorMessage: String? = nil

    enum CodingKeys: String, CodingKey {
        case id, name, product, personaCount, creativesPerPersona, offer, setupGuidance, ranking, personas, pinned, createdAt, updatedAt, memory, memoryRaw
    }

    /// The memory text to inject into a prompt: distilled memory plus any not-yet-distilled notes,
    /// capped so it never bloats the online request.
    var memoryForPrompt: String {
        let raw = memoryRaw.isEmpty ? "" : memoryRaw.map { $0.hasPrefix("- ") ? $0 : "- \($0)" }.joined(separator: "\n")
        let combined = [memory, raw].filter { !$0.isEmpty }.joined(separator: "\n")
        return String(combined.prefix(1400))
    }

    /// Total / done counts across the whole campaign.
    var totals: Totals {
        var t = Totals()
        for p in personas {
            for c in p.creatives {
                t.total += 1
                switch c.status {
                case .done: t.done += 1
                case .queued, .generating: t.inFlight += 1
                case .idle, .error: t.remaining += 1
                }
            }
        }
        return t
    }

    var failedCount: Int { personas.reduce(0) { $0 + $1.creatives.filter { $0.status == .error }.count } }

    struct Totals { var total = 0; var done = 0; var inFlight = 0; var remaining = 0 }
}

// Tolerant Codable so older saved projects keep loading when new fields are added. Swift's
// SYNTHESIZED decoder throws `keyNotFound` for a missing non-optional key even when the property
// has a default (defaults are only used by the memberwise init, never by decoding) — so adding a
// field like `pinned` to the synthesized path silently drops every pre-existing project on load.
// This explicit decoder mirrors the Persona/Creative pattern: every key is optional with a fallback.
extension Project {
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = (try? c.decode(UUID.self, forKey: .id)) ?? UUID()
        name = (try? c.decode(String.self, forKey: .name)) ?? ""
        product = (try? c.decode(Product.self, forKey: .product)) ?? Product(name: "", desc: "")
        personaCount = (try? c.decode(Int.self, forKey: .personaCount)) ?? 0
        creativesPerPersona = (try? c.decode(Int.self, forKey: .creativesPerPersona)) ?? 0
        offer = (try? c.decode(Offer.self, forKey: .offer)) ?? .empty
        setupGuidance = try? c.decode(SetupGuidance.self, forKey: .setupGuidance)
        ranking = (try? c.decode([RankingEntry].self, forKey: .ranking)) ?? []
        personas = (try? c.decode([Persona].self, forKey: .personas)) ?? []
        pinned = (try? c.decode(Bool.self, forKey: .pinned)) ?? false
        createdAt = (try? c.decode(Date.self, forKey: .createdAt)) ?? Date()
        updatedAt = (try? c.decode(Date.self, forKey: .updatedAt)) ?? Date()
        memory = (try? c.decode(String.self, forKey: .memory)) ?? ""
        memoryRaw = (try? c.decode([String].self, forKey: .memoryRaw)) ?? []
    }
}

struct Product: Codable, Hashable {
    var name: String
    var desc: String
    var goal: String = "Sales"       // "Sales" | "Leads"
    /// A short free-text description of the customers the user wants to target.
    var targetCustomers: String = ""
    /// Language for all generated creative content (personas, copy, hooks, headlines).
    var contentLanguage: String = "English"
    /// Filenames of the reference product photos stored inside the project folder.
    var imageFilenames: [String] = []

    // Legacy optional fields (kept for backward-compatible decoding of older projects).
    var price: String = ""
    var market: String = ""
    var budget: String = ""

    enum CodingKeys: String, CodingKey {
        case name, desc, goal, targetCustomers, contentLanguage, imageFilenames, price, market, budget
    }
    init(name: String, desc: String, goal: String = "Sales", targetCustomers: String = "",
         contentLanguage: String = "English", imageFilenames: [String] = []) {
        self.name = name; self.desc = desc; self.goal = goal
        self.targetCustomers = targetCustomers; self.contentLanguage = contentLanguage
        self.imageFilenames = imageFilenames
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        name = try c.decode(String.self, forKey: .name)
        desc = try c.decode(String.self, forKey: .desc)
        goal = (try? c.decode(String.self, forKey: .goal)) ?? "Sales"
        targetCustomers = (try? c.decode(String.self, forKey: .targetCustomers)) ?? ""
        contentLanguage = (try? c.decode(String.self, forKey: .contentLanguage)) ?? "English"
        imageFilenames = (try? c.decode([String].self, forKey: .imageFilenames)) ?? []
        price = (try? c.decode(String.self, forKey: .price)) ?? ""
        market = (try? c.decode(String.self, forKey: .market)) ?? ""
        budget = (try? c.decode(String.self, forKey: .budget)) ?? ""
    }
}

struct Offer: Codable, Hashable {
    var chosen: String
    var rationale: String
    var alternatives: [String]

    static let empty = Offer(chosen: "", rationale: "", alternatives: [])
}

/// Per-persona diversity space (axis 2 & 3): the distinct emotional axes and
/// moments/contexts this persona's creatives are meant to span. AI-derived from
/// the product + target customers; not a fixed enum.
struct Coverage: Codable, Hashable {
    var emotions: [String] = []
    var moments: [String] = []
}

/// Campaign-side reminders for the axes the app does NOT execute (axis 1 person,
/// axis 5 predicted value). AI-tailored per campaign; reference text only.
struct SetupGuidance: Codable, Hashable {
    var pixelCapi: String = ""
    var valueRules: String = ""
    var lookalike: String = ""
    var targeting: String = ""
    var structure: String = ""        // post-Andromeda account structure: Testing + Scaling, broad CBO, consolidate
}

// Tolerant Codable so older saved projects (whose setupGuidance predates newer fields) keep loading.
// Without this, the synthesized decoder throws keyNotFound on a missing key and Project's `try?`
// silently drops the WHOLE setupGuidance. Encode stays synthesized from CodingKeys.
extension SetupGuidance {
    enum CodingKeys: String, CodingKey { case pixelCapi, valueRules, lookalike, targeting, structure }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        pixelCapi = (try? c.decode(String.self, forKey: .pixelCapi)) ?? ""
        valueRules = (try? c.decode(String.self, forKey: .valueRules)) ?? ""
        lookalike = (try? c.decode(String.self, forKey: .lookalike)) ?? ""
        targeting = (try? c.decode(String.self, forKey: .targeting)) ?? ""
        structure = (try? c.decode(String.self, forKey: .structure)) ?? ""
    }
}

struct RankingEntry: Codable, Hashable, Identifiable {
    var id: UUID = UUID()
    var name: String
    var audience: String             // "A" | "B"
    var score: Int
    var picked: Bool
    var why: String
}

struct Persona: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
    var audience: String             // "A" | "B"
    var score: Int
    var ltv: String
    var angle: String
    var desc: String
    var reasonTop: String
    var coreEmotion: String = ""     // §II.3 — core emotion driving the purchase
    var selfImage: String = ""       // §II.5 — who they want to become when buying
    var psychLever: String = ""      // §II.6 — main psychological lever(s)
    var coverage: Coverage = Coverage()  // axes 2 & 3 — what this persona spans
    var copy: CopyBlock
    var creatives: [Creative]
    var winner: Bool = false         // marked as the campaign's winning persona (exclusive)
}

// Tolerant Codable so older saved projects (no lens/coverage) keep loading.
extension Persona {
    enum CodingKeys: String, CodingKey {
        case id, name, audience, score, ltv, angle, desc, reasonTop
        case coreEmotion, selfImage, psychLever, coverage, copy, creatives, winner
    }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = (try? c.decode(UUID.self, forKey: .id)) ?? UUID()
        name = (try? c.decode(String.self, forKey: .name)) ?? ""
        audience = (try? c.decode(String.self, forKey: .audience)) ?? "A"
        score = (try? c.decode(Int.self, forKey: .score)) ?? 0
        ltv = (try? c.decode(String.self, forKey: .ltv)) ?? ""
        angle = (try? c.decode(String.self, forKey: .angle)) ?? ""
        desc = (try? c.decode(String.self, forKey: .desc)) ?? ""
        reasonTop = (try? c.decode(String.self, forKey: .reasonTop)) ?? ""
        coreEmotion = (try? c.decode(String.self, forKey: .coreEmotion)) ?? ""
        selfImage = (try? c.decode(String.self, forKey: .selfImage)) ?? ""
        psychLever = (try? c.decode(String.self, forKey: .psychLever)) ?? ""
        coverage = (try? c.decode(Coverage.self, forKey: .coverage)) ?? Coverage()
        copy = (try? c.decode(CopyBlock.self, forKey: .copy)) ?? CopyBlock(primaryTexts: [], headlines: [], cta: "")
        creatives = (try? c.decode([Creative].self, forKey: .creatives)) ?? []
        winner = (try? c.decode(Bool.self, forKey: .winner)) ?? false
    }
}

extension Creative {
    /// True when the creative actually carries copy to show / generate from. A single over-stuffed
    /// strategy response can run out of output budget and gut the LATER personas — emitting creatives
    /// whose every variant array is empty (`[""]`). Those still decode, so this is the gate that lets
    /// `isWellFormed` reject them for regeneration via the reliable single-persona call.
    var hasUsableCopy: Bool {
        [hooks, headlines, primaryTexts, imagePrompts]
            .contains { $0.contains { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty } }
    }
}

extension Persona {
    /// A persona is only usable if it carries an identity AND at least one creative AND every kept
    /// creative actually has copy. The tolerant decoders (built to survive schema evolution) will
    /// happily produce a nameless / creative-less / empty-copy persona from a contract-violating or
    /// budget-truncated model response; this is the single gate that rejects those, so neither an
    /// "empty persona" nor a persona of blank creatives can ever reach the campaign — the caller
    /// (runStrategy → backfillPersonas) regenerates the shortfall one persona at a time.
    var isWellFormed: Bool {
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && !creatives.isEmpty
            && creatives.allSatisfy(\.hasUsableCopy)
    }
}

struct CopyBlock: Codable, Hashable {
    var primaryTexts: [String]
    var headlines: [String]
    var cta: String
}

struct Creative: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var rank: Int
    var score: Int
    var style: String                // beauty | ugc | testimonial | lifestyle | studio
    var bigIdea: String = ""         // the distinct selling insight/"aha" angle this creative leads with
    var concept: String
    var message: String
    var productDetail: String
    var layout: String
    var reasonTop: String

    // Andromeda axis tags (set by the strategy brain; empty on legacy projects).
    var emotionAxis: String = ""      // axis 2 — emotion this creative fires
    var moment: String = ""           // axis 3 — moment/context it targets
    var messageStrategy: String = ""  // pain | proof | transformation | objection | desire
    var valueSignal: String = ""      // axis 5 — self-pricing-high cue (distinct from productDetail)
    var awarenessStage: Int = 3       // Schwartz 1–5: 1 direct-claim … 5 identity/emotion. Default 3 (mechanism).

    // Each of these carries 4 top variants the user can read & choose between.
    var hooks: [String] = []          // ≤6 words each
    var highlights: [String] = []     // emphasized word per hook (parallel to hooks)
    var selHook: Int = 0
    var headlines: [String] = []
    var selHeadline: Int = 0
    var primaryTexts: [String] = []
    var selPrimaryText: Int = 0
    var imagePrompts: [String] = []
    var selImagePrompt: Int = 0

    // Output aspect ratio (4:5 default, or 1:1).
    var ratio: AdRatio = .r45

    // Generation state (transient + persisted result)
    var status: CreativeStatus = .idle
    var imageFilename: String? = nil      // generated PNG inside project folder
    /// True when `imageFilename` is the auto 3×3 sample grid (not yet an AI/imported image).
    var imageIsPlaceholder: Bool = false
    /// Reference-photo filenames (in grid order, may repeat) used to build the sample grid, so the
    /// saved/exported file can recompose them from the originals at full resolution.
    var sampleRefs: [String] = []
    /// Sample-grid layout, columns × rows (e.g. 2×2, 2×3, 3×3). User-switchable in the inspector.
    var sampleCols: Int = 3
    var sampleRows: Int = 3
    /// Per-cell pan offset, normalized to −1…1 and parallel to `sampleRefs`; (0,0) = centered.
    /// Lets the user drag each photo inside its grid cell to choose which part shows. Empty/short
    /// → missing cells are treated as centered. Reset when the layout or photos change.
    var sampleOffsets: [CGPoint] = []
    /// Bumped on EVERY rewrite of this creative's image file (sample build, AI generate, import,
    /// regenerate). The file is always rewritten in place at the same path, so `imageFilename` never
    /// changes — this counter is the single signal that the bitmap changed, and it is part of
    /// `imageToken` so every view + the preview cache reload in lockstep with `ImageStore.evict`.
    var imageVersion: Int = 0
    var winner: Bool = false
    var attempt: Int = 0
    var errorMessage: String? = nil

    // S3 text-on-image layers (auto-seeded from hook on first open)
    var textLayers: [TextLayer] = []

    /// Non-destructive photo adjustments applied to the base image at render time (preview + export).
    var adjustments: ImageAdjustments = .init()

    /// Identity of the BASE bitmap (no text) for view-refresh keys. Any change here means the on-disk
    /// image bytes changed OR the adjustments changed, so views must reload. This is the ONE place that
    /// defines that identity — `AdImageView`, `DraggableAdView`, and `AppStore.previewSignature` all
    /// derive their keys from it so they never drift. Composite (with-text) keys add `textLayers` on top.
    var imageToken: Int {
        var h = Hasher()
        h.combine(imageFilename); h.combine(ratio); h.combine(imageVersion); h.combine(status)
        h.combine(adjustments)
        return h.finalize()
    }

    // MARK: Convenience accessors for the currently selected variant.
    var hook: String {
        // selHook == -1 means "no hook selected" → no text on the image.
        get { selHook >= 0 && hooks.indices.contains(selHook) ? hooks[selHook] : "" }
        set { writeSelected(&hooks, index: &selHook, newValue) }
    }
    var highlight: String {
        get { highlights.indices.contains(selHook) ? highlights[selHook] : (highlights.first ?? "") }
        set {
            if highlights.indices.contains(selHook) { highlights[selHook] = newValue }
            else if highlights.isEmpty { highlights = [newValue] }
            else { highlights[0] = newValue }
        }
    }
    var headline: String {
        get { headlines.indices.contains(selHeadline) ? headlines[selHeadline] : (headlines.first ?? "") }
        set { writeSelected(&headlines, index: &selHeadline, newValue) }
    }
    var primaryText: String {
        get { primaryTexts.indices.contains(selPrimaryText) ? primaryTexts[selPrimaryText] : (primaryTexts.first ?? "") }
        set { writeSelected(&primaryTexts, index: &selPrimaryText, newValue) }
    }
    var imagePrompt: String {
        get { imagePrompts.indices.contains(selImagePrompt) ? imagePrompts[selImagePrompt] : (imagePrompts.first ?? "") }
        set { writeSelected(&imagePrompts, index: &selImagePrompt, newValue) }
    }

    private func writeSelected(_ array: inout [String], index: inout Int, _ value: String) {
        if array.indices.contains(index) { array[index] = value }
        else if array.isEmpty { array = [value]; index = 0 }
        else { index = 0; array[0] = value }
    }
}

// Tolerant Codable so older saved projects keep loading when new fields are added.
extension Creative {
    enum CodingKeys: String, CodingKey {
        case id, rank, score, style, bigIdea, concept, message, productDetail, layout, reasonTop
        case emotionAxis, moment, messageStrategy, valueSignal, awarenessStage
        case hooks, highlights, selHook, headlines, selHeadline, primaryTexts, selPrimaryText
        case imagePrompts, selImagePrompt, ratio
        case status, imageFilename, imageIsPlaceholder, sampleRefs, sampleCols, sampleRows, sampleOffsets, imageVersion, winner, attempt, errorMessage, textLayers, adjustments
    }
    private enum LegacyKeys: String, CodingKey { case hook, highlight, sampleCells }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = (try? c.decode(UUID.self, forKey: .id)) ?? UUID()
        rank = (try? c.decode(Int.self, forKey: .rank)) ?? 0
        score = (try? c.decode(Int.self, forKey: .score)) ?? 0
        style = (try? c.decode(String.self, forKey: .style)) ?? "studio"
        bigIdea = (try? c.decode(String.self, forKey: .bigIdea)) ?? ""
        concept = (try? c.decode(String.self, forKey: .concept)) ?? ""
        message = (try? c.decode(String.self, forKey: .message)) ?? ""
        productDetail = (try? c.decode(String.self, forKey: .productDetail)) ?? ""
        layout = (try? c.decode(String.self, forKey: .layout)) ?? ""
        reasonTop = (try? c.decode(String.self, forKey: .reasonTop)) ?? ""
        emotionAxis = (try? c.decode(String.self, forKey: .emotionAxis)) ?? ""
        moment = (try? c.decode(String.self, forKey: .moment)) ?? ""
        messageStrategy = (try? c.decode(String.self, forKey: .messageStrategy)) ?? ""
        valueSignal = (try? c.decode(String.self, forKey: .valueSignal)) ?? ""
        awarenessStage = (try? c.decode(Int.self, forKey: .awarenessStage)) ?? 3
        hooks = (try? c.decode([String].self, forKey: .hooks)) ?? []
        highlights = (try? c.decode([String].self, forKey: .highlights)) ?? []
        // Back-compat: older projects stored a single `hook`/`highlight`.
        if hooks.isEmpty, let legacy = try? d.container(keyedBy: LegacyKeys.self),
           let h = try? legacy.decode(String.self, forKey: .hook), !h.isEmpty {
            hooks = [h]
            if highlights.isEmpty, let hi = try? legacy.decode(String.self, forKey: .highlight) { highlights = [hi] }
        }
        selHook = (try? c.decode(Int.self, forKey: .selHook)) ?? 0
        headlines = (try? c.decode([String].self, forKey: .headlines)) ?? []
        selHeadline = (try? c.decode(Int.self, forKey: .selHeadline)) ?? 0
        primaryTexts = (try? c.decode([String].self, forKey: .primaryTexts)) ?? []
        selPrimaryText = (try? c.decode(Int.self, forKey: .selPrimaryText)) ?? 0
        imagePrompts = (try? c.decode([String].self, forKey: .imagePrompts)) ?? []
        selImagePrompt = (try? c.decode(Int.self, forKey: .selImagePrompt)) ?? 0
        ratio = (try? c.decode(AdRatio.self, forKey: .ratio)) ?? .r45
        status = (try? c.decode(CreativeStatus.self, forKey: .status)) ?? .idle
        imageFilename = try? c.decode(String.self, forKey: .imageFilename)
        imageIsPlaceholder = (try? c.decode(Bool.self, forKey: .imageIsPlaceholder)) ?? false
        sampleRefs = (try? c.decode([String].self, forKey: .sampleRefs)) ?? []
        if let cols = try? c.decode(Int.self, forKey: .sampleCols),
           let rows = try? c.decode(Int.self, forKey: .sampleRows) {
            sampleCols = cols; sampleRows = rows
        } else {
            // Migrate legacy single cell-count: 4 → 2×2, anything else → 3×3.
            let legacy = (try? d.container(keyedBy: LegacyKeys.self).decode(Int.self, forKey: .sampleCells)) ?? 9
            sampleCols = legacy == 4 ? 2 : 3
            sampleRows = legacy == 4 ? 2 : 3
        }
        sampleOffsets = (try? c.decode([CGPoint].self, forKey: .sampleOffsets)) ?? []
        imageVersion = (try? c.decode(Int.self, forKey: .imageVersion)) ?? 0
        winner = (try? c.decode(Bool.self, forKey: .winner)) ?? false
        attempt = (try? c.decode(Int.self, forKey: .attempt)) ?? 0
        errorMessage = try? c.decode(String.self, forKey: .errorMessage)
        textLayers = (try? c.decode([TextLayer].self, forKey: .textLayers)) ?? []
        adjustments = (try? c.decode(ImageAdjustments.self, forKey: .adjustments)) ?? .init()
    }
}

/// Non-destructive photo adjustments applied to a creative's base image at render time (preview AND
/// export) via a linear-light Core Image pipeline. Neutral (all 0) = identity, so it costs nothing
/// until the user actually edits. See `ImageAdjust` for the filter mapping.
struct ImageAdjustments: Codable, Hashable {
    var brightness: Double = 0   // -100…100 → exposure (EV, linear light) via CIExposureAdjust
    var shadows: Double = 0      // -100…100 → lift/deepen shadows via CIHighlightShadowAdjust
    var saturation: Double = 0   // -100…100 → vibrance (protects saturated tones) via CIVibrance
    var clarity: Double = 0      //    0…100 → midtone local contrast via large-radius CIUnsharpMask

    var isIdentity: Bool { brightness == 0 && shadows == 0 && saturation == 0 && clarity == 0 }
}

// MARK: - Regenerable copy fields

/// The AI-written text fields that can be individually regenerated with a custom instruction.
enum CopyField: String, Hashable {
    case headline, primaryText, hook

    var label: String {
        switch self {
        case .headline: return "headline"
        case .primaryText: return "primary text"
        case .hook: return "hook"
        }
    }
    /// Length/format guidance handed to the model when rewriting this field.
    var guidance: String {
        switch self {
        case .headline:    return "A punchy Facebook ad headline, ideally ≤ 8 words. No end punctuation needed."
        case .primaryText: return "Facebook primary text: 1–3 sentences (never a single short line) — open with a hook, go deep emotionally, hit the buyer's psychology/pain/desire, pull toward action."
        case .hook:        return "A scroll-stopping hook of ≤ 6 words for rendering on the image."
        }
    }
}

// MARK: - Text-on-image layer (S3 editor)

/// Canonical hook color palettes — the single source of truth for both the editor swatches and the
/// style-preset seeds. Two curated sets: PREMIUM / quiet-luxury (Tệp A) and DR / high-CTR (Tệp B).
enum HookPalette {
    // Premium / quiet-luxury (Tệp A)
    static let white: UInt       = 0xFFFFFF // text on dark
    static let charcoal: UInt    = 0x1A1A1A // text on light / box
    static let cream: UInt       = 0xF4EDE0 // banner / box fill
    static let terracotta: UInt  = 0xC26B4A // highlight
    static let antiqueGold: UInt = 0xC9A227 // highlight (muted gold)
    static let moss: UInt        = 0x5A6B4F // highlight / text on cream
    static let coffee: UInt      = 0x3B2F2A // semi-transparent box (~70%)
    static let navy: UInt        = 0x26344D // premium text / box
    static let taupe: UInt       = 0xA9A091 // neutral secondary fill
    static let burgundy: UInt    = 0x6E1F2A // refined highlight (vs. bright red)
    // DR / high-CTR (Tệp B)
    static let black: UInt       = 0x000000 // box
    static let ctaYellow: UInt   = 0xFFD400 // strongest-CTR highlight
    static let ctaOrange: UInt   = 0xFF6A00 // highlight / CTA
    static let ctaRed: UInt      = 0xE5202E // highlight (stop-scroll)
    static let pink: UInt        = 0xFE2C55 // TikTok accent
    static let pinkBox: UInt     = 0xF01E6E // TikTok box

    /// Text-color swatches — premium tones first, then DR accents.
    static let text: [UInt] = [white, charcoal, navy, terracotta, antiqueGold, moss, burgundy, taupe,
                               pink, ctaRed, ctaOrange, ctaYellow, black]
    /// Caption-box fill swatches.
    static let box: [UInt] = [charcoal, black, cream, coffee, navy, taupe, terracotta, burgundy, white,
                              pinkBox, ctaOrange, ctaRed]
    /// Highlight-word swatches — premium tones first, then DR accents.
    static let highlight: [UInt] = [terracotta, antiqueGold, moss, burgundy,
                                    ctaYellow, ctaOrange, ctaRed, pink, white, charcoal]
}

/// Visual treatment of the hook text rendered over the image. Each preset seeds the layer's text
/// color, caption-box fill, accent, box opacity, corner rounding, weight, and (optionally) font —
/// all overridable afterwards via the swatches below the picker.
///
/// The first three are the premium "magazine" presets shown at the top of the list:
///   • editorial  — serif cream banner, charcoal text, terracotta accent (Architectural Digest look)
///   • cleanFloat — no box: white text floating on a soft shadow, very restrained accent
///   • boldBlock  — semi-transparent dark scrim, white text, warm-gold keyword pop (high CTR, still tasteful)
enum HookStyle: String, Codable, CaseIterable, Hashable {
    case editorial // serif charcoal text on a warm-cream "magazine" banner, terracotta accent
    case cleanFloat // no box: white text + soft shadow, champagne accent — quiet luxury
    case boldBlock // white text on a semi-transparent warm-black scrim, warm-gold accent
    case tiktok    // white text on near-black box with cyan/pink TikTok borders
    case normal1   // black text on a plain white box
    case normal2   // white text on a plain black box
    case normal3   // white text on a plain pink box
    case normal4   // white text on a plain dark-red box
    case normal5   // black text on a white box with a dashed border

    var label: String {
        switch self {
        case .editorial:  return "Editorial"
        case .cleanFloat: return "Clean Float"
        case .boldBlock:  return "Bold Block"
        case .tiktok:  return "TikTok"
        case .normal1: return "Normal 1"
        case .normal2: return "Normal 2"
        case .normal3: return "Normal 3"
        case .normal4: return "Normal 4"
        case .normal5: return "Normal 5"
        }
    }
    /// Box fill behind the text (ignored for Clean Float, which draws no box).
    var boxHex: UInt {
        switch self {
        case .editorial:  return HookPalette.cream
        case .cleanFloat: return HookPalette.black   // unused (no box)
        case .boldBlock:  return HookPalette.coffee  // "Box bán trong suốt (~70%)"
        case .tiktok:  return 0x050505
        case .normal1: return 0xFFFFFF
        case .normal2: return 0x050505
        case .normal3: return 0xF01E6E
        case .normal4: return 0x8B0000
        case .normal5: return 0xFFFFFF
        }
    }
    /// Main text color (highlight word still uses the layer's highlight color).
    var textHex: UInt {
        switch self {
        case .editorial:  return HookPalette.charcoal
        case .cleanFloat: return HookPalette.white
        case .boldBlock:  return HookPalette.white
        case .tiktok:  return 0xFFFFFF
        case .normal1: return 0x000000
        case .normal2: return 0xFFFFFF
        case .normal3: return 0xFFFFFF
        case .normal4: return 0xFFFFFF
        case .normal5: return 0x000000
        }
    }
    /// Accent seeded for the highlight word. The premium presets use tasteful warm tones (no neon);
    /// the original styles keep the TikTok red.
    var highlightHex: UInt {
        switch self {
        case .editorial:  return HookPalette.terracotta
        case .cleanFloat: return HookPalette.antiqueGold  // muted gold — restrained accent
        case .boldBlock:  return HookPalette.ctaYellow    // strongest-CTR highlight
        default:          return HookPalette.pink         // TikTok red
        }
    }
    /// Whether a caption box is drawn behind the text. Clean Float floats the text instead.
    var drawsBox: Bool { self != .cleanFloat }
    /// Box fill opacity — Bold Block uses a semi-transparent scrim so the photo reads through.
    var boxOpacity: CGFloat { self == .boldBlock ? 0.70 : 1.0 }
    /// Caption-box corner rounding as a fraction of the font size (0 = sharp).
    var cornerRadiusFactor: CGFloat {
        switch self {
        case .editorial:  return 0.16
        case .boldBlock:  return 0.22
        default:          return 0
        }
    }
    /// Seeded weight — Editorial / Clean Float read as "quiet luxury", not heavy.
    var prefersBold: Bool { self != .editorial && self != .cleanFloat }
    /// Seeded font ("" keeps the layer's current font). The premium presets set their font
    /// explicitly so a serif never leaks into a sans style (or vice-versa) when switching presets:
    /// Editorial leans serif; Clean Float / Bold Block want a clean, punchy sans.
    var preferredFont: String {
        switch self {
        case .editorial:  return "Georgia"          // elegant serif
        case .cleanFloat: return "SF Pro Display"   // light-medium sans
        case .boldBlock:  return "SF Pro Display"   // extra-bold sans for punch
        default:          return ""                 // original styles keep the layer's font
        }
    }
    /// Cyan top+left / pink bottom+right borders — only the TikTok treatment has them.
    var hasBorders: Bool { self == .tiktok }
    /// A dashed rectangular outline around the caption box — the Normal 5 "cut-out" look.
    var hasDashedBorder: Bool { self == .normal5 }
}

struct TextLayer: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var text: String
    var xFrac: Double = 0.08          // top-left origin, fraction of width
    var yFrac: Double = 0.08
    var widthFrac: Double = 0.64
    var fontSize: Double = 48         // points in the 1024×1280 canvas space
    var fontName: String = "SF Pro Display"
    var colorHex: UInt = 0xFFFFFF     // explicit TEXT color (always applied)
    var boxColorHex: UInt = 0x050505  // explicit BACKGROUND (caption box) color
    var bold: Bool = true
    var italic: Bool = false
    var alignment: String = "leading" // leading | center | trailing
    var highlightWord: String = ""
    var highlightColorHex: UInt = 0xFE2C55  // TikTok red accent
    var shadow: Bool = true            // draws the rounded background box
    var hookStyle: HookStyle = .tiktok // last-applied preset (also drives TikTok borders)

    init(id: UUID = UUID(), text: String, xFrac: Double = 0.08, yFrac: Double = 0.08,
         widthFrac: Double = 0.64, fontSize: Double = 48, fontName: String = "SF Pro Display",
         colorHex: UInt = 0xFFFFFF, boxColorHex: UInt = 0x050505, bold: Bool = true, italic: Bool = false, alignment: String = "leading",
         highlightWord: String = "", highlightColorHex: UInt = 0xFE2C55,
         shadow: Bool = true, hookStyle: HookStyle = .tiktok) {
        self.id = id; self.text = text; self.xFrac = xFrac; self.yFrac = yFrac
        self.widthFrac = widthFrac; self.fontSize = fontSize; self.fontName = fontName
        self.colorHex = colorHex; self.boxColorHex = boxColorHex; self.bold = bold; self.italic = italic; self.alignment = alignment
        self.highlightWord = highlightWord; self.highlightColorHex = highlightColorHex
        self.shadow = shadow; self.hookStyle = hookStyle
    }

    /// Apply a style preset to this layer: seed the explicit text/box/accent colors, box on-off,
    /// weight, and (when the preset specifies one) the font. The swatches below the picker can still
    /// override any of these afterwards.
    mutating func apply(style: HookStyle) {
        hookStyle = style
        colorHex = style.textHex
        boxColorHex = style.boxHex
        highlightColorHex = style.highlightHex
        shadow = style.drawsBox
        bold = style.prefersBold
        if !style.preferredFont.isEmpty { fontName = style.preferredFont }
    }

    // Tolerant decode so projects saved before a field was added keep their layers (position, size).
    enum CodingKeys: String, CodingKey {
        case id, text, xFrac, yFrac, widthFrac, fontSize, fontName, colorHex, boxColorHex
        case bold, italic, alignment, highlightWord, highlightColorHex, shadow, hookStyle
    }
    init(from d: Decoder) throws {
        let c = try d.container(keyedBy: CodingKeys.self)
        id = (try? c.decode(UUID.self, forKey: .id)) ?? UUID()
        text = (try? c.decode(String.self, forKey: .text)) ?? ""
        xFrac = (try? c.decode(Double.self, forKey: .xFrac)) ?? 0.08
        yFrac = (try? c.decode(Double.self, forKey: .yFrac)) ?? 0.08
        widthFrac = (try? c.decode(Double.self, forKey: .widthFrac)) ?? 0.64
        fontSize = (try? c.decode(Double.self, forKey: .fontSize)) ?? 48
        fontName = (try? c.decode(String.self, forKey: .fontName)) ?? "SF Pro Display"
        bold = (try? c.decode(Bool.self, forKey: .bold)) ?? true
        italic = (try? c.decode(Bool.self, forKey: .italic)) ?? false
        alignment = (try? c.decode(String.self, forKey: .alignment)) ?? "leading"
        highlightWord = (try? c.decode(String.self, forKey: .highlightWord)) ?? ""
        highlightColorHex = (try? c.decode(UInt.self, forKey: .highlightColorHex)) ?? 0xFE2C55
        shadow = (try? c.decode(Bool.self, forKey: .shadow)) ?? true
        hookStyle = (try? c.decode(HookStyle.self, forKey: .hookStyle)) ?? .tiktok
        // Migration: pre-boxColorHex layers drew text/box from the style preset (colorHex was
        // ignored), so seed both explicit colors from the style to preserve their look.
        if let bc = try? c.decode(UInt.self, forKey: .boxColorHex) {
            boxColorHex = bc
            colorHex = (try? c.decode(UInt.self, forKey: .colorHex)) ?? hookStyle.textHex
        } else {
            boxColorHex = hookStyle.boxHex
            colorHex = hookStyle.textHex
        }
    }
}
