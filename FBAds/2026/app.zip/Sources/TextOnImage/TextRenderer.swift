import AppKit

/// Composites Vietnamese/English text layers onto the AI-generated base image, producing the
/// final 1024×1280 ad. Used by both the S3 editor preview and the export pipeline.
/// (Mechanism (b): the image model leaves negative space, the app renders clean text.)
enum TextRenderer {
    static let canvas = NSSize(width: 1024, height: 1280)

    static func composite(base: NSImage, layers: [TextLayer], font: String,
                          size: NSSize = NSSize(width: 1024, height: 1280)) -> NSImage {
        let out = NSImage(size: size)
        out.lockFocus()
        NSGraphicsContext.current?.imageInterpolation = .high

        // Aspect-fill the base into the canvas.
        base.draw(in: NSRect(origin: .zero, size: size), from: .zero, operation: .copy, fraction: 1.0)

        for layer in layers { draw(layer, defaultFont: font, size: size) }

        out.unlockFocus()
        return out
    }

    private static func draw(_ layer: TextLayer, defaultFont: String, size: NSSize) {
        let layerText = CopyText.clean(layer.text)
        let highlightTerms = CopyText.highlightTerms(layer.highlightWord)
        guard !layerText.isEmpty else { return }
        let w = size.width
        let h = size.height

        let fontSize = CGFloat(layer.fontSize)
        let baseFont = resolveFont(layer.fontName.isEmpty ? defaultFont : layer.fontName,
                                   size: fontSize, bold: layer.bold, italic: layer.italic)

        let para = NSMutableParagraphStyle()
        switch layer.alignment {
        case "center": para.alignment = .center
        case "trailing": para.alignment = .right
        default: para.alignment = .left
        }
        para.lineHeightMultiple = 1.05

        // Explicit per-layer text color (the style preset seeds it; the user can override it).
        let textColor = NSColor(srgbHex: layer.colorHex)
        var attrs: [NSAttributedString.Key: Any] = [
            .font: baseFont,
            .foregroundColor: textColor,
            .paragraphStyle: para,
        ]
        if !layer.shadow {
            // No box (Clean Float): keep text legible with a contrasting outline + a soft, wide dark
            // halo behind the glyphs — the "gradient tối mờ sau chữ" that lifts it off the photo.
            attrs[.strokeColor] = NSColor(srgbHex: ReadableInk.outlineHex(forText: layer.colorHex))
            attrs[.strokeWidth] = -7.0
            let sh = NSShadow()
            sh.shadowColor = NSColor.black.withAlphaComponent(0.6)
            sh.shadowOffset = NSSize(width: 0, height: -fontSize * 0.04)
            sh.shadowBlurRadius = fontSize * 0.20
            attrs[.shadow] = sh
        }

        let string = NSMutableAttributedString(string: layerText, attributes: attrs)
        // Highlight words — accent color + italic. Supports several comma-separated terms.
        let italicFont = NSFontManager.shared.convert(baseFont, toHaveTrait: .italicFontMask) as NSFont?
        let ns = layerText as NSString
        for term in highlightTerms {
            let range = ns.range(of: term, options: .caseInsensitive)
            if range.location != NSNotFound {
                string.addAttribute(.foregroundColor, value: NSColor(srgbHex: layer.highlightColorHex), range: range)
                if let italicFont { string.addAttribute(.font, value: italicFont, range: range) }
            }
        }

        let boxWidth = w * CGFloat(layer.widthFrac)
        // Measure the text hugging tightly (width returns the actual used width, ≤ boxWidth).
        let bounding = string.boundingRect(with: NSSize(width: boxWidth, height: .greatestFiniteMagnitude),
                                           options: [.usesLineFragmentOrigin, .usesFontLeading])
        let textWidth = ceil(bounding.width)
        let textHeight = ceil(bounding.height)
        let originX = w * CGFloat(layer.xFrac)
        // yFrac is measured from the TOP; AppKit draws from bottom-left.
        let originYTop = h * CGFloat(layer.yFrac)

        // Caption box: text on a sharp-cornered box. The TikTok style adds a cyan top+left border
        // and a hot-pink bottom+right border; Normal styles are a plain box. Padding mirrors HookText.
        if layer.shadow {
            let style = layer.hookStyle
            let padH = fontSize * 0.40
            let padV = fontSize * 0.26
            let bw = max(4, fontSize * 0.17)
            let boxW = textWidth + padH * 2
            let boxH = textHeight + padV * 2
            let boxX = originX
            let boxY = h - originYTop - boxH
            let boxRect = NSRect(x: boxX, y: boxY, width: boxW, height: boxH)

            // Premium presets soften the box (rounded corners) and may use a semi-transparent scrim.
            let radius = fontSize * style.cornerRadiusFactor
            NSColor(srgbHex: layer.boxColorHex, alpha: style.boxOpacity).setFill()
            if radius > 0 {
                NSBezierPath(roundedRect: boxRect, xRadius: radius, yRadius: radius).fill()
            } else {
                boxRect.fill()
            }

            if style.hasBorders {
                NSColor(srgbHex: 0x00D6D6).setFill()
                NSRect(x: boxX, y: boxY + boxH - bw, width: boxW, height: bw).fill()  // top
                NSRect(x: boxX, y: boxY, width: bw, height: boxH).fill()              // left
                NSColor(srgbHex: 0xFF2B5F).setFill()
                NSRect(x: boxX, y: boxY, width: boxW, height: bw).fill()              // bottom
                NSRect(x: boxX + boxW - bw, y: boxY, width: bw, height: boxH).fill()  // right
            }

            if style.hasDashedBorder {
                let lw = max(2, fontSize * 0.07)
                let path = NSBezierPath(rect: boxRect.insetBy(dx: lw / 2, dy: lw / 2))
                path.lineWidth = lw
                path.setLineDash([max(4, fontSize * 0.24), max(3, fontSize * 0.16)], count: 2, phase: 0)
                NSColor(srgbHex: layer.colorHex).setStroke()
                path.stroke()
            }

            let drawRect = NSRect(x: boxX + padH, y: h - originYTop - padV - textHeight,
                                  width: textWidth, height: textHeight)
            string.draw(with: drawRect, options: [.usesLineFragmentOrigin, .usesFontLeading])
        } else {
            let drawRect = NSRect(x: originX, y: h - originYTop - textHeight, width: boxWidth, height: textHeight)
            string.draw(with: drawRect, options: [.usesLineFragmentOrigin, .usesFontLeading])
        }
    }

    private static func resolveFont(_ name: String, size: CGFloat, bold: Bool, italic: Bool = false) -> NSFont {
        var f = NSFont(name: name, size: size) ?? NSFont.systemFont(ofSize: size, weight: bold ? .bold : .regular)
        if bold { f = NSFontManager.shared.convert(f, toHaveTrait: .boldFontMask) }
        if italic { f = NSFontManager.shared.convert(f, toHaveTrait: .italicFontMask) }
        return f
    }
}

extension NSColor {
    convenience init(srgbHex hex: UInt, alpha: CGFloat = 1) {
        self.init(srgbRed: CGFloat((hex >> 16) & 0xFF) / 255,
                  green: CGFloat((hex >> 8) & 0xFF) / 255,
                  blue: CGFloat(hex & 0xFF) / 255,
                  alpha: alpha)
    }
}

extension String {
    /// Filesystem-safe slug for export filenames.
    var slug: String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_"))
        let mapped = self.lowercased().map { ch -> Character in
            String(ch).rangeOfCharacter(from: allowed) != nil ? ch : "-"
        }
        let collapsed = String(mapped).replacingOccurrences(of: "--", with: "-")
        return collapsed.trimmingCharacters(in: CharacterSet(charactersIn: "-")).isEmpty
            ? "untitled" : collapsed.trimmingCharacters(in: CharacterSet(charactersIn: "-"))
    }
}
