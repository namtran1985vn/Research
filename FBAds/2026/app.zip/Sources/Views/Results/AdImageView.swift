import SwiftUI
import AppKit

/// One hook/text layer rendered as a "tutorial banner": bold white text on a sharp-cornered
/// near-black box with a cyan top+left border and a hot-pink bottom border.
/// Shared by the canvas, the live preview, and the drag overlay so everything matches.
struct HookText: View {
    let layer: TextLayer
    let scale: CGFloat
    let containerWidth: CGFloat

    private static let bannerCyan = Color(hex: 0x00D6D6)
    private static let bannerPink = Color(hex: 0xFF2B5F)

    var body: some View {
        let s = layer.fontSize * scale
        let bw = max(3, s * 0.17)
        let borders = layer.shadow && layer.hookStyle.hasBorders
        let dashed = layer.shadow && layer.hookStyle.hasDashedBorder
        Text(highlighted)
            .font(font)
            .multilineTextAlignment(textAlign)
            .fixedSize(horizontal: true, vertical: true)   // hug the (short) hook tightly
            .padding(.horizontal, s * 0.40)
            .padding(.vertical, s * 0.26)
            .background {
                if layer.shadow {
                    RoundedRectangle(cornerRadius: s * layer.hookStyle.cornerRadiusFactor, style: .continuous)
                        .fill(Color(hex: layer.boxColorHex).opacity(Double(layer.hookStyle.boxOpacity)))
                }
            }
            .overlay(alignment: .top)      { if borders { Self.bannerCyan.frame(height: bw) } }
            .overlay(alignment: .leading)  { if borders { Self.bannerCyan.frame(width: bw) } }
            .overlay(alignment: .bottom)   { if borders { Self.bannerPink.frame(height: bw) } }
            .overlay(alignment: .trailing) { if borders { Self.bannerPink.frame(width: bw) } }
            .overlay {
                if dashed {
                    Rectangle().strokeBorder(Color(hex: layer.colorHex),
                                             style: StrokeStyle(lineWidth: max(2, s * 0.07),
                                                                dash: [max(4, s * 0.24), max(3, s * 0.16)]))
                }
            }
            // No box (Clean Float): a soft dark halo keeps the text legible and lifts it off the
            // photo. Two passes = a tight contrast edge + a wider gradient glow. No-op when boxed.
            .shadow(color: .black.opacity(layer.shadow ? 0 : 0.60), radius: layer.shadow ? 0 : s * 0.09, y: layer.shadow ? 0 : s * 0.03)
            .shadow(color: .black.opacity(layer.shadow ? 0 : 0.45), radius: layer.shadow ? 0 : s * 0.22)
    }

    private var font: Font {
        let s = layer.fontSize * scale
        let base: Font = (layer.fontName.isEmpty || layer.fontName.hasPrefix("SF Pro"))
            ? .system(size: s, weight: layer.bold ? .heavy : .regular)
            : .custom(layer.fontName, size: s).weight(layer.bold ? .heavy : .regular)
        return layer.italic ? base.italic() : base
    }
    private var highlighted: AttributedString {
        var str = AttributedString(CopyText.clean(layer.text))
        str.foregroundColor = Color(hex: layer.colorHex)
        for term in CopyText.highlightTerms(layer.highlightWord) {
            if let range = str.range(of: term, options: .caseInsensitive) {
                str[range].foregroundColor = Color(hex: layer.highlightColorHex)
            }
        }
        return str
    }
    private var textAlign: TextAlignment {
        switch layer.alignment { case "center": return .center; case "trailing": return .trailing; default: return .leading }
    }
    private var frameAlign: Alignment {
        switch layer.alignment { case "center": return .top; case "trailing": return .topTrailing; default: return .topLeading }
    }
}

/// The single source of truth for rendering an ad (base image + text layers). Used both for the
/// on-screen preview (via the store's renderer) and for export, so the saved PNG matches exactly.
struct AdCanvas: View {
    let baseImage: NSImage?
    let layers: [TextLayer]
    let size: CGSize

    var body: some View {
        let scale = size.width / 1024
        ZStack(alignment: .topLeading) {
            if let baseImage {
                Image(nsImage: baseImage).resizable().scaledToFill()
                    .frame(width: size.width, height: size.height).clipped()
            } else {
                Theme.surface2
            }
            LinearGradient(colors: [.clear, .black.opacity(0.18)], startPoint: .center, endPoint: .bottom)

            ForEach(layers) { layer in
                if !CopyText.clean(layer.text).isEmpty {
                    HookText(layer: layer, scale: scale, containerWidth: size.width)
                        .offset(x: size.width * layer.xFrac, y: size.height * layer.yFrac)
                }
            }
        }
        .frame(width: size.width, height: size.height)
    }
}

/// On-screen preview: displays the EXACT rendered bitmap that export produces (when showing text),
/// so the saved file looks identical. Falls back to the bare base image when text is hidden.
struct AdImageView: View {
    let creative: Creative
    let projectID: UUID
    var showText: Bool = true
    @EnvironmentObject var store: AppStore
    @State private var image: NSImage?

    /// Re-render only when something that affects the bitmap changes — not on every hover/scroll.
    private var renderKey: Int {
        var h = Hasher()
        h.combine(creative.imageToken)   // base-bitmap identity (filename+ratio+version+status)
        h.combine(showText); if showText { h.combine(creative.textLayers) }
        return h.finalize()
    }

    /// Cache-only best guess shown instantly (no disk read, no render) so switching back to an
    /// already-seen project/persona has no blank flash. The `.task` fills cold cases.
    private var instant: NSImage? {
        if showText, let p = store.cachedPreview(for: creative) { return p }
        guard let url = store.generatedImageURL(for: creative, in: projectID) else { return nil }
        return ImageStore.shared.cached(url)
    }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                if let shown = image ?? instant {
                    Image(nsImage: shown).resizable().scaledToFill()
                        .frame(width: geo.size.width, height: geo.size.height).clipped()
                } else {
                    Theme.surface2
                }
            }
            .task(id: renderKey) {
                image = await store.displayImage(for: creative, in: projectID, showText: showText)
            }
        }
    }
}

/// Inspector preview that lets the user select, DRAG, resize and edit the hook text on the image.
/// Shows the bare base bitmap with an interactive `TextLayerCanvas` on top; edits commit to the
/// store, which re-renders the baked bitmap.
struct DraggableAdView: View {
    let creative: Creative
    let projectID: UUID
    @EnvironmentObject var store: AppStore

    @State private var selectedID: UUID?
    @State private var base: NSImage?

    /// `imageToken` is the single source of base-bitmap identity (filename+ratio+version+status),
    /// so reloading on it never drifts from the list card or the preview cache.
    private var baseKey: Int { creative.imageToken }

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width, h = geo.size.height
            let hasText = creative.textLayers.contains { !CopyText.clean($0.text).isEmpty }
            ZStack(alignment: .topLeading) {
                // Base image — loaded once (cached, off-main) so editing text never re-reads disk.
                if let base {
                    Image(nsImage: base).resizable().scaledToFill().frame(width: w, height: h).clipped()
                } else { Theme.surface2 }

                TextLayerCanvas(creative: creative, projectID: projectID, selectedID: $selectedID, w: w, h: h)
            }
            .frame(width: w, height: h)
            .contentShape(Rectangle())
            .onTapGesture { selectedID = nil }   // tap empty canvas to deselect
            .task(id: baseKey) {
                base = await store.displayImage(for: creative, in: projectID, showText: false)
            }
            .help(hasText ? "Click to select · drag to move · drag corners to resize · double-click to edit" : "")
        }
    }
}

/// Hook text with its highlight word emphasised in accent (for the card/inspector text rows).
func highlightedHook(_ hook: String, _ highlight: String) -> AttributedString {
    var str = AttributedString(CopyText.clean(hook))
    for term in CopyText.highlightTerms(highlight) {
        if let range = str.range(of: term, options: .caseInsensitive) {
            str[range].foregroundColor = Theme.accent
        }
    }
    return str
}
