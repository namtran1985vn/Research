import SwiftUI
import AppKit

/// Live, pannable preview of a placeholder *sample grid*. Each cell shows its reference photo
/// filling the cell; dragging a cell repositions which part of the photo is visible (pan only — the
/// photo always fills the cell). On release the offset is persisted and the store recomposes the flat
/// composite PNG, so the list-card thumbnail and any export match what's shown here.
///
/// Replaces `DraggableAdView` only for placeholder sample grids; generated/imported images keep using
/// `DraggableAdView` (with its editable text layers). Sample placeholders carry no visible text yet,
/// so this editor focuses purely on per-cell panning.
struct SampleGridEditor: View {
    let creative: Creative
    let projectID: UUID
    @EnvironmentObject var store: AppStore

    @State private var cellImages: [NSImage] = []
    /// While a drag is active: which cell, and the current finger translation (display px).
    @State private var drag: (index: Int, tx: CGFloat, ty: CGFloat)?
    /// Currently selected hook/text layer (shared with the TextLayerCanvas).
    @State private var selectedID: UUID?
    /// Currently focused cell for panning. A drag only moves the focused item, so cell-pan and
    /// hook-move never fight. `focusedCell` and `selectedID` are mutually exclusive — clicking one
    /// clears the other; clicks hit the topmost item, so overlaps resolve by z-order.
    @State private var focusedCell: Int?

    private var cols: Int { max(1, creative.sampleCols) }
    private var rows: Int { max(1, creative.sampleRows) }
    /// Reload the source photos only when the photo SET changes — not on pure offset edits.
    private var cellsKey: String { "\(creative.sampleRefs.joined(separator: "|"))#\(cols)x\(rows)" }

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width, h = geo.size.height
            let rsW = GridComposer.highResSize(creative.ratio.size).width
            let gap = rsW > 0 ? 12 * w / rsW : 3            // mirror the composite's hairline gaps
            let cellW = (w - gap * CGFloat(cols + 1)) / CGFloat(cols)
            let cellH = (h - gap * CGFloat(rows + 1)) / CGFloat(rows)
            ZStack(alignment: .topLeading) {
                Theme.surface2
                ForEach(Array(0..<(cols * rows)), id: \.self) { i in
                    cell(i, cellW: cellW, cellH: cellH)
                        .frame(width: cellW, height: cellH)
                        .overlay(RoundedRectangle(cornerRadius: 4)
                            .strokeBorder(focusedCell == i ? Theme.accent : .clear, lineWidth: 2))
                        .contextMenu { cellMenu(i) }
                        .offset(x: gap + CGFloat(i % cols) * (cellW + gap),
                                y: gap + CGFloat(i / cols) * (cellH + gap))
                }

                // Interactive hook/text overlay on top of the cells. It has no full-size background,
                // so empty space still reaches the cells underneath; only the text boxes + handles
                // take hits. `requireSelectToMove` means a hook only moves once clicked, so it never
                // fights the cell-pan when they overlap.
                TextLayerCanvas(creative: creative, projectID: projectID,
                                selectedID: $selectedID, requireSelectToMove: true, w: w, h: h)
            }
            .frame(width: w, height: h)
            .onChange(of: selectedID) { _, id in if id != nil { focusedCell = nil } }   // hook ↔ cell exclusive
        }
        .task(id: cellsKey) { await loadCells() }
    }

    @ViewBuilder
    private func cell(_ i: Int, cellW: CGFloat, cellH: CGFloat) -> some View {
        if let img = cellImages.indices.contains(i) ? cellImages[i] : nil {
            let iw = CGFloat(img.pixelWidth), ih = CGFloat(img.pixelHeight)
            let scale = max(cellW / iw, cellH / ih)
            let dw = iw * scale, dh = ih * scale
            let ovX = max(0, dw - cellW), ovY = max(0, dh - cellH)   // pannable slack per axis
            let stored = storedOffset(i)
            let baseX = stored.x * ovX / 2, baseY = stored.y * ovY / 2
            let active = drag?.index == i
            let px = clamp(baseX + (active ? drag!.tx : 0), -ovX / 2, ovX / 2)
            let py = clamp(baseY + (active ? drag!.ty : 0), -ovY / 2, ovY / 2)
            Color.clear
                .frame(width: cellW, height: cellH)
                .overlay(Image(nsImage: img).resizable().frame(width: dw, height: dh).offset(x: px, y: py))
                .clipShape(RoundedRectangle(cornerRadius: 4))
                .contentShape(Rectangle())
                .onTapGesture { focusedCell = i; selectedID = nil }   // click a cell to focus it
                .gesture(
                    DragGesture(minimumDistance: 2)
                        .onChanged { v in
                            focusedCell = i; selectedID = nil   // dragging a cell focuses + pans it directly
                            drag = (i, v.translation.width, v.translation.height)
                        }
                        .onEnded { v in
                            let fx = ovX > 0 ? clamp(baseX + v.translation.width, -ovX / 2, ovX / 2) / (ovX / 2) : 0
                            let fy = ovY > 0 ? clamp(baseY + v.translation.height, -ovY / 2, ovY / 2) / (ovY / 2) : 0
                            drag = nil
                            store.setCellOffset(project: projectID, creative: creative.id,
                                                index: i, offset: CGPoint(x: fx, y: fy))
                        }
                )
                .help((ovX > 1 || ovY > 1) ? "Drag to reposition this photo" : "")
        } else {
            RoundedRectangle(cornerRadius: 4).fill(Theme.surface)
        }
    }

    /// Right-click actions for a single cell — re-roll its photo, or recenter its pan.
    @ViewBuilder
    private func cellMenu(_ i: Int) -> some View {
        Button {
            store.reSampleCell(project: projectID, creative: creative.id, index: i)
        } label: { Label("Re-sample this cell", systemImage: "arrow.triangle.2.circlepath") }
        if storedOffset(i) != .zero {
            Button {
                store.setCellOffset(project: projectID, creative: creative.id, index: i, offset: .zero)
            } label: { Label("Recenter photo", systemImage: "scope") }
        }
    }

    private func storedOffset(_ i: Int) -> CGPoint {
        creative.sampleOffsets.indices.contains(i) ? creative.sampleOffsets[i] : .zero
    }
    private func clamp(_ v: CGFloat, _ lo: CGFloat, _ hi: CGFloat) -> CGFloat { min(hi, max(lo, v)) }

    private func loadCells() async {
        let refs = creative.sampleRefs
        guard !refs.isEmpty else { cellImages = []; return }
        // Read the reference photos (small set), decode off-main — same pattern as the builder.
        let datas = ProjectStore.shared.referenceImageData(projectID: projectID, filenames: refs)
        cellImages = await Task.detached { datas.compactMap { NSImage(data: $0) } }.value
    }
}
