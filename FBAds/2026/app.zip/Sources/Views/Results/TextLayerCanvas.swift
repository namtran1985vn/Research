import SwiftUI
import AppKit

/// Captures the fixed geometry at the moment a corner-resize begins.
private struct ResizeSession {
    var startFont: Double
    var startBox: CGSize     // rendered text-box size in px
    var anchor: CGPoint      // the opposite corner, kept fixed (px)
    var corner0: CGPoint     // the dragged corner's start position (px)
    var dir: CGSize          // outward direction of the dragged corner
}

/// Reads the rendered size of each hook-text layer (keyed by layer id) so resize can anchor the
/// opposite corner and drag can clamp to the canvas — one entry per visible layer.
private struct HookSizeKey: PreferenceKey {
    static var defaultValue: [UUID: CGSize] = [:]
    static func reduce(value: inout [UUID: CGSize], nextValue: () -> [UUID: CGSize]) {
        value.merge(nextValue()) { _, new in new }
    }
}

/// Interactive hook/text layer overlay: renders a creative's text layers on top of whatever base
/// view it is stacked over, and lets each be selected, moved, corner-resized and edited
/// (double-click). The single source of truth for on-image text editing — reused by both
/// `DraggableAdView` (over a flat rendered image) and `SampleGridEditor` (over the pannable sample
/// cells).
///
/// Gesture-coexistence contract (so it composes cleanly over other draggable content beneath it):
/// • It has **no full-size hit-testable background** — empty space passes straight through to the
///   base view (e.g. the pannable cells), so their drags still work. Only the small text boxes and
///   corner handles take hits.
/// • A drag is owned by the view where it *begins*: starting on a text box moves the text; starting
///   on empty space reaches the base view's own gesture. The two never fire together.
/// • `selectedID` is a `@Binding` owned by the container, so the base view can clear the selection
///   ("tap empty → deselect") without this overlay needing to swallow background taps.
struct TextLayerCanvas: View {
    let creative: Creative
    let projectID: UUID
    @Binding var selectedID: UUID?
    /// When true, a layer only moves while it is the *selected* one — the user must click it first.
    /// Used over the sample grid so a hook-drag never fights the cell-pan when they overlap. When
    /// false (generated images, no cells beneath) a drag also selects, so move is one motion.
    var requireSelectToMove: Bool = false
    /// The image rect this overlay sits on. Passed in from the parent's GeometryReader (NOT measured
    /// by a nested one) so text position + the move math share the EXACT coordinates of the base.
    let w: CGFloat
    let h: CGFloat
    @EnvironmentObject var store: AppStore

    // Live state during a move/resize/edit gesture (committed to the store on release).
    @State private var editing = false
    @State private var draft = ""
    @State private var editLayerID: UUID?
    @State private var livePos: CGPoint?
    @State private var liveFont: Double?
    @State private var boxSizes: [UUID: CGSize] = [:]
    @State private var resize: ResizeSession?
    @FocusState private var focused: Bool

    var body: some View {
        let scale = w / 1024
        let visible = creative.textLayers.filter { !CopyText.clean($0.text).isEmpty }
        ZStack(alignment: .topLeading) {
            ForEach(visible) { layer in
                if !(editing && editLayerID == layer.id) {
                    textObject(layer: layer, scale: scale, w: w, h: h)
                }
            }

            if editing, let id = editLayerID, let layer = creative.textLayers.first(where: { $0.id == id }) {
                let boxW = max(160, w * 0.6)
                TextEditor(text: $draft)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.ink)
                    .scrollContentBackground(.hidden)
                    .frame(minHeight: 44, maxHeight: 120)
                    .focused($focused)
                    .padding(10)
                    .frame(width: boxW)
                    .background(Color.white)
                    .overlay(RoundedRectangle(cornerRadius: 10).strokeBorder(Theme.accent, lineWidth: 1.5))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .popShadow()
                    // ⌘↩ commits — carried by a hidden button so the shortcut still fires.
                    .background(Button("") { commit() }.keyboardShortcut(.return, modifiers: .command).opacity(0))
                    .onExitCommand { cancel() }   // Esc cancels
                    .offset(x: min(w * layer.xFrac, w - boxW - 6), y: min(h * layer.yFrac, h - 90))
            }
        }
        .frame(width: w, height: h, alignment: .topLeading)
        .onPreferenceChange(HookSizeKey.self) { boxSizes = $0 }
        .onChange(of: focused) { _, isFocused in if !isFocused { commit() } }
    }

    // MARK: Live text object (select / move / resize / edit)

    private func textObject(layer: TextLayer, scale: CGFloat, w: CGFloat, h: CGFloat) -> some View {
        let isSelected = selectedID == layer.id
        var disp = layer
        // Live font/pos apply only to the layer currently being dragged/resized.
        disp.fontSize = (isSelected ? liveFont : nil) ?? layer.fontSize
        let curPos = (isSelected ? livePos : nil) ?? CGPoint(x: layer.xFrac, y: layer.yFrac)
        let box = boxSizes[layer.id] ?? .zero

        // The text box carries SELECT + MOVE. Handles are layered on AFTER (and on top), so a
        // press on a handle never reaches the move gesture underneath.
        let block = HookText(layer: disp, scale: scale, containerWidth: w)
            .background(GeometryReader { p in
                Color.clear.preference(key: HookSizeKey.self, value: [layer.id: p.size])
            })
            .overlay(
                RoundedRectangle(cornerRadius: 3)
                    .strokeBorder(Theme.accent, style: StrokeStyle(lineWidth: isSelected ? 1.5 : 0, dash: [4, 3]))
            )
            .contentShape(Rectangle())
            .onTapGesture(count: 2) { startEditing(layer) }
            .onTapGesture { selectedID = layer.id }
            .gesture(
                DragGesture(minimumDistance: 2, coordinateSpace: .global)
                    .onChanged { v in
                        if requireSelectToMove {
                            guard selectedID == layer.id else { return }   // click to select before moving
                        } else {
                            selectedID = layer.id
                        }
                        let nx = (layer.xFrac * w + v.translation.width) / w
                        let ny = (layer.yFrac * h + v.translation.height) / h
                        let maxX = max(0, 1 - box.width / w)
                        let maxY = max(0, 1 - box.height / h)
                        livePos = CGPoint(x: min(max(0, nx), maxX), y: min(max(0, ny), maxY))
                    }
                    .onEnded { _ in
                        if let lp = livePos {
                            store.moveTextLayer(project: projectID, creative: creative.id,
                                                layerID: layer.id, x: lp.x, y: lp.y)
                        }
                        livePos = nil
                    }
            )

        return block
            .overlay(alignment: .topLeading)     { handle(.tl, w: w, h: h, layer: layer) }
            .overlay(alignment: .topTrailing)    { handle(.tr, w: w, h: h, layer: layer) }
            .overlay(alignment: .bottomLeading)  { handle(.bl, w: w, h: h, layer: layer) }
            .overlay(alignment: .bottomTrailing) { handle(.br, w: w, h: h, layer: layer) }
            .offset(x: w * curPos.x, y: h * curPos.y)
    }

    private enum Corner {
        case tl, tr, bl, br
        var dir: CGSize {
            switch self {
            case .tl: return CGSize(width: -1, height: -1)
            case .tr: return CGSize(width:  1, height: -1)
            case .bl: return CGSize(width: -1, height:  1)
            case .br: return CGSize(width:  1, height:  1)
            }
        }
    }

    @ViewBuilder
    private func handle(_ corner: Corner, w: CGFloat, h: CGFloat, layer: TextLayer) -> some View {
        if selectedID == layer.id {
            let dot: CGFloat = 12, hit: CGFloat = 28
            let dir = corner.dir
            Circle()
                .fill(Color.white)
                .overlay(Circle().strokeBorder(Theme.accent, lineWidth: 1.5))
                .frame(width: dot, height: dot)
                .shadow(color: .black.opacity(0.25), radius: 1.5, y: 0.5)
                .frame(width: hit, height: hit)
                .contentShape(Circle())
                .offset(x: dir.width * hit / 2, y: dir.height * hit / 2)
                .onHover { inside in if inside { NSCursor.crosshair.push() } else { NSCursor.pop() } }
                .gesture(
                    DragGesture(minimumDistance: 0, coordinateSpace: .global)
                        .onChanged { v in
                            selectedID = layer.id
                            let s = resize ?? beginResize(corner: corner, layer: layer, w: w, h: h)
                            if resize == nil { resize = s }
                            applyResize(s, translation: v.translation, w: w, h: h)
                        }
                        .onEnded { _ in
                            if let nf = liveFont, let lp = livePos {
                                store.resizeTextLayer(project: projectID, creative: creative.id,
                                                      layerID: layer.id, fontSize: nf, x: lp.x, y: lp.y)
                            }
                            resize = nil; liveFont = nil; livePos = nil
                        }
                )
                .zIndex(1)
        }
    }

    private func beginResize(corner: Corner, layer: TextLayer, w: CGFloat, h: CGFloat) -> ResizeSession {
        let dir = corner.dir
        let tl = CGPoint(x: layer.xFrac * w, y: layer.yFrac * h)
        let measured = boxSizes[layer.id] ?? .zero
        let box = measured == .zero ? CGSize(width: 1, height: 1) : measured
        let anchor = CGPoint(x: dir.width  < 0 ? tl.x + box.width  : tl.x,
                             y: dir.height < 0 ? tl.y + box.height : tl.y)
        let corner0 = CGPoint(x: dir.width  < 0 ? tl.x : tl.x + box.width,
                              y: dir.height < 0 ? tl.y : tl.y + box.height)
        return ResizeSession(startFont: layer.fontSize, startBox: box, anchor: anchor, corner0: corner0, dir: dir)
    }

    private func applyResize(_ s: ResizeSession, translation t: CGSize, w: CGFloat, h: CGFloat) {
        let newCorner = CGPoint(x: s.corner0.x + t.width, y: s.corner0.y + t.height)
        let newW = abs(newCorner.x - s.anchor.x), newH = abs(newCorner.y - s.anchor.y)
        let startDiag = max(1, hypot(s.startBox.width, s.startBox.height))
        let factor = hypot(newW, newH) / startDiag
        let nf = min(140, max(24, (s.startFont * factor).rounded()))
        // Predicted new box (text hugs → scales ~linearly with font), used to keep the anchor fixed.
        let predW = s.startBox.width  * nf / s.startFont
        let predH = s.startBox.height * nf / s.startFont
        var tlx = s.dir.width  < 0 ? s.anchor.x - predW : s.anchor.x
        var tly = s.dir.height < 0 ? s.anchor.y - predH : s.anchor.y
        tlx = min(max(0, tlx), max(0, w - predW))
        tly = min(max(0, tly), max(0, h - predH))
        liveFont = nf
        livePos = CGPoint(x: tlx / w, y: tly / h)
    }

    private func startEditing(_ layer: TextLayer) {
        guard !editing else { return }
        editLayerID = layer.id
        draft = layer.text
        editing = true
        selectedID = nil
        focused = true
    }

    private func commit() {
        guard editing, let id = editLayerID else { return }
        editing = false
        store.editHookText(project: projectID, creative: creative.id, layerID: id, text: draft)
        editLayerID = nil
    }

    /// Discard edits and close. Flip `editing` off FIRST so the focus-loss `commit()` no-ops.
    private func cancel() {
        guard editing else { return }
        editing = false
        editLayerID = nil
        draft = ""
        focused = false
    }
}
