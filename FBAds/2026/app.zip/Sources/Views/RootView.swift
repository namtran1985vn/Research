import SwiftUI

struct RootView: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        HStack(spacing: 0) {
            if store.sidebarOpen {
                SidebarView()
                    .frame(width: 244)
                    .transition(.move(edge: .leading).combined(with: .opacity))
            }

            VStack(spacing: 0) {
                ToolbarBar()
                Divider().overlay(Theme.border)
                HStack(spacing: 0) {
                    Group {
                        if store.screen == .input {
                            InputScreen()
                        } else {
                            ResultsView()
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)

                    if store.screen == .results && store.inspectorOpen {
                        Divider().overlay(Theme.borderStrong)
                        InspectorView()
                            .frame(width: 460)
                    }
                }
            }
            .background(Theme.bgWindow)
        }
        .background(Theme.bgWindow)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .overlay(alignment: .bottom) {
            if let toast = store.toast { ToastView(toast: toast).padding(.bottom, 20) }
        }
        .sheet(item: $store.activeSheet) { sheet in
            switch sheet {
            case .settings: SettingsSheet()
            case .ranking:  PersonaRankingSheet()
            case .regenerateProject(let id): RegenerateProjectSheet(projectID: id, mode: .regenerate)
            case .duplicateProject(let id): RegenerateProjectSheet(projectID: id, mode: .duplicate)
            case .regeneratePersona(let pid, let personaID): RegeneratePersonaSheet(projectID: pid, personaID: personaID)
            }
        }
        .animation(.easeInOut(duration: 0.22), value: store.inspectorOpen)
        .animation(.easeInOut(duration: 0.22), value: store.sidebarOpen)
        .animation(.easeOut(duration: 0.2), value: store.toast)
    }
}
