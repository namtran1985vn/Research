import AppKit

/// Composites Vietnamese/English text layers onto the AI-generated base image, producing the
/// final 1024×1280 ad. Used by both the S3 editor preview and the export pipeline.
/// (Mechanism (b): the image model leaves negative space, the app renders clean text.)
enum TextRenderer {
    static let canvas = NSSize(width: 1024, height: 1280)

    static func composite(base: NSImage, layers: [TextLayer], font: String,
                          size: NSSize = NSSize(width: 1024, height: 1280)) -> NSImage {
        let out = NSImage(size: size)
        out.lockFocus()
        NSGraphicsContext.current?.imageInterpolation = .high

        // Aspect-fill the base into the canvas.
        base.draw(in: NSRect(origin: .zero, size: size), from: .zero, operation: .copy, fraction: 1.0)

        for layer in layers { draw(layer, defaultFont: font, size: size) }

        out.unlockFocus()
        return out
    }

    private static func draw(_ layer: TextLayer, defaultFont: String, size: NSSize) {
        let layerText = CopyText.clean(layer.text)
        let highlightTerms = CopyText.highlightTerms(layer.highlightWord)
        guard !layerText.isEmpty else { return }
        let w = size.width
        let h = size.height

        let fontSize = CGFloat(layer.fontSize)
        let baseFont = resolveFont(layer.fontName.isEmpty ? defaultFont : layer.fontName,
                                   size: fontSize, bold: layer.bold, italic: layer.italic)

        let para = NSMutableParagraphStyle()
        switch layer.alignment {
        case "center": para.alignment = .center
        case "trailing": para.alignment = .right
        default: para.alignment = .left
        }
        para.lineHeightMultiple = 1.05
        // Portrait hang-tag stamps: generous line spacing so multiline text breathes.
        if layer.hookStyle == .stamp {
            let stampAspect = Stamps.at(layer.stampVariant).map { $0.size.width / max(1, $0.size.height) } ?? 1
            if stampAspect < 0.75 { para.lineHeightMultiple = 1.4 }
        }

        // Explicit per-layer text color (the style preset seeds it; the user can override it).
        let textColor = NSColor(srgbHex: layer.colorHex)
        var attrs: [NSAttributedString.Key: Any] = [
            .font: baseFont,
            .foregroundColor: textColor,
            .paragraphStyle: para,
        ]
        if layer.hookStyle == .annotation {
            // Annotation: a thin WHITE outline hugging every glyph (no shadow) so the handwriting
            // pops off any photo while the dark ink stays dark, like a marker note with a white edge.
            attrs[.strokeColor] = NSColor.white
            attrs[.strokeWidth] = -5.0
        } else if !layer.shadow {
            // No box (Clean Float): keep text legible with a contrasting outline + a soft, wide dark
            // halo behind the glyphs — the "gradient tối mờ sau chữ" that lifts it off the photo.
            attrs[.strokeColor] = NSColor(srgbHex: ReadableInk.outlineHex(forText: layer.colorHex))
            attrs[.strokeWidth] = -7.0
            let sh = NSShadow()
            sh.shadowColor = NSColor.black.withAlphaComponent(0.6)
            sh.shadowOffset = NSSize(width: 0, height: -fontSize * 0.04)
            sh.shadowBlurRadius = fontSize * 0.20
            attrs[.shadow] = sh
        }

        let string = NSMutableAttributedString(string: layerText, attributes: attrs)
        // Highlight words — accent color + italic. Supports several comma-separated terms.
        let italicFont = NSFontManager.shared.convert(baseFont, toHaveTrait: .italicFontMask) as NSFont?
        let ns = layerText as NSString
        for term in highlightTerms {
            let range = ns.range(of: term, options: .caseInsensitive)
            if range.location != NSNotFound {
                string.addAttribute(.foregroundColor, value: NSColor(srgbHex: layer.highlightColorHex), range: range)
                if let italicFont { string.addAttribute(.font, value: italicFont, range: range) }
            }
        }

        let boxWidth = w * CGFloat(layer.widthFrac)
        // Measure the text hugging tightly (width returns the actual used width, ≤ boxWidth).
        let bounding = string.boundingRect(with: NSSize(width: boxWidth, height: .greatestFiniteMagnitude),
                                           options: [.usesLineFragmentOrigin, .usesFontLeading])
        let textWidth = ceil(bounding.width)
        let textHeight = ceil(bounding.height)
        let originX = w * CGFloat(layer.xFrac)
        // yFrac is measured from the TOP; AppKit draws from bottom-left.
        let originYTop = h * CGFloat(layer.yFrac)

        // Authentic styles draw their own background / decoration (PNG paper, PNG stamp, vector
        // chat bubble, hand-drawn mark) instead of the plain caption box — dispatch them here.
        switch layer.hookStyle {
        case .stickyNote:
            drawStickyNote(string, textWidth: textWidth, textHeight: textHeight,
                           originXTop: originX, originYTop: originYTop,
                           fontSize: fontSize, canvasH: h, seed: StickyNote.seed(for: layer.id))
            return
        case .stamp:
            drawStamp(string, textWidth: textWidth, textHeight: textHeight,
                      originXTop: originX, originYTop: originYTop,
                      fontSize: fontSize, canvasH: h, variant: layer.stampVariant,
                      seed: StickyNote.seed(for: layer.id))
            return
        case .chatBubble:
            drawChatBubble(string, textWidth: textWidth, textHeight: textHeight,
                           originXTop: originX, originYTop: originYTop,
                           fontSize: fontSize, canvasH: h, fillHex: layer.boxColorHex)
            return
        case .annotation:
            drawAnnotation(string, textWidth: textWidth, textHeight: textHeight,
                           originXTop: originX, originYTop: originYTop,
                           fontSize: fontSize, canvasH: h, kind: layer.annotationKind)
            return
        default: break
        }

        // Caption box: text on a sharp-cornered box. The TikTok style adds a cyan top+left border
        // and a hot-pink bottom+right border; Normal styles are a plain box. Padding mirrors HookText.
        if layer.shadow {
            let style = layer.hookStyle
            let padH = fontSize * 0.40
            let padV = fontSize * 0.26
            let bw = max(4, fontSize * 0.17)
            let boxW = textWidth + padH * 2
            let boxH = textHeight + padV * 2
            let boxX = originX
            let boxY = h - originYTop - boxH
            let boxRect = NSRect(x: boxX, y: boxY, width: boxW, height: boxH)

            // Premium presets soften the box (rounded corners) and may use a semi-transparent scrim.
            let radius = fontSize * style.cornerRadiusFactor
            NSColor(srgbHex: layer.boxColorHex, alpha: style.boxOpacity).setFill()
            if radius > 0 {
                NSBezierPath(roundedRect: boxRect, xRadius: radius, yRadius: radius).fill()
            } else {
                boxRect.fill()
            }

            if style.hasBorders {
                NSColor(srgbHex: 0x00D6D6).setFill()
                NSRect(x: boxX, y: boxY + boxH - bw, width: boxW, height: bw).fill()  // top
                NSRect(x: boxX, y: boxY, width: bw, height: boxH).fill()              // left
                NSColor(srgbHex: 0xFF2B5F).setFill()
                NSRect(x: boxX, y: boxY, width: boxW, height: bw).fill()              // bottom
                NSRect(x: boxX + boxW - bw, y: boxY, width: bw, height: boxH).fill()  // right
            }

            if style.hasDashedBorder {
                let lw = max(2, fontSize * 0.07)
                let path = NSBezierPath(rect: boxRect.insetBy(dx: lw / 2, dy: lw / 2))
                path.lineWidth = lw
                path.setLineDash([max(4, fontSize * 0.24), max(3, fontSize * 0.16)], count: 2, phase: 0)
                NSColor(srgbHex: layer.colorHex).setStroke()
                path.stroke()
            }

            let drawRect = NSRect(x: boxX + padH, y: h - originYTop - padV - textHeight,
                                  width: textWidth, height: textHeight)
            string.draw(with: drawRect, options: [.usesLineFragmentOrigin, .usesFontLeading])
        } else {
            let drawRect = NSRect(x: originX, y: h - originYTop - textHeight, width: boxWidth, height: textHeight)
            string.draw(with: drawRect, options: [.usesLineFragmentOrigin, .usesFontLeading])
        }
    }

    private static func resolveFont(_ name: String, size: CGFloat, bold: Bool, italic: Bool = false) -> NSFont {
        var f = NSFont(name: name, size: size) ?? NSFont.systemFont(ofSize: size, weight: bold ? .bold : .regular)
        if bold { f = NSFontManager.shared.convert(f, toHaveTrait: .boldFontMask) }
        if italic { f = NSFontManager.shared.convert(f, toHaveTrait: .italicFontMask) }
        return f
    }

    /// Draws the "Sticky Note" treatment: a real paper PNG (chosen deterministically per layer),
    /// tilted a few degrees with a soft drop shadow so it lifts off the photo, then the handwriting
    /// rendered on top. `seed` keeps the chosen paper + tilt stable across re-renders of the same layer.
    private static func drawStickyNote(_ string: NSAttributedString,
                                       textWidth: CGFloat, textHeight: CGFloat,
                                       originXTop: CGFloat, originYTop: CGFloat,
                                       fontSize: CGFloat, canvasH: CGFloat, seed: Int) {
        // Generous margins — a hand-written note has lots of blank paper around the words.
        let padH = fontSize * 0.70
        let padV = fontSize * 0.60
        let boxW = textWidth + padH * 2
        let boxH = textHeight + padV * 2
        let boxX = originXTop
        let boxY = canvasH - originYTop - boxH
        let rect = NSRect(x: boxX, y: boxY, width: boxW, height: boxH)
        let center = NSPoint(x: rect.midX, y: rect.midY)
        let angle = CGFloat(StickyNote.tiltDegrees(seed: seed))

        guard let ctx = NSGraphicsContext.current else { return }
        ctx.saveGraphicsState()                              // outer: holds the rotation

        // Rotate the whole note (paper + ink) around its centre.
        let t = NSAffineTransform()
        t.translateX(by: center.x, yBy: center.y)
        t.rotate(byDegrees: angle)
        t.translateX(by: -center.x, yBy: -center.y)
        t.concat()

        // Soft drop shadow, applied only to the paper (inner save/restore clears it before the ink).
        ctx.saveGraphicsState()
        let sh = NSShadow()
        sh.shadowColor = NSColor.black.withAlphaComponent(0.33)
        sh.shadowOffset = NSSize(width: fontSize * 0.10, height: -fontSize * 0.14)
        sh.shadowBlurRadius = fontSize * 0.38
        sh.set()
        if let paper = StickyNote.pick(seed: seed) {
            paper.draw(in: rect, from: .zero, operation: .sourceOver, fraction: 1.0)
        } else {
            // No real PNGs bundled yet → plain note-yellow card so the style still renders.
            NSColor(srgbHex: HookPalette.noteYellow).setFill()
            NSBezierPath(roundedRect: rect, xRadius: fontSize * 0.04, yRadius: fontSize * 0.04).fill()
        }
        ctx.restoreGraphicsState()                           // drops the shadow, keeps the rotation

        // Flat ink, NO text shadow — the shadow belongs to the paper, never the glyphs, so the text
        // reads as written-on rather than floating above the note.
        let drawRect = NSRect(x: boxX + padH, y: boxY + padV, width: textWidth, height: textHeight)
        string.draw(with: drawRect, options: [.usesLineFragmentOrigin, .usesFontLeading])

        ctx.restoreGraphicsState()                           // drops the rotation
    }

    /// Stamp: a real craft-stamp / badge / hang-tag PNG (chosen per layer) with the (short) text
    /// centred on it, tilted slightly. PNG aspect is preserved so the stamp never distorts.
    private static func drawStamp(_ string: NSAttributedString,
                                  textWidth: CGFloat, textHeight: CGFloat,
                                  originXTop: CGFloat, originYTop: CGFloat,
                                  fontSize: CGFloat, canvasH: CGFloat, variant: Int, seed: Int) {
        guard let ctx = NSGraphicsContext.current else { return }
        let stamp = Stamps.at(variant)
        let aspect: CGFloat = stamp.map { $0.size.width / max(1, $0.size.height) } ?? 1
        // Portrait hang-tag (aspect < 0.75): rectangular body, ~65% usable width, ~58% usable height.
        // Round/badge (aspect ≥ 0.75): inscribe text diagonal in the stamp's inner circle.
        let isPortrait = aspect < 0.75
        let stampW: CGFloat
        let stampH: CGFloat
        if isPortrait {
            let wFromWidth  = textWidth  / 0.65
            let wFromHeight = (textHeight / 0.615) * aspect
            stampW = max(wFromWidth, wFromHeight)
            stampH = stampW / aspect
        } else {
            let diag = (textWidth * textWidth + textHeight * textHeight).squareRoot()
            stampW = diag / 0.80
            stampH = stampW / aspect
        }
        let boxX = originXTop
        let boxY = canvasH - originYTop - stampH
        let rect = NSRect(x: boxX, y: boxY, width: stampW, height: stampH)
        let rotationCenter = NSPoint(x: rect.midX, y: rect.midY)
        // Body starts at 35.5% from PNG top (pixel-measured); body centre = 66.3% from top.
        // In AppKit (y=0 at bottom): body centre = 1 – 0.663 = 0.337 × stampH from minY.
        let textCenterY = rect.minY + stampH * (isPortrait ? 0.337 : 0.50)
        let center = NSPoint(x: rect.midX, y: textCenterY)
        let angle = CGFloat(-1.0 - Double(abs(seed) % 4))    // pressed slightly off-square

        ctx.saveGraphicsState()
        let t = NSAffineTransform()
        t.translateX(by: rotationCenter.x, yBy: rotationCenter.y)
        t.rotate(byDegrees: angle)
        t.translateX(by: -rotationCenter.x, yBy: -rotationCenter.y)
        t.concat()

        ctx.saveGraphicsState()
        let sh = NSShadow()
        sh.shadowColor = NSColor.black.withAlphaComponent(0.28)
        sh.shadowOffset = NSSize(width: fontSize * 0.06, height: -fontSize * 0.08)
        sh.shadowBlurRadius = fontSize * 0.30
        sh.set()
        if let stamp {
            stamp.draw(in: rect, from: .zero, operation: .sourceOver, fraction: 1.0)
        } else {
            // Fallback: a simple double-ring stamp in stamp-red until PNGs are bundled.
            NSColor(srgbHex: HookPalette.stampRed, alpha: 0.9).setStroke()
            let p = NSBezierPath(ovalIn: rect.insetBy(dx: rect.width * 0.05, dy: rect.height * 0.05))
            p.lineWidth = max(3, fontSize * 0.12); p.stroke()
        }
        ctx.restoreGraphicsState()                           // drops the shadow, keeps the rotation

        let drawRect = NSRect(x: center.x - textWidth / 2, y: center.y - textHeight / 2,
                              width: textWidth, height: textHeight)
        string.draw(with: drawRect, options: [.usesLineFragmentOrigin, .usesFontLeading])
        ctx.restoreGraphicsState()                           // drops the rotation
    }

    /// Chat Bubble: a real iMessage-style bubble PNG, nine-sliced so the corners + tail never distort,
    /// with the text inside the body (above the bottom-left tail). Falls back to a vector bubble.
    private static func drawChatBubble(_ string: NSAttributedString,
                                       textWidth: CGFloat, textHeight: CGFloat,
                                       originXTop: CGFloat, originYTop: CGFloat,
                                       fontSize: CGFloat, canvasH: CGFloat, fillHex: UInt) {
        guard let ctx = NSGraphicsContext.current else { return }
        let padH = fontSize * 0.20, padV = fontSize * 0.12
        if let bubble = ChatBubbles.first {
            let corner = fontSize * 0.42
            let caps = ChatBubbles.caps(bubble, corner: corner)
            let bubbleW = textWidth + caps.left + caps.right + padH * 2
            let bubbleH = textHeight + caps.top + caps.bottom + padV * 2
            let bubbleY = canvasH - originYTop - bubbleH
            let rect = NSRect(x: originXTop, y: bubbleY, width: bubbleW, height: bubbleH)
            // Pre-slice into one image so the drop shadow is cast by the whole bubble (not 9 pieces).
            let img = ChatBubbles.sliced(bubble, size: rect.size, corner: corner)
            ctx.saveGraphicsState()
            let sh = NSShadow()
            sh.shadowColor = NSColor.black.withAlphaComponent(0.16)
            sh.shadowOffset = NSSize(width: 0, height: -fontSize * 0.04)
            sh.shadowBlurRadius = fontSize * 0.12
            sh.set()
            img.draw(in: rect, from: .zero, operation: .sourceOver, fraction: 1.0)
            ctx.restoreGraphicsState()
            // Text in the body interior, above the tail (which lives in the bottom-left cap).
            let drawRect = NSRect(x: originXTop + caps.left + padH, y: bubbleY + caps.bottom + padV,
                                  width: textWidth, height: textHeight)
            string.draw(with: drawRect, options: [.usesLineFragmentOrigin, .usesFontLeading])
            return
        }
        // Fallback: a simple rounded vector bubble if no PNG is bundled.
        let bubbleW = textWidth + padH * 4, bubbleH = textHeight + padV * 4
        let bubbleY = canvasH - originYTop - bubbleH
        let rect = NSRect(x: originXTop, y: bubbleY, width: bubbleW, height: bubbleH)
        NSColor(srgbHex: fillHex).setFill()
        NSBezierPath(roundedRect: rect, xRadius: fontSize * 0.45, yRadius: fontSize * 0.45).fill()
        let drawRect = NSRect(x: rect.minX + padH * 2, y: rect.minY + padV * 2, width: textWidth, height: textHeight)
        string.draw(with: drawRect, options: [.usesLineFragmentOrigin, .usesFontLeading])
    }

    /// Annotation: handwriting text (with its legibility halo) plus a hand-drawn mark — an underline
    /// beneath, a scribbled circle around, or an arrow beside it — depending on the layer's kind.
    private static func drawAnnotation(_ string: NSAttributedString,
                                       textWidth: CGFloat, textHeight: CGFloat,
                                       originXTop: CGFloat, originYTop: CGFloat,
                                       fontSize: CGFloat, canvasH: CGFloat, kind: AnnotationKind) {
        let textX = originXTop
        let textBottomY = canvasH - originYTop - textHeight
        let mark = Annotations.image(kind)
        let textRect = NSRect(x: textX, y: textBottomY, width: textWidth, height: textHeight)

        func drawMark(in rect: NSRect) {
            guard let mark else { return }
            // Thin WHITE outline hugging the mark (8 offset white silhouettes), then the coloured mark.
            if let white = Annotations.whiteImage(kind) {
                let o = max(1.5, fontSize * 0.045)
                let dirs: [(CGFloat, CGFloat)] = [(-1, -1), (0, -1), (1, -1), (-1, 0),
                                                  (1, 0), (-1, 1), (0, 1), (1, 1)]
                for d in dirs {
                    white.draw(in: rect.offsetBy(dx: d.0 * o, dy: d.1 * o),
                               from: .zero, operation: .sourceOver, fraction: 1.0)
                }
            }
            mark.draw(in: rect, from: .zero, operation: .sourceOver, fraction: 1.0)
        }
        let mAspect: CGFloat = mark.map { $0.size.width / max(1, $0.size.height) } ?? 1

        switch kind {
        case .circle:
            // Ellipse behind the text.
            let cW = textWidth * 1.35
            let cH = max(cW / mAspect, textHeight * 1.5)
            drawMark(in: NSRect(x: textRect.midX - cW / 2, y: textRect.midY - cH / 2, width: cW, height: cH))
            string.draw(with: textRect, options: [.usesLineFragmentOrigin, .usesFontLeading])
        case .underline:
            string.draw(with: textRect, options: [.usesLineFragmentOrigin, .usesFontLeading])
            let uW = textWidth * 1.02
            let uH = uW / mAspect
            drawMark(in: NSRect(x: textX, y: textBottomY - uH * 0.55, width: uW, height: uH))
        case .arrow:
            string.draw(with: textRect, options: [.usesLineFragmentOrigin, .usesFontLeading])
            let aW = max(textWidth * 0.55, fontSize * 3)
            let aH = aW / mAspect
            // Arrow to the upper-right of the text, tip pointing out at a product detail.
            drawMark(in: NSRect(x: textX + textWidth * 0.88, y: textBottomY + textHeight * 0.35, width: aW, height: aH))
        }
    }
}

/// Loads the bundled sticky-note paper PNGs (Resources/StickyNotes/*.png) once and picks one
/// deterministically per layer. Shared by the AppKit export (TextRenderer) and the SwiftUI editor
/// (HookText) so on-screen and exported notes use the same paper + tilt. Empty until real note PNGs
/// are added — see that folder's README.
enum StickyNote {
    static let papers: [NSImage] = {
        let urls = Bundle.main.urls(forResourcesWithExtension: "png", subdirectory: "StickyNotes") ?? []
        return urls.sorted { $0.lastPathComponent < $1.lastPathComponent }
                   .compactMap { NSImage(contentsOf: $0) }
    }()

    /// Stable per-layer seed (same across launches) from the layer's UUID bytes.
    static func seed(for id: UUID) -> Int {
        withUnsafeBytes(of: id.uuid) { $0.reduce(0) { ($0 &* 31) &+ Int($1) } }
    }

    /// Seeded slight tilt: −2°…−6° (stuck on by hand, leaning left).
    static func tiltDegrees(seed: Int) -> Double { -2.0 - Double(abs(seed) % 5) }

    static func pick(seed: Int) -> NSImage? {
        guard !papers.isEmpty else { return nil }
        return papers[abs(seed) % papers.count]
    }
}

/// Bundled craft-stamp / badge / hang-tag PNGs (Resources/Stamps/*.png), chosen per layer by index.
enum Stamps {
    static let images: [NSImage] = {
        let urls = Bundle.main.urls(forResourcesWithExtension: "png", subdirectory: "Stamps") ?? []
        return urls.sorted { $0.lastPathComponent < $1.lastPathComponent }
                   .compactMap { NSImage(contentsOf: $0) }
    }()
    /// Friendly labels for the first few bundled stamps (extra files fall back to "Stamp N").
    static let labels = ["Ink Seal", "Badge", "Hang Tag"]
    static func label(_ i: Int) -> String { i < labels.count ? labels[i] : "Stamp \(i + 1)" }

    /// The stamp at `index` (clamped to the available range).
    static func at(_ index: Int) -> NSImage? {
        guard !images.isEmpty else { return nil }
        return images[min(max(0, index), images.count - 1)]
    }
}

/// Bundled Before/After arrow art (Resources/Arrows/*.png) — a red brush arrow pointing right,
/// drawn straddling the seam between each Before|After pair.
enum Arrows {
    static let image: NSImage? = {
        let urls = Bundle.main.urls(forResourcesWithExtension: "png", subdirectory: "Arrows") ?? []
        return urls.sorted { $0.lastPathComponent < $1.lastPathComponent }.compactMap { NSImage(contentsOf: $0) }.first
    }()
}

/// Bundled hand-drawn annotation marks (Resources/Annotations/<kind>.png), looked up by kind.
enum Annotations {
    static let byName: [String: NSImage] = {
        var d: [String: NSImage] = [:]
        for url in Bundle.main.urls(forResourcesWithExtension: "png", subdirectory: "Annotations") ?? [] {
            if let img = NSImage(contentsOf: url) { d[url.deletingPathExtension().lastPathComponent] = img }
        }
        return d
    }()
    /// White silhouettes of each mark (same alpha), used to paint a thin white outline behind the
    /// coloured mark so it pops off the photo like the handwriting does.
    static let whiteByName: [String: NSImage] = byName.mapValues { tintedWhite($0) }

    static func image(_ kind: AnnotationKind) -> NSImage? { byName[kind.asset] }
    static func whiteImage(_ kind: AnnotationKind) -> NSImage? { whiteByName[kind.asset] }

    /// Returns a white-tinted copy of `img` preserving its alpha (sourceAtop fills only opaque px).
    static func tintedWhite(_ img: NSImage) -> NSImage {
        let out = NSImage(size: img.size)
        out.lockFocus()
        img.draw(in: NSRect(origin: .zero, size: img.size))
        NSColor.white.set()
        NSRect(origin: .zero, size: img.size).fill(using: .sourceAtop)
        out.unlockFocus()
        return out
    }
}

/// Bundled chat-bubble PNGs (Resources/ChatBubbles/*.png) rendered as a resolution-independent
/// nine-slice: the rounded corners + the tail stay undistorted while the centre stretches to the text.
enum ChatBubbles {
    static let images: [NSImage] = {
        let urls = Bundle.main.urls(forResourcesWithExtension: "png", subdirectory: "ChatBubbles") ?? []
        return urls.sorted { $0.lastPathComponent < $1.lastPathComponent }.compactMap { NSImage(contentsOf: $0) }
    }()
    static var first: NSImage? { images.first }

    // Cap-inset fractions measured on the bundled bubble (rounded corners + bottom-left tail).
    static let topFrac: CGFloat = 0.21, bottomFrac: CGFloat = 0.32, leftFrac: CGFloat = 0.12, rightFrac: CGFloat = 0.07

    /// Rendered cap insets scaled so the top corner is `corner` points tall (corner art stays undistorted).
    static func caps(_ img: NSImage, corner: CGFloat) -> NSEdgeInsets {
        let f = corner / max(1, img.size.height * topFrac)
        return NSEdgeInsets(top: img.size.height * topFrac * f, left: img.size.width * leftFrac * f,
                            bottom: img.size.height * bottomFrac * f, right: img.size.width * rightFrac * f)
    }

    /// Draws `img` nine-sliced into `dst`: 4 corners at the rendered cap size, edges + centre stretched.
    static func drawNineSlice(_ img: NSImage, in dst: NSRect, corner: CGFloat) {
        let sw = img.size.width, sh = img.size.height
        let sl = sw * leftFrac, sr = sw * rightFrac, st = sh * topFrac, sb = sh * bottomFrac
        let d = caps(img, corner: corner)
        let sxs = [0, sl, sw - sr, sw], sys = [0, sb, sh - st, sh]                 // src (bottom-left origin)
        let dxs = [dst.minX, dst.minX + d.left, dst.maxX - d.right, dst.maxX]
        let dys = [dst.minY, dst.minY + d.bottom, dst.maxY - d.top, dst.maxY]
        for r in 0..<3 {
            for c in 0..<3 {
                let src = NSRect(x: sxs[c], y: sys[r], width: sxs[c + 1] - sxs[c], height: sys[r + 1] - sys[r])
                let dest = NSRect(x: dxs[c], y: dys[r], width: dxs[c + 1] - dxs[c], height: dys[r + 1] - dys[r])
                img.draw(in: dest, from: src, operation: .sourceOver, fraction: 1.0)
            }
        }
    }

    /// A standalone NSImage of the bubble at `size` (so the editor can show it without re-stretching).
    static func sliced(_ img: NSImage, size: CGSize, corner: CGFloat) -> NSImage {
        let out = NSImage(size: size)
        out.lockFocus()
        NSGraphicsContext.current?.imageInterpolation = .high
        drawNineSlice(img, in: NSRect(origin: .zero, size: size), corner: corner)
        out.unlockFocus()
        return out
    }
}

extension NSColor {
    convenience init(srgbHex hex: UInt, alpha: CGFloat = 1) {
        self.init(srgbRed: CGFloat((hex >> 16) & 0xFF) / 255,
                  green: CGFloat((hex >> 8) & 0xFF) / 255,
                  blue: CGFloat(hex & 0xFF) / 255,
                  alpha: alpha)
    }
}

extension String {
    /// Filesystem-safe slug for export filenames.
    var slug: String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_"))
        let mapped = self.lowercased().map { ch -> Character in
            String(ch).rangeOfCharacter(from: allowed) != nil ? ch : "-"
        }
        let collapsed = String(mapped).replacingOccurrences(of: "--", with: "-")
        return collapsed.trimmingCharacters(in: CharacterSet(charactersIn: "-")).isEmpty
            ? "untitled" : collapsed.trimmingCharacters(in: CharacterSet(charactersIn: "-"))
    }
}
