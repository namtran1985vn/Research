import AppKit

/// Composites several dropped images into a single 1024×1280 grid (2×2 for 4, 3×3 for 9, …)
/// so a batch of images becomes one creative image.
enum GridComposer {
    static let canvas = NSSize(width: 1024, height: 1280)

    /// Sample/import grids pack up to 9 full-res reference photos into one image. Composing at the
    /// bare 1024-wide canvas shrinks each 3×3 cell to ~341px → blurry on zoom even though the source
    /// photos are sharp. Composing at 3× (≈3072-wide) gives ~1024px per cell, so cells stay crisp.
    static let detailScale: CGFloat = 3
    static func highResSize(_ size: CGSize) -> CGSize {
        CGSize(width: size.width * detailScale, height: size.height * detailScale)
    }

    /// Canvas size (matching `ratio`'s aspect) big enough that every grid cell can hold its source
    /// photo at native resolution — i.e. the small images inside the grid are NOT downscaled. Used
    /// when saving/exporting a sample grid so the cells stay fully detailed. Capped at `maxLongEdge`
    /// to keep file size and memory sane.
    static func highFidelitySize(for images: [NSImage], ratio: CGSize,
                                 cols explicitCols: Int? = nil, rows explicitRows: Int? = nil,
                                 maxLongEdge: CGFloat = 8192) -> CGSize {
        let (cols, rows) = explicitCols.flatMap { c in explicitRows.map { (c, $0) } } ?? gridDims(images.count)
        let maxW = images.map(\.pixelWidth).max() ?? 1024
        let maxH = images.map(\.pixelHeight).max() ?? 1280
        // Each cell must be at least the largest source photo → canvas = cell × grid count.
        var w = CGFloat(maxW * cols)
        var h = CGFloat(maxH * rows)
        // Force the overall canvas to the creative's aspect ratio (cells get center-cropped to fit).
        let targetAR = ratio.width / ratio.height
        if w / h > targetAR { h = w / targetAR } else { w = h * targetAR }
        let longEdge = max(w, h)
        if longEdge > maxLongEdge { let k = maxLongEdge / longEdge; w *= k; h *= k }
        return CGSize(width: w.rounded(), height: h.rounded())
    }

    /// Square-ish grid dimensions for `n` images (cols ≥ rows).
    static func gridDims(_ n: Int) -> (cols: Int, rows: Int) {
        guard n > 1 else { return (1, 1) }
        let cols = Int(ceil(Double(n).squareRoot()))
        let rows = Int(ceil(Double(n) / Double(cols)))
        return (cols, rows)
    }

    /// Thread-safe (CoreGraphics) — can be called off the main actor to avoid UI freezes.
    /// `images` is positional: element `i` is drawn into cell `i`; a `nil` entry leaves that cell
    /// empty (background shows through) — used by Before/After grids where some cells aren't filled yet.
    /// When `split` is true a vertical seam is drawn between the two columns plus a horizontal seam
    /// between each row, in `dividerColor`, so a 2-column split (Before/After or Comparison) reads at
    /// a glance. The seam is purely cosmetic and mode-agnostic — labels are drawn elsewhere.
    static func compose(_ images: [NSImage?], size: CGSize = CGSize(width: 1024, height: 1280),
                        gap: CGFloat = 12, bg: NSColor = NSColor(srgbHex: 0xFBFAF7),
                        cols explicitCols: Int? = nil, rows explicitRows: Int? = nil,
                        offsets: [CGPoint]? = nil,
                        split: Bool = false,
                        dividerColor: NSColor = NSColor(srgbHex: 0xE7DEC9)) -> NSImage? {
        guard !images.isEmpty else { return nil }
        let (cols, rows) = explicitCols.flatMap { c in explicitRows.map { (c, $0) } } ?? gridDims(images.count)
        let w = Int(size.width), h = Int(size.height)
        guard let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0,
                                  space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        ctx.interpolationQuality = .high
        ctx.setFillColor(bg.usingColorSpace(.sRGB)?.cgColor ?? NSColor.white.cgColor)
        ctx.fill(CGRect(x: 0, y: 0, width: size.width, height: size.height))

        let cellW = (size.width - gap * CGFloat(cols + 1)) / CGFloat(cols)
        let cellH = (size.height - gap * CGFloat(rows + 1)) / CGFloat(rows)
        let radius: CGFloat = gap > 0 ? 8 : 0

        for (i, maybe) in images.enumerated() {
            guard let img = maybe,
                  let cg = img.cgImage(forProposedRect: nil, context: nil, hints: nil) else { continue }
            let col = i % cols, row = i / cols
            let x = gap + CGFloat(col) * (cellW + gap)
            let yTop = gap + CGFloat(row) * (cellH + gap)
            let cell = CGRect(x: x, y: size.height - yTop - cellH, width: cellW, height: cellH)

            let iw = CGFloat(cg.width), ih = CGFloat(cg.height)
            guard iw > 0, ih > 0 else { continue }
            let scale = max(cell.width / iw, cell.height / ih)
            let dw = iw * scale, dh = ih * scale
            // Per-cell pan: the image over-fills its cell; shift it within that overflow. `offset`
            // is −1…1 of the available slack (0 = centered). y is flipped (CG origin is bottom-left)
            // so it matches the live SwiftUI preview where +y drags the photo downward.
            let off = (offsets?.indices.contains(i) ?? false) ? offsets![i] : .zero
            let panX = max(-1, min(1, off.x)) * (dw - cell.width) / 2
            let panY = max(-1, min(1, off.y)) * (dh - cell.height) / 2
            let drawRect = CGRect(x: cell.minX + (cell.width - dw) / 2 + panX,
                                  y: cell.minY + (cell.height - dh) / 2 - panY, width: dw, height: dh)

            ctx.saveGState()
            ctx.addPath(CGPath(roundedRect: cell, cornerWidth: radius, cornerHeight: radius, transform: nil))
            ctx.clip()
            ctx.draw(cg, in: drawRect)
            ctx.restoreGState()
        }

        // Split seams: a crisp neutral line in the central gap (the column split) plus a thin line in
        // each inter-row gap. Drawn in the gaps the cell loop already left, so they sit between photos
        // without clipping any. Coordinates: x is top-origin == CG; y is flipped.
        if split, cols == 2 {
            ctx.setFillColor((dividerColor.usingColorSpace(.sRGB) ?? dividerColor).cgColor)
            ctx.fill(CGRect(x: gap + cellW, y: 0, width: gap, height: size.height))   // vertical seam
            for r in 1..<max(1, rows) {
                let yTop = gap + CGFloat(r) * (cellH + gap)                            // top of row r
                ctx.fill(CGRect(x: 0, y: size.height - yTop, width: size.width, height: gap))
            }
        }
        guard let outCG = ctx.makeImage() else { return nil }
        return NSImage(cgImage: outCG, size: size)
    }
}

extension NSImage {
    /// True pixel dimensions of the largest bitmap representation (NOT the point `size`, which can be
    /// arbitrary). Falls back to `size` when there's no bitmap rep.
    var pixelWidth: Int { representations.map(\.pixelsWide).max().flatMap { $0 > 0 ? $0 : nil } ?? Int(size.width) }
    var pixelHeight: Int { representations.map(\.pixelsHigh).max().flatMap { $0 > 0 ? $0 : nil } ?? Int(size.height) }
}

/// Loads images from dropped `NSItemProvider`s (files or images), preserving drop order.
enum ImageDrop {
    static func load(_ providers: [NSItemProvider], completion: @escaping ([NSImage]) -> Void) {
        var results = [NSImage?](repeating: nil, count: providers.count)
        let lock = NSLock()
        let group = DispatchGroup()
        for (i, p) in providers.enumerated() {
            group.enter()
            let set: (NSImage?) -> Void = { img in
                lock.lock(); results[i] = img; lock.unlock(); group.leave()
            }
            if p.canLoadObject(ofClass: NSImage.self) {
                _ = p.loadObject(ofClass: NSImage.self) { obj, _ in set(obj as? NSImage) }
            } else if p.canLoadObject(ofClass: URL.self) {
                _ = p.loadObject(ofClass: URL.self) { url, _ in set(url.flatMap { NSImage(contentsOf: $0) }) }
            } else {
                set(nil)
            }
        }
        group.notify(queue: .main) { completion(results.compactMap { $0 }) }
    }
}
