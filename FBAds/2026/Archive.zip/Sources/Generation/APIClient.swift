import Foundation

/// Shared HTTP transport for the app's API clients (OpenAI chat, OpenAI images, Gemini images).
/// Conformers supply only their provider label + auth header; this extension builds the request,
/// performs it, and maps any non-2xx response (and transport failure) to `APIError` — collapsing the
/// status-check + `URLSession` boilerplate that was copy-pasted across every client.
protocol APIClient {
    /// Provider label used in `APIError` messages ("OpenAI" / "Gemini").
    var providerName: String { get }
    /// The auth header applied to every request (field name + value).
    var authHeader: (field: String, value: String) { get }
}

extension APIClient {
    /// Perform a prebuilt request, returning the raw body on success or throwing `APIError`
    /// (`.network` on transport failure, `.from(status:…)` on any non-2xx response).
    func send(_ request: URLRequest) async throws -> Data {
        let data: Data, response: URLResponse
        do { (data, response) = try await URLSession.shared.data(for: request) }
        catch { throw APIError.network(error.localizedDescription) }
        guard let http = response as? HTTPURLResponse else { throw APIError.empty }
        guard (200..<300).contains(http.statusCode) else {
            throw APIError.from(status: http.statusCode, provider: providerName, data: data)
        }
        return data
    }

    /// POST a JSON object body (auth + content-type headers applied) and return the raw response data.
    func postJSON(_ url: URL, body: [String: Any], timeout: TimeInterval = 240) async throws -> Data {
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = timeout
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue(authHeader.value, forHTTPHeaderField: authHeader.field)
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        return try await send(req)
    }
}

// MARK: - OpenAI Chat Completions envelope

extension APIClient {
    /// Pull `choices[0].message.content` out of a Chat Completions response. `requireNonEmpty` throws
    /// on empty content (strategy / persona / variants must return text); pass `false` where an empty
    /// string is acceptable (single-field rewrite).
    func openAIChatContent(from data: Data, requireNonEmpty: Bool = true) throws -> String {
        guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let choices = obj["choices"] as? [[String: Any]],
              let message = choices.first?["message"] as? [String: Any],
              let text = message["content"] as? String,
              !(requireNonEmpty && text.isEmpty) else {
            throw APIError.decoding("unexpected chat envelope")
        }
        return text
    }
}

// MARK: - multipart/form-data

/// Builds a `multipart/form-data` body (text fields + image parts) for endpoints like OpenAI's
/// images *edit*, replacing the hand-rolled boundary handling that lived inline in the image provider.
struct MultipartFormData {
    let boundary = "Boundary-\(UUID().uuidString)"
    private var body = Data()

    init() {}

    var contentType: String { "multipart/form-data; boundary=\(boundary)" }

    mutating func addField(_ name: String, _ value: String) {
        body.append("--\(boundary)\r\n")
        body.append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n")
        body.append("\(value)\r\n")
    }

    mutating func addImage(_ data: Data, name: String, filename: String, mimeType: String = "image/png") {
        body.append("--\(boundary)\r\n")
        body.append("Content-Disposition: form-data; name=\"\(name)\"; filename=\"\(filename)\"\r\n")
        body.append("Content-Type: \(mimeType)\r\n\r\n")
        body.append(data)
        body.append("\r\n")
    }

    /// The finished body with the closing boundary appended.
    var httpBody: Data {
        var b = body
        b.append("--\(boundary)--\r\n")
        return b
    }
}

extension Data {
    mutating func append(_ string: String) {
        if let d = string.data(using: .utf8) { append(d) }
    }
}
