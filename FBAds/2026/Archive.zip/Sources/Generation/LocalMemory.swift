import Foundation
#if canImport(FoundationModels)
import FoundationModels
#endif

/// On-device memory distillation via Apple Intelligence (the FoundationModels framework).
///
/// Everything here runs ENTIRELY on-device, so maintaining a project's memory costs ZERO online API
/// tokens — only the small, already-distilled result is ever sent to the online model. When Apple
/// Intelligence is unavailable (turned off, unsupported hardware, or older OS) `distill` returns nil
/// and the caller keeps a trimmed, deduped tail of recent notes instead, so the feature still works
/// everywhere — it is just *smarter* when on-device AI is on.
enum LocalMemory {
    /// Target size (characters) for the distilled memory — keeps the injected block cheap (~150–200 tokens).
    static let targetChars = 700
    /// Distill once the combined distilled memory + pending raw notes exceed this many characters.
    static let compactThreshold = 1200

    /// True when the on-device model can run right now (Apple Intelligence enabled + supported hardware).
    static var isAvailable: Bool {
        #if canImport(FoundationModels)
        guard #available(macOS 26, *) else { return false }
        if case .available = SystemLanguageModel.default.availability { return true }
        return false
        #else
        return false
        #endif
    }

    /// Merge `existing` distilled memory with new `notes` into a compact, deduped, prioritized memory
    /// using the on-device model. Returns nil if the model is unavailable or errors — the caller then
    /// falls back to a non-AI fold.
    static func distill(existing: String, notes: [String], language: String) async -> String? {
        #if canImport(FoundationModels)
        guard #available(macOS 26, *) else { return nil }
        guard case .available = SystemLanguageModel.default.availability else { return nil }
        let body = ([existing] + notes)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .joined(separator: "\n")
        guard !body.isEmpty else { return nil }

        let instructions = """
        You maintain a SHORT memory of one ad campaign's durable user preferences and feedback. \
        Merge the notes below into a compact bullet list of stable, reusable rules an ad copywriter \
        and art director should follow next time for THIS campaign. Deduplicate; drop one-off, \
        contradicted or obsolete items; keep only what will still matter for future ads. Be specific \
        and terse. Write in \(language). Output ONLY the bullets (each starting with "- "), at most \
        about \(targetChars) characters, with no preamble or closing remark.
        """
        do {
            let session = LanguageModelSession(instructions: instructions)
            let response = try await session.respond(to: "NOTES:\n\(body)")
            let text = response.content.trimmingCharacters(in: .whitespacesAndNewlines)
            return text.isEmpty ? nil : String(text.prefix(targetChars + 200))
        } catch {
            return nil
        }
        #else
        return nil
        #endif
    }
}
