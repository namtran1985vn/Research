import Foundation
import AppKit
import CoreGraphics

/// Thin abstraction over the image backend (spec §6.3): one implementation today
/// (OpenAI gpt-image-1), but callers never depend on it directly so a future
/// provider can be swapped in without touching the engine or UI.
protocol ImageProvider {
    /// Returns PNG data for an ad image at the requested target size. `fidelity` controls which (if
    /// any) reproduce-the-product lock is appended: `.product` for the normal single-reference case,
    /// `nil` when the prompt is the sole authority (e.g. the Variant-grid Vary, which attaches TWO
    /// references with different roles — scene vs pattern — and must not be told "only the scene may
    /// change"). The 3-argument convenience below defaults to `.product` so existing callers are unchanged.
    func generate(prompt: String, references: [Data], target: CGSize, fidelity: ImageFidelity?) async throws -> Data

    /// Edits an EXISTING image per a free-text instruction and returns the new PNG at `target` size.
    /// Unlike `generate`, this never applies the product-fidelity lock — the user's instruction is the
    /// authority, so it may freely remove, recolor, or replace anything in the image.
    func editImage(prompt: String, image: Data, target: CGSize) async throws -> Data
}

extension ImageProvider {
    /// Back-compat default: the historical reference-based call locks the product (`.product`).
    func generate(prompt: String, references: [Data], target: CGSize) async throws -> Data {
        try await generate(prompt: prompt, references: references, target: target, fidelity: .product)
    }
}

/// Wraps a user's free-text edit instruction so the backend makes a LOCALIZED change and leaves the
/// rest of the image alone — the difference between "remove the pillow" and a full re-imagining.
///
/// The instruction is the AUTHORITY: we only preserve structure (framing, camera angle, where the
/// subject sits) so the edit reads as the same photo, not a different one. We deliberately do NOT ask
/// to preserve colors / lighting / materials / style — those are exactly what most edits change, and
/// freezing them made the model output something nearly identical to the input.
enum ImageEditPrompt {
    static func wrap(_ instruction: String) -> String {
        """
        Edit this image. The requested change is:

        \(instruction.trimmingCharacters(in: .whitespacesAndNewlines))

        Carry out this change FULLY and make it clearly, obviously visible in the result — even if it \
        substantially alters colors, materials, textures, patterns, or styling. The instruction above \
        is the authority; do not hold back or apply it only subtly.

        Keep the overall framing, camera angle, perspective, and the position/scale of the main subject \
        the same, so it still reads as the same photo — but everything the instruction asks to change \
        should genuinely change. Photorealistic result. Do not add any text, captions, watermarks, or \
        borders.
        """
    }
}

/// A reproduce-the-product lock appended to a reference-based prompt so any backend renders the real
/// product faithfully. Modelled as a value (not a bare static string) so a caller can pass `nil` to
/// opt OUT — the Variant-grid Vary needs full prompt authority over two differently-roled references.
enum ImageFidelity {
    /// Lock a SINGLE reference product's exact shape/pattern/silhouette; only scene/lighting/composition
    /// may change. The geometry line stops a half-moon mat becoming a full circle.
    case product

    var suffix: String {
        switch self {
        case .product:
            return "\n\nIMPORTANT: Reproduce the product exactly as shown in the reference photo — identical shape, proportions, colors, materials, surface patterns/textures, engravings, text and logos. Preserve its exact outline/silhouette: if the reference is a half-moon/semicircle, keep it a semicircle (straight edge at the bottom); never turn it into a full circle, oval, or rectangle. Do not redesign, restyle, or invent product details. Only the scene, lighting, and composition may change."
        }
    }
}

/// Crop / scale helpers to normalise any provider output to the requested target size.
enum ImageCrop {
    /// Center-crop a full product-SCENE photo down to a close-up of its main textile, so a
    /// pattern-swap edit gets a high-detail swatch to reproduce (the full scene is too distant — the
    /// model paraphrases the motif instead of copying it). `widthFrac`/`heightFrac` are the kept
    /// fractions; `vCenter` (0 = top … 1 = bottom) biases the crop down to where a bed throw drapes.
    /// Returns PNG, or the original data unchanged on any failure. CGImage cropping uses a top-left
    /// origin, so `vCenter` is measured from the top.
    static func centerCrop(_ data: Data, widthFrac: CGFloat = 0.72, heightFrac: CGFloat = 0.55,
                           vCenter: CGFloat = 0.6) -> Data {
        guard let src = NSImage(data: data),
              let cg = src.cgImage(forProposedRect: nil, context: nil, hints: nil) else { return data }
        let w = CGFloat(cg.width), h = CGFloat(cg.height)
        let cw = max(1, (w * min(1, max(0.1, widthFrac))).rounded())
        let ch = max(1, (h * min(1, max(0.1, heightFrac))).rounded())
        let x = ((w - cw) / 2).rounded()
        let y = max(0, min(h - ch, (h * vCenter - ch / 2))).rounded()
        guard let cropped = cg.cropping(to: CGRect(x: x, y: y, width: cw, height: ch)) else { return data }
        return NSBitmapImageRep(cgImage: cropped).representation(using: .png, properties: [:]) ?? data
    }

    static func normalizeToTarget(_ data: Data, target: CGSize = CGSize(width: 1024, height: 1280)) -> Data? {
        guard let src = NSImage(data: data), let cg = src.cgImage(forProposedRect: nil, context: nil, hints: nil)
        else { return data }

        let srcW = CGFloat(cg.width), srcH = CGFloat(cg.height)
        // Aspect-fill the target, then center-crop.
        let scale = max(target.width / srcW, target.height / srcH)
        let scaledW = srcW * scale, scaledH = srcH * scale
        let dx = (target.width - scaledW) / 2
        let dy = (target.height - scaledH) / 2

        guard let ctx = CGContext(
            data: nil, width: Int(target.width), height: Int(target.height),
            bitsPerComponent: 8, bytesPerRow: 0,
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return data }
        ctx.interpolationQuality = .high
        ctx.draw(cg, in: CGRect(x: dx, y: dy, width: scaledW, height: scaledH))
        guard let out = ctx.makeImage() else { return data }
        let rep = NSBitmapImageRep(cgImage: out)
        return rep.representation(using: .png, properties: [:])
    }
}
