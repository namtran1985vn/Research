import Foundation
import AppKit

/// Nano Banana (Google Gemini 2.5 Flash Image) backend. It preserves a product's exact shape and
/// surface pattern far better than gpt-image-1 when re-staging it in a new scene, and is cheaper per
/// image. Uses the `generateContent` endpoint with the product photo(s) attached as inline image
/// parts, then normalises the returned image to the requested target size.
struct NanoBananaImageProvider: ImageProvider {
    let apiKey: String

    private let model = "gemini-2.5-flash-image"
    private var endpoint: URL {
        URL(string: "https://generativelanguage.googleapis.com/v1beta/models/\(model):generateContent")!
    }

    func generate(prompt: String, references: [Data], target: CGSize, fidelity: ImageFidelity?) async throws -> Data {
        guard !apiKey.isEmpty else { throw APIError.missingKey(provider: "Gemini") }

        // Anchor the real product with the fidelity lock only when we attach a photo AND the caller
        // asked for one (Vary passes `nil` — its prompt is the sole authority over two references).
        let text = (references.isEmpty ? nil : fidelity).map { prompt + $0.suffix } ?? prompt
        return try await call(text: text, images: references, target: target)
    }

    func editImage(prompt: String, image: Data, target: CGSize) async throws -> Data {
        guard !apiKey.isEmpty else { throw APIError.missingKey(provider: "Gemini") }
        // No fidelity lock — the user's edit instruction is the authority (it may remove/recolor things).
        return try await call(text: ImageEditPrompt.wrap(prompt), images: [image], target: target)
    }

    /// Shared `generateContent` call: a text part plus up to four inline image parts → first image out.
    private func call(text: String, images: [Data], target: CGSize) async throws -> Data {
        var parts: [[String: Any]] = [["text": text]]
        for ref in images.prefix(4) {
            let png = NSImage(data: ref)?.pngData() ?? ref
            parts.append(["inlineData": ["mimeType": "image/png", "data": png.base64EncodedString()]])
        }

        let body: [String: Any] = [
            "contents": [["role": "user", "parts": parts]],
            "generationConfig": ["responseModalities": ["IMAGE"]],
        ]

        let data = try await postJSON(endpoint, body: body)
        guard let b64 = Self.firstInlineImage(in: data) else {
            throw APIError.decoding("Gemini returned no image")
        }
        guard let raw = Data(base64Encoded: b64) else { throw APIError.decoding("image not base64") }
        return ImageCrop.normalizeToTarget(raw, target: target) ?? raw
    }

    /// Pull the first inline image's base64 out of a `generateContent` response.
    private static func firstInlineImage(in data: Data) -> String? {
        guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let candidates = obj["candidates"] as? [[String: Any]] else { return nil }
        for cand in candidates {
            guard let content = cand["content"] as? [String: Any],
                  let parts = content["parts"] as? [[String: Any]] else { continue }
            for part in parts {
                if let inline = part["inlineData"] as? [String: Any],
                   let d = inline["data"] as? String, !d.isEmpty { return d }
            }
        }
        return nil
    }
}

extension NanoBananaImageProvider: APIClient {
    var providerName: String { "Gemini" }
    var authHeader: (field: String, value: String) { ("x-goog-api-key", apiKey) }
}
