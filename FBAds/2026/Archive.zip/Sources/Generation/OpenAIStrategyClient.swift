import Foundation
import AppKit

/// Generates the ranked creative strategy via the OpenAI **Chat Completions** API (GPT with vision).
/// This replaces the Claude path — the whole app talks to OpenAI only.
struct OpenAIStrategyClient {
    let apiKey: String
    let model: String
    let language: String
    /// The user's persistent cross-campaign learnings/rules (Settings). Empty by default.
    let learnings: String
    /// This project's distilled memory — durable feedback/edits/preferences for THIS campaign,
    /// maintained on-device. Empty by default so non-project calls are byte-for-byte unchanged.
    var projectMemory: String = ""

    private let endpoint = URL(string: "https://api.openai.com/v1/chat/completions")!

    /// The learnings formatted as a strong, labeled prompt block — or "" when empty so prompts
    /// are byte-for-byte unchanged. Appended to every content-generation user message.
    private var learningsBlock: String {
        let t = learnings.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return "" }
        return """
        PAST-CAMPAIGN LEARNINGS & RULES — the user's own findings from running real ads. Apply these \
        STRONGLY across every persona, creative, hook, headline, copy and image prompt; honor any \
        explicit do's and don'ts:
        \(t)
        """
    }

    /// This campaign's memory as a labeled block — or "" when empty.
    private var memoryBlock: String {
        let t = projectMemory.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return "" }
        return """
        PROJECT MEMORY — durable preferences and feedback the user has given on THIS campaign. Honor \
        these unless the current request explicitly overrides them:
        \(t)
        """
    }

    /// Append the learnings + project-memory blocks to a user message (no-op when both are empty).
    private func withContext(_ user: String) -> String {
        [user, learningsBlock, memoryBlock].filter { !$0.isEmpty }.joined(separator: "\n\n")
    }

    /// gpt-5 / o-series models require `max_completion_tokens` instead of `max_tokens`.
    private var maxTokensKey: String {
        let m = model.lowercased()
        return (m.hasPrefix("gpt-5") || m.hasPrefix("o1") || m.hasPrefix("o3") || m.hasPrefix("o4"))
            ? "max_completion_tokens" : "max_tokens"
    }

    /// Output budget for the big strategy JSON. Reasoning models (gpt-5/o-series) spend hidden
    /// reasoning tokens from this same budget, and gpt-4.1 supports large outputs — give those
    /// headroom so the richer 5-axis JSON (coverage maps, lens, per-creative tags, setup guidance)
    /// never truncates mid-stream. gpt-4o/4o-mini cap at 16,384 output tokens, so keep them at 16k.
    private var strategyMaxTokens: Int {
        let m = model.lowercased()
        let largeOutput = m.hasPrefix("gpt-5") || m.hasPrefix("o1") || m.hasPrefix("o3")
            || m.hasPrefix("o4") || m.hasPrefix("gpt-4.1")
        return largeOutput ? 32000 : 16000
    }

    func generateStrategy(product: Product,
                          referenceImages: [Data],
                          n: Int, m: Int, feedback: String = "") async throws -> StrategyResponse {
        guard !apiKey.isEmpty else { throw APIError.missingKey(provider: "OpenAI") }

        // User message: product brief + product photos as base64 data URLs (vision).
        var userContent: [[String: Any]] = [
            ["type": "text", "text": withContext(StrategyPrompt.userMessage(product: product, n: n, m: m, feedback: feedback))]
        ]
        for data in referenceImages {
            guard let png = NSImage(data: data)?.pngData() else { continue }
            userContent.append([
                "type": "image_url",
                "image_url": ["url": "data:image/png;base64,\(png.base64EncodedString())"],
            ])
        }

        let body: [String: Any] = [
            "model": model,
            maxTokensKey: strategyMaxTokens,
            "response_format": ["type": "json_object"],
            "messages": [
                ["role": "system", "content": StrategyPrompt.system(n: n, m: m, language: language)],
                ["role": "user", "content": userContent],
            ],
        ]

        let data = try await postJSON(endpoint, body: body, timeout: 240)
        let text = try openAIChatContent(from: data)   // choices[0].message.content → JSON string

        let json = OpenAIStrategyClient.extractJSON(from: text)
        guard let jsonData = json.data(using: .utf8) else { throw APIError.decoding("not utf8") }
        do {
            return try JSONDecoder().decode(StrategyResponse.self, from: jsonData)
        } catch {
            throw APIError.decoding(error.localizedDescription)
        }
    }

    /// Generate ONE additional persona (with `m` ranked creatives, each 4 variants), consistent
    /// with the existing campaign context. `seed` optionally fleshes out a named ranking candidate.
    func generatePersona(product: Product, offer: Offer, existing: [String], m: Int,
                         seedName: String?, seedDesc: String?, instruction: String) async throws -> StrategyResponse.PersonaDTO {
        guard !apiKey.isEmpty else { throw APIError.missingKey(provider: "OpenAI") }
        let system = """
        You are a world-class direct-response Facebook/Meta ads strategist. Generate ONE additional \
        buyer persona for the product, consistent with the existing campaign and offer. Write \
        ALL human-readable content in \(language). Make it DISTINCT from the existing personas.
        TOP PRIORITY: if the input gives a brief / seed for WHO this persona is, that brief DEFINES \
        this persona — match it precisely. It OVERRIDES the campaign-wide audience and the generic \
        "be different" pull: you must still avoid duplicating an existing persona, but satisfy the \
        brief FIRST; never swap in a different audience just to be distinct. Then the WHOLE ad set \
        must serve that persona — every creative's bigIdea, hooks, message and imagery must embody \
        THIS persona's coreEmotion, selfImage and angle, speaking to this specific buyer, never the \
        product in the abstract.
        Every creative is direct-response but DESIRE-LED, never pushy: build emotion/desire and leave \
        the reader leaning toward owning it — no urgency, fake scarcity, countdowns or "BUY NOW" \
        pressure (that signals cheap and repels value buyers). The explicit ask is the CTA button.
        First declare the persona's lens — `coreEmotion` (the emotion driving their purchase), \
        `selfImage` (who they want to become), `psychLever` (1–2 main levers) — then a `coverage` map \
        (`emotions`: ≥4 distinct emotional axes, `moments`: ≥3 distinct moments; or \(m) if \(m) is smaller). \
        These are derived from the product + the user's input notes (not a fixed list), written in \(language).
        Then provide exactly \(m) ranked creatives (best first). Each MUST lead with a distinct \
        `bigIdea` — a SHORT phrase (≤12 words) naming a specific selling insight/'aha' angle (in \
        \(language)), NOT a format or label; no two creatives may share a bigIdea. Each is a DISTINCT \
        combination of (emotionAxis × moment × imageStyle × messageStrategy): `emotionAxis` from coverage.emotions, \
        `moment` from coverage.moments, `messageStrategy` ∈ {pain, proof, transformation, objection, \
        desire} (label in \(language)), `imageStyle` ∈ {beauty, ugc, testimonial, lifestyle, studio}, \
        and a `valueSignal` (a self-pricing-high cue that attracts value buyers, separate from \
        productDetail). For EACH creative provide 4 distinct variants of: hooks (≤6 words), highlights \
        (the 1–2 word emphasis inside each hook, same order), headlines, primaryTexts, and imagePrompts \
        (each keeps the real product accurate and ends with "No text, no words, no logos. 4:5 vertical. \
        Keep the same exact pattern/design of the input product.").
        Return ONLY JSON for a single persona:
        { "name": string, "audience": "A"|"B", "score": int, "ltv": string, "angle": string,
          "description": string, "reasonTop": string,
          "coreEmotion": string, "selfImage": string, "psychLever": string,
          "coverage": { "emotions": [string], "moments": [string] },
          "copy": { "primaryTexts": [string,string,string,string], "headlines": [string,string,string], "cta": string },
          "creatives": [ { "rank": int, "score": int, "bigIdea": string, "imageStyle": string, "concept": string, "message": string,
            "productDetail": string, "layout": string, "reasonTop": string,
            "emotionAxis": string, "moment": string, "messageStrategy": string, "valueSignal": string,
            "hooks": [4], "highlights": [4], "headlines": [4], "primaryTexts": [4], "imagePrompts": [4] } ] }
        """
        var lines = ["PRODUCT: \(product.name) — \(product.desc)"]
        // WHO this persona is comes FIRST and is the primary directive — a buried brief gets
        // overridden by the campaign-wide audience + "be distinct" pull, producing an off-brief
        // persona. Seed (from a ranking row) and the user's free-text brief both define the persona.
        if let seedName, !seedName.isEmpty {
            lines.append("THE PERSONA TO BUILD — this DEFINES the new ad set; honor it precisely and "
                + "keep every creative on it: \(seedName)\(seedDesc.map { " — \($0)" } ?? "")")
        }
        let brief = instruction.trimmingCharacters(in: .whitespaces)
        if !brief.isEmpty {
            lines.append("THE USER'S BRIEF FOR THIS PERSONA (HIGHEST PRIORITY — the persona AND all its "
                + "creatives must match this exactly; do NOT drift to a different audience to be distinct): \(brief)")
        }
        // Campaign-wide context is BACKGROUND only — it must not override the brief above.
        if !product.targetCustomers.trimmingCharacters(in: .whitespaces).isEmpty {
            lines.append("Campaign-wide context (background only — do not let it override the brief above): \(product.targetCustomers)")
        }
        lines.append("RECOMMENDED OFFER: \(offer.chosen)")
        if !existing.isEmpty {
            lines.append("Existing personas to stay distinct from (avoid duplicating these, but still satisfy the brief above): \(existing.joined(separator: "; "))")
        }
        lines.append("Produce \(m) creatives, best-first — each speaking to THIS persona's emotion and self-image, not the product generically.")

        let body: [String: Any] = [
            "model": model, maxTokensKey: min(strategyMaxTokens, 16000),
            "response_format": ["type": "json_object"],
            "messages": [
                ["role": "system", "content": system],
                ["role": "user", "content": withContext(lines.joined(separator: "\n"))],
            ],
        ]
        let data = try await postJSON(endpoint, body: body, timeout: 180)
        let text = try openAIChatContent(from: data)
        guard let jsonData = Self.extractJSON(from: text).data(using: .utf8) else { throw APIError.decoding("not utf8") }
        do { return try JSONDecoder().decode(StrategyResponse.PersonaDTO.self, from: jsonData) }
        catch { throw APIError.decoding(error.localizedDescription) }
    }

    /// Rewrite a single AI copy field (headline / primary text / hook) given the full creative
    /// context and an optional user instruction. Returns just the new text.
    func rewriteCopy(field: CopyField,
                     current: String,
                     instruction: String,
                     product: Product,
                     persona: Persona,
                     creative: Creative) async throws -> String {
        guard !apiKey.isEmpty else { throw APIError.missingKey(provider: "OpenAI") }

        let system = """
        You are an elite direct-response Facebook/Meta ads copywriter. You rewrite a single piece of \
        ad copy on request. Output ONLY the rewritten \(field.label) — no quotes, no preamble, no \
        markdown, no alternatives. Write it in \(language).
        """
        let userInstruction = instruction.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? "Make it noticeably stronger and fresh while keeping the same core intent."
            : instruction
        let user = """
        PRODUCT: \(product.name) — \(product.desc)
        PERSONA: \(persona.name). \(persona.desc) Angle: \(persona.angle)
        CREATIVE CONCEPT: \(creative.concept)
        CREATIVE MESSAGE: \(creative.message)
        HOOK: \(creative.hook)

        FIELD TO REWRITE: \(field.label)
        FORMAT: \(field.guidance)
        CURRENT \(field.label.uppercased()): \(current)

        INSTRUCTION FROM USER: \(userInstruction)

        Return only the new \(field.label).
        """

        let body: [String: Any] = [
            "model": model,
            maxTokensKey: 600,
            "messages": [
                ["role": "system", "content": system],
                ["role": "user", "content": withContext(user)],
            ],
        ]

        let data = try await postJSON(endpoint, body: body, timeout: 120)
        let text = try openAIChatContent(from: data, requireNonEmpty: false)
        return Self.cleanCopy(text)
    }

    /// Produce N distinct variants of a copy field (headline / primary text) to choose from.
    func copyVariants(field: CopyField, count: Int, instruction: String,
                      product: Product, persona: Persona, creative: Creative) async throws -> [String] {
        let system = """
        You are an elite direct-response Facebook/Meta ads copywriter. Produce \(count) DISTINCT, \
        high-quality variants of one \(field.label), each a different angle. Write in \(language).
        Return ONLY JSON: {"variants": [\(count) strings]}. No markdown, no commentary, no quotes inside strings.
        """
        let extra = instruction.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? "" : "\nUSER INSTRUCTION (apply to all variants): \(instruction)"
        let user = """
        PRODUCT: \(product.name) — \(product.desc)
        PERSONA: \(persona.name). \(persona.desc) Angle: \(persona.angle)
        CREATIVE CONCEPT: \(creative.concept) | MESSAGE: \(creative.message) | HOOK: \(creative.hook)
        FIELD: \(field.label) — \(field.guidance)\(extra)
        """
        return try await requestVariants(system: system, user: withContext(user), count: count)
    }

    /// Produce N distinct image-generation prompts (different scene directions) to choose from.
    func imagePromptVariants(count: Int, instruction: String,
                             product: Product, persona: Persona, creative: Creative) async throws -> [String] {
        let system = """
        You write prompts for an image generator that recreates a real product photo in new scenes. \
        Produce \(count) DISTINCT image prompts (different compositions/settings) in ENGLISH. Each must \
        keep the real product accurate, reserve clean negative space for a text overlay, and END with \
        "No text, no words, no logos. 4:5 vertical. Keep the same exact pattern/design of the input product." \
        Return ONLY JSON: {"variants": [\(count) strings]}.
        """
        let extra = instruction.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            ? "" : "\nUSER INSTRUCTION (apply to all): \(instruction)"
        let user = """
        PRODUCT: \(product.name) — \(product.desc)
        PERSONA: \(persona.name). Angle: \(persona.angle)
        CREATIVE: \(creative.concept) | style: \(creative.style) | layout: \(creative.layout) | \
        keep sharp: \(creative.productDetail)\(extra)
        """
        return try await requestVariants(system: system, user: withContext(user), count: count)
    }

    private func requestVariants(system: String, user: String, count: Int) async throws -> [String] {
        guard !apiKey.isEmpty else { throw APIError.missingKey(provider: "OpenAI") }
        let body: [String: Any] = [
            "model": model, maxTokensKey: 2000,
            "response_format": ["type": "json_object"],
            "messages": [["role": "system", "content": system], ["role": "user", "content": user]],
        ]
        let data = try await postJSON(endpoint, body: body, timeout: 120)
        let text = try openAIChatContent(from: data, requireNonEmpty: false)
        let json = Self.extractJSON(from: text)
        guard let jsonData = json.data(using: .utf8),
              let parsed = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any] else {
            throw APIError.decoding("variants not JSON")
        }
        let arr = (parsed["variants"] as? [String]) ?? (parsed["variants"] as? [Any])?.compactMap { $0 as? String } ?? []
        let cleaned = arr.map { Self.cleanCopy($0) }.filter { !$0.isEmpty }
        guard !cleaned.isEmpty else { throw APIError.empty }
        return Array(cleaned.prefix(count))
    }

    /// Strip wrapping quotes / stray markdown the model sometimes adds.
    static func cleanCopy(_ s: String) -> String { CopyText.clean(s) }

    /// Pull the JSON object out of the reply, tolerating ```json fences or prose.
    static func extractJSON(from text: String) -> String {
        var s = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if let r = s.range(of: "```json") ?? s.range(of: "```") {
            s = String(s[r.upperBound...])
            if let end = s.range(of: "```") { s = String(s[..<end.lowerBound]) }
        }
        guard let start = s.firstIndex(of: "{"), let end = s.lastIndex(of: "}") else { return s }
        return String(s[start...end])
    }
}

extension OpenAIStrategyClient: APIClient {
    var providerName: String { "OpenAI" }
    var authHeader: (field: String, value: String) { ("Authorization", "Bearer \(apiKey)") }
}
