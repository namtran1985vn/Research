import Foundation

/// Drives parallel image generation with a concurrency cap, auto-retry + backoff, and cancellation.
/// Independent jobs run concurrently up to `concurrency`; finished jobs free a slot for the next.
@MainActor
final class GenerationEngine: ObservableObject {

    struct Job: Identifiable, Equatable, Hashable {
        let projectID: UUID
        let personaID: UUID
        let creativeID: UUID
        var id: UUID { creativeID }
    }

    @Published private(set) var isRunning = false

    var concurrency: Int = 4
    var autoRetry: Bool = true

    // Injected dependencies (wired by AppStore).
    var makeProvider: () -> ImageProvider? = { nil }
    /// Name of the key the current image backend needs — for the "missing key" message.
    var missingKeyProvider: () -> String = { "OpenAI" }
    var promptFor: (Job) -> String? = { _ in nil }
    var referencesFor: (Job) -> [Data] = { _ in [] }
    var targetFor: (Job) -> CGSize = { _ in CGSize(width: 1024, height: 1280) }
    var onStatus: (Job, CreativeStatus, String?) -> Void = { _, _, _ in }
    var onImage: (Job, Data) -> Void = { _, _ in }
    var onBatchComplete: () -> Void = {}

    private var queue: [Job] = []
    private var active: [UUID: Task<Void, Never>] = [:]

    var queuedCount: Int { queue.count }

    // MARK: Public control

    func enqueue(_ jobs: [Job]) {
        guard !jobs.isEmpty else { return }
        for job in jobs where !queue.contains(job) && active[job.creativeID] == nil {
            queue.append(job)
            onStatus(job, .queued, nil)
        }
        isRunning = true
        pump()
    }

    func cancelAll() {
        for (_, task) in active { task.cancel() }
        let cancelled = queue
        queue.removeAll()
        for job in cancelled { onStatus(job, .idle, nil) }
        // Active jobs reset themselves to idle on cancellation inside their task.
    }

    func cancelOne(_ job: Job) {
        queue.removeAll { $0 == job }
        if let task = active[job.creativeID] { task.cancel() }
        else { onStatus(job, .idle, nil) }
    }

    // MARK: Queue pump

    private func pump() {
        while active.count < max(1, concurrency), !queue.isEmpty {
            let job = queue.removeFirst()
            start(job)
        }
        if active.isEmpty && queue.isEmpty {
            isRunning = false
            onBatchComplete()
        }
    }

    private func start(_ job: Job) {
        guard let provider = makeProvider(), let prompt = promptFor(job) else {
            onStatus(job, .error, APIError.missingKey(provider: missingKeyProvider()).errorDescription)
            return
        }
        let references = referencesFor(job)
        onStatus(job, .generating, nil)

        let task = Task { [weak self] in
            guard let self else { return }
            await self.run(job: job, provider: provider, prompt: prompt, references: references)
        }
        active[job.creativeID] = task
    }

    private func run(job: Job, provider: ImageProvider, prompt: String, references: [Data]) async {
        let maxAttempts = autoRetry ? 4 : 1
        var lastError: APIError = .empty

        for attempt in 0..<maxAttempts {
            if Task.isCancelled { break }
            do {
                let png = try await provider.generate(prompt: prompt, references: references, target: targetFor(job))
                if Task.isCancelled { break }
                finish(job: job) {
                    self.onImage(job, png)
                    self.onStatus(job, .done, nil)
                }
                return
            } catch let error as APIError {
                lastError = error
                if !error.isRetryable || attempt == maxAttempts - 1 { break }
                let backoff = min(pow(2.0, Double(attempt + 1)), 16) + Double((job.creativeID.hashValue % 1000)) / 1000.0
                try? await Task.sleep(nanoseconds: UInt64(backoff * 1_000_000_000))
            } catch {
                lastError = .network(error.localizedDescription)
                break
            }
        }

        if Task.isCancelled {
            finish(job: job) { self.onStatus(job, .idle, nil) }
        } else {
            finish(job: job) { self.onStatus(job, .error, lastError.errorDescription) }
        }
    }

    /// Common teardown: drop from active, apply the status mutation, and pump the next job.
    private func finish(job: Job, _ apply: () -> Void) {
        active[job.creativeID] = nil
        apply()
        pump()
    }
}
