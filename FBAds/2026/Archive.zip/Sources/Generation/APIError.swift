import Foundation

/// Human-readable API errors surfaced to the UI (per spec §G — readable messages + guidance).
enum APIError: LocalizedError {
    case missingKey(provider: String)
    case unauthorized(provider: String)
    case rateLimited(retryAfter: Double?)
    case quotaExceeded(provider: String)
    case server(status: Int, message: String)
    case decoding(String)
    case network(String)
    case empty

    var errorDescription: String? {
        switch self {
        case .missingKey(let p):    return "Add your \(p) API key in Settings (⌘,) to continue."
        case .unauthorized(let p):  return "\(p) rejected the API key. Check it in Settings."
        case .rateLimited:          return "Rate limit reached (429). Retrying with backoff…"
        case .quotaExceeded(let p): return "\(p) quota exceeded — check your billing."
        case .server(let s, let m): return "Server error (\(s)): \(m)"
        case .decoding(let m):      return "Couldn't read the response: \(m)"
        case .network(let m):       return "Network error: \(m)"
        case .empty:                return "The model returned no content."
        }
    }

    /// Whether the generation engine should auto-retry this (with backoff).
    var isRetryable: Bool {
        switch self {
        case .rateLimited, .network, .server: return true
        default: return false
        }
    }

    static func from(status: Int, provider: String, data: Data) -> APIError {
        let body = String(data: data, encoding: .utf8) ?? ""
        let lower = body.lowercased()
        switch status {
        case 401, 403: return .unauthorized(provider: provider)
        case 429:
            if lower.contains("quota") || lower.contains("billing") || lower.contains("insufficient") {
                return .quotaExceeded(provider: provider)
            }
            return .rateLimited(retryAfter: nil)
        default:
            // Pull a concise message out of the JSON error envelope when present.
            if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let err = obj["error"] as? [String: Any],
               let msg = err["message"] as? String {
                return .server(status: status, message: msg)
            }
            return .server(status: status, message: String(body.prefix(160)))
        }
    }
}
