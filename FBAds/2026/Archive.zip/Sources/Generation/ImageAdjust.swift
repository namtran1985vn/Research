import SwiftUI
import AppKit
import CoreImage
import CoreImage.CIFilterBuiltins

/// High-quality, non-destructive image adjustments via Core Image, tuned to feel like Photoshop's
/// Camera Raw sliders — a moderate slider value produces a clearly visible change, not a subtle one.
///
/// Quality choices:
/// • Brightness → `CIGammaAdjust` — a midtone gamma curve that pins pure black and pure white, so it
///   brightens/darkens the midtones strongly without clipping highlights or crushing shadows. This is
///   Photoshop's highlight-protected Brightness; a raw exposure multiply blows highlights to white.
/// • Shadows    → `CIHighlightShadowAdjust` — purpose-built, radius-based tonal recovery that lifts
///   (or deepens) shadows while leaving highlights alone. Uses a LARGE radius so the lift is visible
///   (a small radius makes this filter nearly a no-op).
/// • Clarity    → large-radius `CIUnsharpMask` for midtone LOCAL contrast, then a luminance tent mask
///   confines the boost to the midtones (`CIBlendWithMask`) so shadows/highlights don't halo — the
///   way Camera Raw's Clarity behaves, not a naive global unsharp.
/// • Saturation → `CIColorControls.saturation` — a DIRECT saturation multiply (Photoshop "Saturation"):
///   +100 → 2× saturation, −100 → fully desaturated. We deliberately do NOT use `CIVibrance` here —
///   vibrance protects already-colorful pixels, so on a normal photo the slider barely moves and feels
///   broken. A direct multiply gives the unmistakable effect users expect from a "Saturation" control.
/// The whole chain runs in a LINEAR-sRGB working space (float precision) with sRGB output, which is
/// what makes exposure/contrast look correct and avoids banding.
enum ImageAdjust {
    private static let context: CIContext = {
        var opts: [CIContextOption: Any] = [.useSoftwareRenderer: false]
        if let lin = CGColorSpace(name: CGColorSpace.linearSRGB) { opts[.workingColorSpace] = lin }
        if let srgb = CGColorSpace(name: CGColorSpace.sRGB) { opts[.outputColorSpace] = srgb }
        return CIContext(options: opts)
    }()

    /// Apply adjustments to an NSImage. Returns the input unchanged when neutral (zero cost).
    static func apply(_ image: NSImage, _ adj: ImageAdjustments) -> NSImage? {
        guard !adj.isIdentity else { return image }
        guard let cg = image.cgImage(forProposedRect: nil, context: nil, hints: nil),
              let out = apply(cg, adj) else { return image }
        return NSImage(cgImage: out, size: image.size)
    }

    /// Apply adjustments to a CGImage. Filter order is tonal → local-contrast → color, which is the
    /// standard high-quality pipeline order.
    static func apply(_ cg: CGImage, _ adj: ImageAdjustments) -> CGImage? {
        var ci = CIImage(cgImage: cg)
        let extent = ci.extent
        let dim = min(extent.width, extent.height)

        // 1) Brightness → midtone GAMMA, not exposure. Gamma pins pure black (0→0) and pure white
        //    (1→1), so it lifts/darkens the midtones strongly WITHOUT blowing highlights to white or
        //    crushing shadows — Photoshop's highlight-protected Brightness. A raw exposure multiply
        //    (the old approach) clips highlights to white as soon as you push it up.
        if adj.brightness != 0 {
            let f = CIFilter.gammaAdjust()
            f.inputImage = ci
            f.power = Float(exp(-adj.brightness / 100.0 * 0.9))   // +100 → ~0.41 (brighten), −100 → ~2.46 (darken)
            if let o = f.outputImage { ci = o }
        }
        // 2) Shadows → lift (+) / deepen (−) shadows only; highlights untouched. A LARGE radius is
        //    what makes CIHighlightShadowAdjust actually visible — too small and it barely registers.
        if adj.shadows != 0 {
            let f = CIFilter.highlightShadowAdjust()
            f.inputImage = ci
            f.highlightAmount = 1.0                              // 1 = leave highlights as-is
            f.shadowAmount = Float(adj.shadows / 100.0)          // + brightens, − darkens
            f.radius = Float(max(10, dim * 0.06))                // large radius → strong, natural recovery
            if let o = f.outputImage { ci = o }
        }
        // 3) Clarity → midtone LOCAL contrast via large-radius unsharp mask, then confined to the
        //    midtones with a luminance tent mask. Plain USM halos at the tonal extremes (bright rims
        //    on highlights, muddy rings in shadows); masking the boost to midtones — exactly how
        //    Camera Raw's Clarity behaves — keeps the punch while killing those halos.
        if adj.clarity > 0 {
            let usm = CIFilter.unsharpMask()
            usm.inputImage = ci
            usm.radius = Float(max(12, dim * 0.04))              // large radius = local contrast
            usm.intensity = Float(adj.clarity / 100.0 * 1.5)
            if let sharpened = usm.outputImage?.cropped(to: extent) {
                // Midtone weight = a tent over luminance, peaking at mid-grey and falling to 0 at
                // both black and white. Built from a desaturated copy run through a tone curve.
                let gray = CIFilter.colorControls()
                gray.inputImage = ci
                gray.saturation = 0
                let tent = CIFilter.toneCurve()
                tent.inputImage = gray.outputImage
                tent.point0 = CGPoint(x: 0.0,  y: 0.0)
                tent.point1 = CGPoint(x: 0.25, y: 0.6)
                tent.point2 = CGPoint(x: 0.5,  y: 1.0)
                tent.point3 = CGPoint(x: 0.75, y: 0.6)
                tent.point4 = CGPoint(x: 1.0,  y: 0.0)
                if let mask = tent.outputImage {
                    let blend = CIFilter.blendWithMask()
                    blend.inputImage = sharpened                 // boosted midtones
                    blend.backgroundImage = ci                   // untouched shadows/highlights
                    blend.maskImage = mask
                    if let o = blend.outputImage { ci = o.cropped(to: extent) }
                } else {
                    ci = sharpened
                }
            }
        }
        // 4) Saturation → DIRECT saturation multiply (Photoshop "Saturation"), NOT vibrance: +100 →
        //    2× saturation, −100 → greyscale. Vibrance protected colorful pixels and felt like a no-op.
        if adj.saturation != 0 {
            let f = CIFilter.colorControls()
            f.inputImage = ci
            f.saturation = Float(1.0 + adj.saturation / 100.0)
            if let o = f.outputImage { ci = o }
        }
        return context.createCGImage(ci, from: extent)
    }

    /// Downscale for a snappy live preview (full-res CI on every slider tick would be wasteful).
    static func downscaled(_ image: NSImage, maxDim: CGFloat) -> NSImage {
        let s = image.size
        guard s.width > 0, s.height > 0 else { return image }
        let scale = min(1, maxDim / max(s.width, s.height))
        guard scale < 1 else { return image }
        let newSize = NSSize(width: floor(s.width * scale), height: floor(s.height * scale))
        let out = NSImage(size: newSize)
        out.lockFocus()
        image.draw(in: NSRect(origin: .zero, size: newSize),
                   from: NSRect(origin: .zero, size: s), operation: .copy, fraction: 1)
        out.unlockFocus()
        return out
    }
}

// MARK: - Editor sheet (double-click a grid cell)

/// Live, non-destructive image editor. Sliders drive a downscaled preview; "Done" commits the
/// adjustments to the creative (persisted, applied to preview + export).
struct ImageAdjustSheet: View {
    @EnvironmentObject var store: AppStore
    let projectID: UUID
    let creativeID: UUID
    @Environment(\.dismiss) private var dismiss

    @State private var adj: ImageAdjustments
    @State private var rawBase: NSImage?
    @State private var preview: NSImage?

    init(projectID: UUID, creativeID: UUID, initial: ImageAdjustments) {
        self.projectID = projectID
        self.creativeID = creativeID
        _adj = State(initialValue: initial)
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Adjust image").font(.system(size: 15, weight: .bold)).foregroundStyle(Theme.ink)
                Spacer()
                Button("Reset") { adj = .init() }
                    .buttonStyle(.plain).foregroundStyle(adj.isIdentity ? Theme.ink4 : Theme.accent)
                    .disabled(adj.isIdentity)
            }
            .padding(.horizontal, 16).padding(.vertical, 12)
            Divider().overlay(Theme.border)

            ZStack {
                Theme.surface2
                if let img = preview ?? rawBase {
                    Image(nsImage: img).resizable().scaledToFit().padding(10)
                } else {
                    Spinner(size: 22, lineWidth: 2)
                }
            }
            // Preview shrinks when the window is short so the sliders + buttons stay on screen
            // (the sheet has no scroll). ~220pt is reserved for the header, sliders and footer.
            .frame(height: min(300, max(150, store.canvasSize.height - 220)))
            .frame(maxWidth: .infinity).clipped()

            VStack(spacing: 13) {
                row("Brightness", $adj.brightness, -100...100)
                row("Shadows", $adj.shadows, -100...100)
                row("Saturation", $adj.saturation, -100...100)
                row("Clarity", $adj.clarity, 0...100)
            }
            .padding(16)
            Divider().overlay(Theme.border)

            HStack(spacing: 8) {
                Spacer()
                Button("Cancel") { dismiss() }.buttonStyle(.plain).foregroundStyle(Theme.ink2)
                AppButton(title: "Done", icon: "check", variant: .primary, size: .sm) {
                    store.setAdjustments(project: projectID, creative: creativeID, adj)
                    dismiss()
                }
            }
            .padding(.horizontal, 16).padding(.vertical, 12)
        }
        .frame(width: min(460, store.canvasSize.width - 40))
        .background(Theme.bgWindow)
        .task(id: adj) { await rerender() }
    }

    @ViewBuilder
    private func row(_ label: String, _ value: Binding<Double>, _ range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack {
                Text(label).font(.system(size: 12, weight: .semibold)).foregroundStyle(Theme.ink2)
                Spacer()
                Text("\(Int(value.wrappedValue))")
                    .font(.system(size: 11, design: .monospaced)).foregroundStyle(Theme.ink3)
            }
            Slider(value: value, in: range, step: 1)
                .tint(Theme.accent)
        }
    }

    /// Re-render the preview from the (downscaled) raw base whenever `adj` changes. `.task(id:)`
    /// cancels the prior run, and the short sleep debounces rapid slider drags.
    private func rerender() async {
        if rawBase == nil {
            let raw = await store.rawBaseImage(project: projectID, creative: creativeID)
            rawBase = raw.map { ImageAdjust.downscaled($0, maxDim: 900) }
        }
        guard let base = rawBase else { return }
        try? await Task.sleep(nanoseconds: 25_000_000)
        if Task.isCancelled { return }
        preview = adj.isIdentity ? base : ImageAdjust.apply(base, adj)
    }
}

/// Same Brightness/Shadows/Saturation/Clarity sliders as `ImageAdjustSheet`, but for ONE grid/split
/// cell. It previews against the passed-in cell photo and hands the chosen adjustments back to the
/// caller (which bakes them into the cell and recomposes the grid). Unlike the whole-image sheet it's
/// self-contained — no store/creative coupling — so it can be driven from the per-cell context menu.
struct CellAdjustSheet: View {
    @EnvironmentObject var store: AppStore
    /// The cell's current photo, used only for the live preview.
    let source: NSImage
    let onDone: (ImageAdjustments) -> Void
    @Environment(\.dismiss) private var dismiss

    @State private var adj = ImageAdjustments()
    @State private var base: NSImage?       // downscaled preview source
    @State private var preview: NSImage?

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Adjust photo").font(.system(size: 15, weight: .bold)).foregroundStyle(Theme.ink)
                Spacer()
                Button("Reset") { adj = .init() }
                    .buttonStyle(.plain).foregroundStyle(adj.isIdentity ? Theme.ink4 : Theme.accent)
                    .disabled(adj.isIdentity)
            }
            .padding(.horizontal, 16).padding(.vertical, 12)
            Divider().overlay(Theme.border)

            ZStack {
                Theme.surface2
                if let img = preview ?? base {
                    Image(nsImage: img).resizable().scaledToFit().padding(10)
                } else {
                    Spinner(size: 22, lineWidth: 2)
                }
            }
            .frame(height: min(300, max(150, store.canvasSize.height - 220)))
            .frame(maxWidth: .infinity).clipped()

            VStack(spacing: 13) {
                row("Brightness", $adj.brightness, -100...100)
                row("Shadows", $adj.shadows, -100...100)
                row("Saturation", $adj.saturation, -100...100)
                row("Clarity", $adj.clarity, 0...100)
            }
            .padding(16)
            Divider().overlay(Theme.border)

            HStack(spacing: 8) {
                Spacer()
                Button("Cancel") { dismiss() }.buttonStyle(.plain).foregroundStyle(Theme.ink2)
                AppButton(title: "Done", icon: "check", variant: .primary, size: .sm) {
                    onDone(adj); dismiss()
                }
            }
            .padding(.horizontal, 16).padding(.vertical, 12)
        }
        .frame(width: min(460, store.canvasSize.width - 40))
        .background(Theme.bgWindow)
        .task(id: adj) { await rerender() }
    }

    @ViewBuilder
    private func row(_ label: String, _ value: Binding<Double>, _ range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack {
                Text(label).font(.system(size: 12, weight: .semibold)).foregroundStyle(Theme.ink2)
                Spacer()
                Text("\(Int(value.wrappedValue))")
                    .font(.system(size: 11, design: .monospaced)).foregroundStyle(Theme.ink3)
            }
            Slider(value: value, in: range, step: 1).tint(Theme.accent)
        }
    }

    private func rerender() async {
        if base == nil { base = ImageAdjust.downscaled(source, maxDim: 900) }
        guard let b = base else { return }
        try? await Task.sleep(nanoseconds: 25_000_000)
        if Task.isCancelled { return }
        preview = adj.isIdentity ? b : ImageAdjust.apply(b, adj)
    }
}
