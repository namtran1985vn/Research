import Foundation
import AppKit

/// gpt-image-1 backend. Uses the images *edit* endpoint when product reference photos
/// are present (to keep the product accurate) and the *generations* endpoint otherwise.
struct OpenAIImageProvider: ImageProvider {
    let apiKey: String

    /// Nearest gpt-image-1 size for the requested target (square → 1024×1024, else portrait).
    private func requestedSize(for target: CGSize) -> String {
        target.width == target.height ? "1024x1024" : "1024x1536"
    }

    func generate(prompt: String, references: [Data], target: CGSize, fidelity: ImageFidelity?) async throws -> Data {
        guard !apiKey.isEmpty else { throw APIError.missingKey(provider: "OpenAI") }
        let size = requestedSize(for: target)
        let b64: String
        if references.isEmpty {
            b64 = try await generateFromScratch(prompt: prompt, size: size)
        } else {
            b64 = try await edit(prompt: prompt, references: references, size: size, fidelity: fidelity)
        }
        guard let raw = Data(base64Encoded: b64) else { throw APIError.decoding("image not base64") }
        return ImageCrop.normalizeToTarget(raw, target: target) ?? raw
    }

    func editImage(prompt: String, image: Data, target: CGSize) async throws -> Data {
        guard !apiKey.isEmpty else { throw APIError.missingKey(provider: "OpenAI") }
        // Free-text edit: the edits endpoint with input_fidelity high keeps untouched regions stable,
        // but we send the user's wrapped instruction WITHOUT the product-fidelity lock.
        let b64 = try await edit(prompt: ImageEditPrompt.wrap(prompt), references: [image],
                                 size: requestedSize(for: target), fidelity: nil)
        guard let raw = Data(base64Encoded: b64) else { throw APIError.decoding("image not base64") }
        return ImageCrop.normalizeToTarget(raw, target: target) ?? raw
    }

    // MARK: edits (with reference photos)

    private func edit(prompt: String, references: [Data], size: String,
                      fidelity: ImageFidelity? = .product) async throws -> String {
        var form = MultipartFormData()
        form.addField("model", "gpt-image-1")
        form.addField("prompt", fidelity.map { prompt + $0.suffix } ?? prompt)
        form.addField("size", size)
        form.addField("n", "1")
        // Preserve the input product as closely as possible (shape, pattern, logos) and render at
        // high quality — without input_fidelity:high gpt-image-1 reinterprets the product loosely.
        form.addField("input_fidelity", "high")
        form.addField("quality", "high")
        for (i, ref) in references.prefix(4).enumerated() {
            let png = NSImage(data: ref)?.pngData() ?? ref
            form.addImage(png, name: "image[]", filename: "ref\(i).png")
        }

        var req = URLRequest(url: URL(string: "https://api.openai.com/v1/images/edits")!)
        req.httpMethod = "POST"
        req.timeoutInterval = 240
        req.setValue(authHeader.value, forHTTPHeaderField: authHeader.field)
        req.setValue(form.contentType, forHTTPHeaderField: "Content-Type")
        req.httpBody = form.httpBody
        let data = try await send(req)
        return try Self.firstB64(from: data)
    }

    // MARK: generations (no reference)

    private func generateFromScratch(prompt: String, size: String) async throws -> String {
        let url = URL(string: "https://api.openai.com/v1/images/generations")!
        let payload: [String: Any] = ["model": "gpt-image-1", "prompt": prompt,
                                      "size": size, "n": 1]
        let data = try await postJSON(url, body: payload)
        return try Self.firstB64(from: data)
    }

    /// Pull the first image's base64 (`data[0].b64_json`) out of an OpenAI images response.
    private static func firstB64(from data: Data) throws -> String {
        guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let arr = obj["data"] as? [[String: Any]],
              let b64 = arr.first?["b64_json"] as? String else {
            throw APIError.decoding("missing b64_json")
        }
        return b64
    }
}

extension OpenAIImageProvider: APIClient {
    var providerName: String { "OpenAI" }
    var authHeader: (field: String, value: String) { ("Authorization", "Bearer \(apiKey)") }
}
