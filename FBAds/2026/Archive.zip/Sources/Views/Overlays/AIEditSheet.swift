import SwiftUI

/// Free-text prompt sheet for "Edit with AI" — the user describes a change to make to an existing
/// image (e.g. "Remove the pillow on the left", "Change the background to a sunny room") and the AI
/// edits the target image in place. Mirrors `BeforeNoteSheet`; unlike that one the prompt is REQUIRED
/// (Edit is disabled while it's empty). The instruction is passed back to the caller, which runs the model.
struct AIEditSheet: View {
    let onEdit: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var prompt = ""

    private let suggestions = ["Remove an object", "Change the background",
                               "Brighter lighting", "Change the color"]

    private var trimmed: String { prompt.trimmingCharacters(in: .whitespacesAndNewlines) }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 7) {
                Glyph(name: "sparkle", size: 15, color: Theme.accent)
                Text("Edit with AI").font(.system(size: 14, weight: .bold))
            }
            Text("Describe the change you want. The AI edits this image and keeps everything else the same.")
                .font(.system(size: 11.5)).foregroundStyle(Theme.ink3)

            ZStack(alignment: .topLeading) {
                if prompt.isEmpty {
                    Text("e.g. Remove the pillow on the left")
                        .font(.system(size: 12)).foregroundStyle(Theme.ink4)
                        .padding(.horizontal, 9).padding(.vertical, 8).allowsHitTesting(false)
                }
                TextEditor(text: $prompt)
                    .font(.system(size: 12)).scrollContentBackground(.hidden)
                    .frame(height: 72).padding(.horizontal, 5).padding(.vertical, 3)
            }
            .background(Theme.surface)
            .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
            .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))

            FlexChips(items: suggestions) { prompt = $0 }

            HStack {
                Spacer()
                AppButton(title: "Cancel", variant: .secondary, size: .sm) { dismiss() }
                AppButton(title: "Edit", icon: "sparkle", variant: .primary, size: .sm) {
                    onEdit(trimmed); dismiss()
                }
                .disabled(trimmed.isEmpty)
                .opacity(trimmed.isEmpty ? 0.5 : 1)
            }
        }
        .padding(16)
        .frame(width: 340)
    }
}
