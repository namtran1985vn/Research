import SwiftUI
import UniformTypeIdentifiers

/// Full redo of a project: pre-fills the original brief + lets you add/remove photos, plus a
/// feedback box for new requirements. On submit, re-runs the whole strategy in the background.
struct RegenerateProjectSheet: View {
    enum Mode { case regenerate, duplicate }
    let projectID: UUID
    var mode: Mode = .regenerate
    @EnvironmentObject var store: AppStore

    private var title: String { mode == .duplicate ? "Duplicate project" : "Re-generate project" }
    private var subtitle: String { mode == .duplicate
        ? "Edit the brief and photos, then create a new project from this one."
        : "Tweak the brief, add or remove photos, and add feedback — the whole strategy is rebuilt." }
    private var actionTitle: String { mode == .duplicate ? "Create & generate" : "Re-generate" }

    struct Ref: Identifiable {
        let id = UUID()
        let image: NSImage
        var existingFilename: String?   // from disk (keep)
        var newData: Data?              // newly added (persist on submit)
    }

    @State private var name = ""
    @State private var desc = ""
    @State private var targetCustomers = ""
    @State private var goal = "Sales"
    @State private var languageDisplay = "English"
    @State private var n = 3
    @State private var m = 5
    @State private var feedback = ""
    @State private var refs: [Ref] = []
    @State private var dragOver = false
    @State private var loaded = false

    private var valid: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty && !desc.trimmingCharacters(in: .whitespaces).isEmpty
    }

    var body: some View {
        SheetShell(title: title, sub: subtitle, width: 640) {
            VStack(alignment: .leading, spacing: 16) {
                photosSection
                FormField(label: "Product name", text: $name, required: true)
                FormField(label: "Description", text: $desc, required: true, multiline: true)
                FormField(label: "Anything else you want the AI to know", text: $targetCustomers, placeholder: "Target, offer, angle, must-haves, things to avoid…", multiline: true)

                HStack(alignment: .top, spacing: 28) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Objective").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.ink2)
                        SegmentedControl(selection: $goal, options: ["Sales", "Leads"])
                    }
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Creative language").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.ink2)
                        SegmentedControl(selection: $languageDisplay, options: ["English", "Tiếng Việt"])
                    }
                    Spacer(minLength: 0)
                }
                HStack(spacing: 14) {
                    NumberStepper(label: "Personas (N)", sub: "1–6", value: $n, range: 1...6)
                    NumberStepper(label: "Creatives / persona (M)", sub: "3–10", value: $m, range: 3...10)
                }
                VStack(alignment: .leading, spacing: 6) {
                    Text("Feedback / new requirements").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.accent)
                    FormField(label: "", text: $feedback,
                              placeholder: "e.g. punchier hooks, focus on durability, target younger buyers…", multiline: true)
                }
                HStack {
                    Spacer()
                    AppButton(title: actionTitle, icon: mode == .duplicate ? "plus" : "refresh",
                              variant: .primary, disabled: !valid) { submit() }
                }
            }
        }
        .onAppear { if !loaded { populate() } }
    }

    private var photosSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("PHOTOS · \(refs.count)").font(.system(size: 10.5, weight: .bold)).tracking(0.4).foregroundStyle(Theme.ink3)
                Spacer()
                Button("Add photos…") { pickImages() }.buttonStyle(.plain)
                    .font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.accent)
            }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 62, maximum: 62), spacing: 8)], alignment: .leading, spacing: 8) {
                ForEach(refs) { ref in
                    ZStack(alignment: .topTrailing) {
                        Image(nsImage: ref.image).resizable().scaledToFill()
                            .frame(width: 62, height: 78)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                            .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(Theme.border, lineWidth: 0.5))
                        Button(action: { refs.removeAll { $0.id == ref.id } }) {
                            Glyph(name: "close", size: 10, color: Theme.ink2)
                                .frame(width: 18, height: 18).background(Theme.surface).clipShape(Circle())
                                .overlay(Circle().strokeBorder(Theme.borderStrong, lineWidth: 0.5)).cardShadow()
                        }.buttonStyle(.plain).offset(x: 6, y: -6)
                    }
                }
                Button(action: { pickImages() }) {
                    Glyph(name: "plus", size: 18, color: Theme.accent)
                        .frame(width: 62, height: 78)
                        .background(Theme.accentSoft)
                        .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(style: StrokeStyle(lineWidth: 1, dash: [4, 3])).foregroundStyle(Theme.accentLine))
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                }.buttonStyle(.plain)
            }
            .padding(8)
            .background(dragOver ? Theme.accentSoft : Theme.surface2)
            .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(dragOver ? Theme.accent : Theme.border, lineWidth: dragOver ? 1.5 : 0.5))
            .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
            .onDrop(of: [.fileURL, .image], isTargeted: $dragOver) { providers in
                ImageDrop.load(providers) { images in
                    for img in images { if let data = img.pngData() { refs.append(Ref(image: img, newData: data)) } }
                }
                return true
            }
        }
    }

    private func populate() {
        guard let p = store.projects.first(where: { $0.id == projectID }) else { return }
        name = p.product.name
        desc = p.product.desc
        targetCustomers = p.product.targetCustomers
        goal = p.product.goal.isEmpty ? "Sales" : p.product.goal
        languageDisplay = p.product.contentLanguage == "Vietnamese" ? "Tiếng Việt" : "English"
        n = p.personaCount
        m = p.creativesPerPersona
        refs = store.referenceItems(projectID: projectID).map { Ref(image: $0.image, existingFilename: $0.filename) }
        loaded = true
    }

    private func pickImages() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = false
        panel.allowedContentTypes = [.png, .jpeg, .image]
        if panel.runModal() == .OK {
            for url in panel.urls {
                if let data = try? Data(contentsOf: url), let img = NSImage(data: data) {
                    refs.append(Ref(image: img, newData: data))
                }
            }
        }
    }

    private func submit() {
        guard var product = store.projects.first(where: { $0.id == projectID })?.product else { return }
        product.name = name
        product.desc = desc
        product.targetCustomers = targetCustomers
        product.goal = goal
        product.contentLanguage = languageDisplay == "Tiếng Việt" ? "Vietnamese" : "English"
        let keep = refs.compactMap { $0.existingFilename }
        let new = refs.compactMap { $0.newData }
        switch mode {
        case .regenerate:
            store.regenerateProject(project: projectID, product: product, feedback: feedback,
                                    n: n, m: m, keepFilenames: keep, newImages: new)
        case .duplicate:
            store.duplicateAndGenerate(from: projectID, product: product, feedback: feedback,
                                       n: n, m: m, keepFilenames: keep, newImages: new)
        }
    }
}

/// Lightweight sheet for re-generating a single persona's copy. Just a feedback box — the AI rewrites
/// every creative's text honouring the note, then the image grids are resampled (no AI image call).
struct RegeneratePersonaSheet: View {
    let projectID: UUID
    let personaID: UUID
    @EnvironmentObject var store: AppStore
    @State private var feedback = ""

    private var personaName: String {
        store.projects.first(where: { $0.id == projectID })?
            .personas.first(where: { $0.id == personaID })?.name ?? "this persona"
    }

    var body: some View {
        SheetShell(title: "Re-generate persona",
                   sub: "The AI rewrites every creative's copy for “\(personaName)”, then resamples the image grids.",
                   width: 520) {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Feedback / new requirements").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.accent)
                    FormField(label: "", text: $feedback,
                              placeholder: "e.g. punchier hooks, lean into the gift angle, avoid discounts… (optional)",
                              multiline: true)
                }
                HStack {
                    Spacer()
                    AppButton(title: "Re-generate", icon: "refresh", variant: .primary) {
                        store.regeneratePersona(project: projectID, persona: personaID, feedback: feedback)
                        store.activeSheet = nil
                    }
                }
            }
        }
    }
}
