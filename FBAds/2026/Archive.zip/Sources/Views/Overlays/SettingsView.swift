import SwiftUI

struct SettingsSheet: View {
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var store: AppStore

    @State private var openaiDraft = ""
    @State private var geminiDraft = ""

    var body: some View {
        SheetShell(title: "Settings", width: 520) {
            VStack(alignment: .leading, spacing: 0) {
                sectionLabel("API key")
                if settings.keyIsHardcoded {
                    SettingRow(label: "OpenAI", sub: "Used for GPT strategy & gpt-image generation") {
                        HStack(spacing: 6) {
                            Glyph(name: "lock", size: 12, color: Theme.ok)
                            Text("Hardcoded in Secrets.swift").font(.system(size: 12)).foregroundStyle(Theme.ink2)
                        }
                    }
                } else {
                    KeyRow(label: "OpenAI", sub: "Used for GPT strategy & gpt-image generation",
                           draft: $openaiDraft, saved: settings.hasOpenAIKey,
                           masked: mask(settings.openaiKey)) { settings.saveOpenAIKey($0) }
                }
                KeyRow(label: "Gemini", sub: "Used for Nano Banana image generation",
                       draft: $geminiDraft, saved: settings.hasGeminiKey,
                       masked: mask(settings.geminiKey), placeholder: "AI…") { settings.saveGeminiKey($0) }

                sectionLabel("Generation").padding(.top, 18)
                SettingRow(label: "Image backend", sub: "Which model renders the ad images") {
                    Picker("", selection: Binding(get: { settings.imageBackend },
                                                  set: { settings.imageBackend = $0 })) {
                        ForEach(ImageBackend.allCases, id: \.self) { Text($0.short).tag($0) }
                    }.pickerStyle(.segmented).labelsHidden().frame(width: 200)
                }
                SettingRow(label: "Concurrency cap", sub: "Max images generated in parallel") {
                    HStack(spacing: 10) {
                        Slider(value: Binding(get: { Double(settings.concurrency) },
                                              set: { settings.concurrency = Int($0) }), in: 1...8, step: 1)
                            .frame(width: 130).tint(Theme.accent)
                        Text("\(settings.concurrency)").font(.system(size: 14, weight: .bold)).monospacedDigit().frame(width: 18)
                    }
                }
                SettingRow(label: "GPT model", sub: "Strategy, personas & copy") {
                    Picker("", selection: $settings.gptModel) {
                        ForEach(AppSettings.modelOptions, id: \.self) { Text($0).tag($0) }
                    }.labelsHidden().frame(width: 160)
                }
                SettingRow(label: "Auto-retry on 429", sub: "Exponential backoff") {
                    PillToggle(isOn: $settings.autoRetry)
                }

                sectionLabel("AI guidance").padding(.top, 18)
                VStack(alignment: .leading, spacing: 7) {
                    Text("Learnings & rules").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.ink2)
                    LearningsEditor(text: $settings.adLearnings)
                    Text("Notes from past campaigns — angles that work, words to avoid, must-have details. The AI applies these to every generation (strategy, personas, copy & image prompts).")
                        .font(.system(size: 11)).foregroundStyle(Theme.ink3).lineSpacing(1.5)
                }
                .padding(.vertical, 12)

                sectionLabel("New project defaults").padding(.top, 18)
                SettingRow(label: "Objective", sub: "Pre-selected on every new project") {
                    SegmentedControl(selection: $settings.defaultGoal, options: ["Sales", "Leads"])
                }
                SettingRow(label: "Creative language", sub: "Personas, copy, hooks & headlines") {
                    SegmentedControl(selection: $settings.contentLanguage, options: ["English", "Vietnamese"])
                }
                SettingRow(label: "Personas (N)", sub: "Top audiences by value & fit · 1–6") {
                    stepper(value: $settings.defaultPersonas, range: 1...6)
                }
                SettingRow(label: "Creatives / persona (M)", sub: "Top concepts per persona · 3–10") {
                    stepper(value: $settings.defaultCreatives, range: 3...10)
                }
                SettingRow(label: "Aspect ratio", sub: "Seeded into every new creative") {
                    Picker("", selection: $settings.defaultRatio) {
                        ForEach(AdRatio.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                    }.pickerStyle(.segmented).labelsHidden().frame(width: 120)
                }
                SettingRow(label: "Hook text style", sub: "Preset for the on-image hook caption") {
                    Picker("", selection: Binding(get: { settings.defaultHookStyle },
                                                  set: { settings.defaultHookStyle = $0 })) {
                        ForEach(HookStyle.allCases, id: \.self) { Text($0.label).tag($0) }
                    }.labelsHidden().frame(width: 170)
                }

                sectionLabel("Output").padding(.top, 18)
                SettingRow(label: "Save folder", sub: "Default export location") {
                    Button(action: pickFolder) {
                        HStack(spacing: 5) {
                            Glyph(name: "folder", size: 12, color: Theme.ink2)
                            Text(settings.exportFolderDisplay).font(.system(size: 12)).foregroundStyle(Theme.ink2)
                                .lineLimit(1).truncationMode(.middle)
                        }
                        .frame(maxWidth: 200)
                    }.buttonStyle(.plain)
                }
                SettingRow(label: "Default text font", sub: "Text-on-image renderer") {
                    Picker("", selection: $settings.defaultFont) {
                        ForEach(AppSettings.fontOptions, id: \.self) { Text($0).tag($0) }
                    }.labelsHidden().frame(width: 170)
                }
            }
        }
        .onAppear { openaiDraft = ""; geminiDraft = "" }
    }

    /// Compact inline −/value/+ stepper sized for a settings row (the big NumberStepper card
    /// from the input screen is too tall here).
    private func stepper(value: Binding<Int>, range: ClosedRange<Int>) -> some View {
        HStack(spacing: 10) {
            stepBtn(icon: "minus", enabled: value.wrappedValue > range.lowerBound) {
                value.wrappedValue = max(range.lowerBound, value.wrappedValue - 1)
            }
            Text("\(value.wrappedValue)").font(.system(size: 14, weight: .bold)).monospacedDigit().frame(width: 18)
            stepBtn(icon: "plus", enabled: value.wrappedValue < range.upperBound) {
                value.wrappedValue = min(range.upperBound, value.wrappedValue + 1)
            }
        }
    }

    private func stepBtn(icon: String, enabled: Bool, action: @escaping () -> Void) -> some View {
        Button(action: { if enabled { action() } }) {
            Glyph(name: icon, size: 12, weight: .semibold, color: enabled ? Theme.ink : Theme.ink4)
                .frame(width: 26, height: 26)
                .background(enabled ? Theme.surface : Theme.surface2)
                .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: 7))
        }.buttonStyle(.plain)
    }

    private func sectionLabel(_ t: String) -> some View {
        Text(t.uppercased()).font(.system(size: 10.5, weight: .bold)).tracking(0.5)
            .foregroundStyle(Theme.ink3).padding(.bottom, 2)
    }

    private func mask(_ key: String) -> String {
        guard key.count > 8 else { return key.isEmpty ? "" : "••••" }
        return String(key.prefix(6)) + "…" + String(key.suffix(4))
    }

    private func pickFolder() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.prompt = "Choose"
        if panel.runModal() == .OK, let url = panel.url { settings.setExportFolder(url) }
    }
}

struct SettingRow<Trailing: View>: View {
    let label: String
    var sub: String? = nil
    @ViewBuilder let trailing: Trailing

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 1) {
                Text(label).font(.system(size: 13, weight: .semibold))
                if let sub { Text(sub).font(.system(size: 11.5)).foregroundStyle(Theme.ink3) }
            }
            Spacer()
            trailing
        }
        .padding(.vertical, 12)
        .overlay(alignment: .bottom) { Rectangle().fill(Theme.border).frame(height: 0.5) }
    }
}

/// Multiline editor for the persistent AI learnings. Edits a LOCAL draft so each keystroke only
/// re-renders this small view. Binding the TextEditor straight to `settings.adLearnings` wrote to
/// the app-wide `AppSettings` on every character, invalidating every view observing it (the whole
/// app) — that caused the typing lag. The draft is committed back when the field loses focus or
/// the sheet closes. Mirrors the commit-on-blur pattern in `AdImageView`.
private struct LearningsEditor: View {
    @Binding var text: String
    @State private var draft = ""
    @FocusState private var focused: Bool

    var body: some View {
        TextEditor(text: $draft)
            .font(.system(size: 13)).foregroundStyle(Theme.ink)
            .scrollContentBackground(.hidden)
            .frame(minHeight: 96)
            .padding(.horizontal, 7).padding(.vertical, 6)
            .background(Theme.surface)
            .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
            .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
            .cardShadow()
            .focused($focused)
            .onAppear { draft = text }
            .onChange(of: focused) { _, isFocused in if !isFocused { commit() } }
            .onDisappear { commit() }
    }

    private func commit() { if draft != text { text = draft } }
}

struct KeyRow: View {
    let label: String
    let sub: String
    @Binding var draft: String
    let saved: Bool
    let masked: String
    var placeholder: String = "sk-…"
    let onSave: (String) -> Void
    @State private var editing = false

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 1) {
                Text(label).font(.system(size: 13, weight: .semibold))
                Text(sub).font(.system(size: 11.5)).foregroundStyle(Theme.ink3)
            }
            Spacer()
            if saved && !editing {
                HStack(spacing: 6) {
                    Glyph(name: "check", size: 12, color: Theme.ok)
                    Text(masked).font(.system(size: 12, design: .monospaced)).foregroundStyle(Theme.ink2)
                    Text("Saved").font(.system(size: 10, weight: .semibold)).foregroundStyle(Theme.ok)
                }
                .padding(.horizontal, 10).padding(.vertical, 6)
                .background(Theme.surface2)
                .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(Theme.border, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: 7))
                Button("Change") { editing = true }.buttonStyle(.plain)
                    .font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.accent)
            } else {
                HStack(spacing: 6) {
                    SecureField(placeholder, text: $draft)
                        .textFieldStyle(.plain).font(.system(size: 12, design: .monospaced))
                        .frame(width: 180)
                        .padding(.horizontal, 9).padding(.vertical, 6)
                        .background(Theme.surface)
                        .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
                        .clipShape(RoundedRectangle(cornerRadius: 7))
                    AppButton(title: "Save", variant: .soft, size: .sm,
                              disabled: draft.trimmingCharacters(in: .whitespaces).isEmpty) {
                        onSave(draft); draft = ""; editing = false
                    }
                }
            }
        }
        .padding(.vertical, 12)
        .overlay(alignment: .bottom) { Rectangle().fill(Theme.border).frame(height: 0.5) }
    }
}
