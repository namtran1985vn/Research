import SwiftUI

// MARK: - Sheet shell

struct SheetShell<Content: View>: View {
    let title: String
    var sub: String? = nil
    var width: CGFloat = 540
    let content: Content
    @EnvironmentObject var store: AppStore

    init(title: String, sub: String? = nil, width: CGFloat = 540, @ViewBuilder content: () -> Content) {
        self.title = title; self.sub = sub; self.width = width; self.content = content()
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .top, spacing: 10) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.system(size: 16, weight: .bold)).tracking(-0.1)
                    if let sub { Text(sub).font(.system(size: 12)).foregroundStyle(Theme.ink2) }
                }
                Spacer()
                Button(action: { store.activeSheet = nil }) {
                    Glyph(name: "close", size: 15, color: Theme.ink2)
                        .frame(width: 28, height: 28).background(Theme.surface)
                        .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(Theme.border, lineWidth: 0.5))
                        .clipShape(RoundedRectangle(cornerRadius: 7))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 18).padding(.vertical, 15)
            Divider().overlay(Theme.border)
            ScrollView { content.padding(18) }
                .scrollIndicators(.automatic)
        }
        // Cap against the logical canvas so the sheet stays inside the window at any zoom level.
        .frame(width: min(width, store.canvasSize.width - 40))
        .frame(maxHeight: min(640, store.canvasSize.height - 40))
        .background(Theme.bgWindow)
    }
}

// MARK: - Persona ranking

struct PersonaRankingSheet: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        SheetShell(title: "Persona ranking",
                   sub: "Why these personas made the cut — add more anytime; AI generates them in the same context.",
                   width: 600) {
            VStack(spacing: 7) {
                ForEach(Array((store.selectedProject?.ranking ?? []).enumerated()), id: \.element.id) { idx, r in
                    HStack(spacing: 12) {
                        Text("\(idx + 1)").font(.system(size: 12, weight: .bold)).monospacedDigit()
                            .foregroundStyle(Theme.ink3).frame(width: 18)
                        VStack(alignment: .leading, spacing: 4) {
                            HStack(spacing: 8) {
                                Text(r.name).font(.system(size: 13, weight: .bold))
                                AudienceTag(audience: r.audience)
                                if r.picked {
                                    Tag(text: "✓ Selected", color: Theme.ok, bg: Theme.okBg, line: Theme.okLine)
                                } else {
                                    Tag(text: "Not selected")
                                }
                                Spacer(minLength: 0)
                                if !r.picked, let pid = store.selectedProjectID {
                                    if store.addingPersonaIDs.contains(r.id) {
                                        HStack(spacing: 6) {
                                            Spinner(size: 12, lineWidth: 1.6, track: Theme.accentLine, tint: Theme.accent)
                                            Text("Adding…").font(.system(size: 11.5, weight: .semibold))
                                                .foregroundStyle(Theme.ink3)
                                        }
                                    } else {
                                        AppButton(title: "Add", icon: "plus", variant: .soft, size: .sm) {
                                            store.addPersona(project: pid, fromRanking: r)
                                        }
                                    }
                                }
                            }
                            Text(r.why).font(.system(size: 11.5)).foregroundStyle(Theme.ink2).lineSpacing(1)
                            ProgressBar(fraction: Double(r.score) / 100).frame(height: 5).padding(.top, 3)
                        }
                        Text("\(r.score)").font(.system(size: 18, weight: .bold)).monospacedDigit()
                            .foregroundStyle(r.picked ? Theme.accentInk : Theme.ink3)
                            .frame(width: 34, alignment: .trailing)
                    }
                    .padding(.horizontal, 13).padding(.vertical, 11)
                    .background(r.picked ? Theme.accentSoft : Theme.surface)
                    .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(r.picked ? Theme.accentLine : Theme.border, lineWidth: 0.5))
                    .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
                    .opacity(r.picked ? 1 : 0.85)
                }

                // Add a brand-new persona (AI invents it in-context, optionally from your brief).
                HStack(spacing: 10) {
                    if store.addingCustomPersona {
                        Spinner(size: 14, lineWidth: 1.8, track: Theme.accentLine, tint: Theme.accent)
                        Text("Generating persona…").font(.system(size: 12, weight: .semibold)).foregroundStyle(Theme.ink2)
                    } else if !store.addingPersonaIDs.isEmpty {
                        Spinner(size: 14, lineWidth: 1.8, track: Theme.accentLine, tint: Theme.accent)
                        Text("Adding \(store.addingPersonaIDs.count) persona… you can keep adding")
                            .font(.system(size: 12, weight: .semibold)).foregroundStyle(Theme.ink2)
                    } else {
                        Glyph(name: "user", size: 14, color: Theme.accent)
                        Text("Want a different angle?").font(.system(size: 12)).foregroundStyle(Theme.ink2)
                    }
                    Spacer()
                    if let pid = store.selectedProjectID {
                        RegenerateControl(title: "Add a new persona", placeholder: "Optional: describe who to target…",
                                          compact: false, label: "Add persona", icon: "plus", busy: store.addingCustomPersona,
                                          suggestions: ["Younger buyers", "Gift shoppers", "Budget-conscious", "Eco-minded"]) { instr in
                            store.addPersona(project: pid, instruction: instr)
                        }
                    }
                }
                .padding(.horizontal, 13).padding(.vertical, 11)
                .background(Theme.surface2)
                .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.border, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
                .padding(.top, 4)
            }
        }
    }
}

// MARK: - Toast

struct ToastView: View {
    let toast: Toast
    var body: some View {
        HStack(spacing: 9) {
            Glyph(name: toast.isError ? "warn" : "check", size: 14,
                  color: toast.isError ? Color(hex: 0xE8A99C) : Color(hex: 0x9FD3AC))
            Text(toast.message).font(.system(size: 12.5, weight: .semibold)).foregroundStyle(Color(hex: 0xFBF7EE))
        }
        .padding(.horizontal, 15).padding(.vertical, 9)
        .background(Color(hex: 0x211E18).opacity(0.92))
        .clipShape(Capsule())
        .popShadow()
        .transition(.move(edge: .bottom).combined(with: .opacity))
    }
}
