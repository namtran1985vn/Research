import SwiftUI
import UniformTypeIdentifiers

struct InputScreen: View {
    @EnvironmentObject var store: AppStore

    @State private var name = ""
    @State private var desc = ""
    @State private var goal = "Sales"
    @State private var targetCustomers = ""
    @State private var languageDisplay = "English"   // "English" | "Tiếng Việt"
    @State private var n = 3
    @State private var m = 5
    @State private var images: [DroppedImage] = []
    @State private var dragOver = false

    private var valid: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty &&
        !desc.trimmingCharacters(in: .whitespaces).isEmpty
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 8) {
                    Glyph(name: "plus", size: 15, color: Theme.accent)
                    Text("NEW PROJECT").font(.system(size: 11.5, weight: .bold)).tracking(0.6).foregroundStyle(Theme.accent)
                }
                Text("Describe your product")
                    .font(.system(size: 26, weight: .bold)).tracking(-0.5)
                    .padding(.top, 4)
                Text("Drop in a few product photos and the essentials. GPT will rank the personas worth targeting and draft ranked ad creatives for each — then generate the images.")
                    .font(.system(size: 13.5)).foregroundStyle(Theme.ink2).lineSpacing(3)
                    .frame(maxWidth: 520, alignment: .leading)
                    .padding(.top, 4).padding(.bottom, 26)

                dropZone
                    .padding(.bottom, 22)

                VStack(spacing: 16) {
                    FormField(label: "Product name", text: $name, placeholder: "e.g. Auria LED Therapy Mask", required: true)
                    FormField(label: "Description", text: $desc, placeholder: "What it is, who it helps, why it's different…", required: true, multiline: true)
                    FormField(label: "Anything else you want the AI to know",
                              text: $targetCustomers,
                              placeholder: "Anything important: who to target, offer, price, angle, must-have details, things to avoid…",
                              multiline: true)
                    HStack(alignment: .top, spacing: 28) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Objective").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.ink2)
                            SegmentedControl(selection: $goal, options: ["Sales", "Leads"])
                        }
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Creative language").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.ink2)
                            SegmentedControl(selection: $languageDisplay, options: ["English", "Tiếng Việt"])
                        }
                        Spacer(minLength: 0)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.bottom, 22)

                HStack(spacing: 14) {
                    NumberStepper(label: "Personas (N)", sub: "Top by value & fit · 1–6", value: $n, range: 1...6)
                    NumberStepper(label: "Creatives / persona (M)", sub: "Top concepts · 3–10", value: $m, range: 3...10)
                    totalCard
                }

                HStack(spacing: 14) {
                    AppButton(title: store.analyzing ? "Analyzing & building strategy…" : "Analyze & build strategy",
                              icon: store.analyzing ? nil : "sparkle", variant: .primary, size: .lg,
                              disabled: !valid || store.analyzing) { runAnalyze() }
                    if store.analyzing { Spinner(size: 16, lineWidth: 2, track: Theme.accentLine, tint: Theme.accent) }
                    Text(valid ? "⌘↵ to run" : "Add a name and description to continue")
                        .font(.system(size: 11.5)).foregroundStyle(Theme.ink3)
                }
                .padding(.top, 22)
            }
            .frame(maxWidth: 720, alignment: .leading)
            .padding(.horizontal, 32).padding(.top, 40).padding(.bottom, 56)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.automatic)
        .background(Theme.bgWindow)
        .background {
            Button("") { if valid { runAnalyze() } }
                .keyboardShortcut(.return, modifiers: .command).opacity(0).frame(width: 0, height: 0)
        }
        .onAppear {
            // Seed the per-project fields from the New-project defaults in Settings.
            languageDisplay = store.settings.contentLanguage == "Vietnamese" ? "Tiếng Việt" : "English"
            goal = store.settings.defaultGoal
            n = store.settings.defaultPersonas
            m = store.settings.defaultCreatives
        }
    }

    private var totalCard: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text("TOTAL").font(.system(size: 11, weight: .bold)).tracking(0.4).foregroundStyle(Theme.accent)
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text("\(n * m)").font(.system(size: 28, weight: .bold)).tracking(-0.5)
                Text("creatives").font(.system(size: 13, weight: .semibold))
            }
            .foregroundStyle(Theme.accentInk)
            Text("\(n) ad sets · \(m) each").font(.system(size: 11)).foregroundStyle(Theme.accentInk.opacity(0.8))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(Theme.accentSoft)
        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.card).strokeBorder(Theme.accentLine, lineWidth: 0.5))
        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.card))
    }

    private var dropZone: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 7) {
                Glyph(name: "upload", size: 15, color: Theme.accent)
                Text("Drag product photos here").font(.system(size: 13, weight: .semibold)).foregroundStyle(Theme.ink)
                Spacer(minLength: 0)
                Text("\(images.count) added").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.ink3)
                Button("Choose photos…") { pickImages() }
                    .buttonStyle(.plain)
                    .font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.accent)
            }
            Text("Add as many product photos / angles as you like. Each image is generated from a random one of these samples — keeping the product's exact details and patterns.")
                .font(.system(size: 11.5)).foregroundStyle(Theme.ink3).lineSpacing(1.5)

            if !images.isEmpty {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 76, maximum: 76), spacing: 10)],
                          alignment: .leading, spacing: 10) {
                    ForEach(images) { img in
                        ZStack(alignment: .topTrailing) {
                            Image(nsImage: img.nsImage)
                                .resizable().scaledToFill()
                                .frame(width: 76, height: 95)
                                .clipShape(RoundedRectangle(cornerRadius: 9))
                                .overlay(RoundedRectangle(cornerRadius: 9).strokeBorder(Theme.border, lineWidth: 0.5))
                                .cardShadow()
                            Button(action: { images.removeAll { $0.id == img.id } }) {
                                Glyph(name: "close", size: 11, color: Theme.ink2)
                                    .frame(width: 20, height: 20).background(Theme.surface)
                                    .clipShape(Circle())
                                    .overlay(Circle().strokeBorder(Theme.borderStrong, lineWidth: 0.5))
                                    .cardShadow()
                            }
                            .buttonStyle(.plain).offset(x: 7, y: -7)
                        }
                    }
                }
                .padding(.top, 2)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(dragOver ? Theme.accentSoft : Theme.surface2)
        .overlay(
            RoundedRectangle(cornerRadius: Theme.Radius.card)
                .strokeBorder(style: StrokeStyle(lineWidth: 1.5, dash: [6, 4]))
                .foregroundStyle(dragOver ? Theme.accent : Theme.borderStrong))
        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.card))
        .onDrop(of: [.fileURL, .image], isTargeted: $dragOver) { providers in
            handleDrop(providers); return true
        }
    }

    // MARK: Image handling

    private func pickImages() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = false
        panel.allowedContentTypes = [.png, .jpeg, .image]
        if panel.runModal() == .OK {
            for url in panel.urls { addImageData(try? Data(contentsOf: url)) }
        }
    }

    private func handleDrop(_ providers: [NSItemProvider]) {
        for provider in providers {
            if provider.canLoadObject(ofClass: NSImage.self) {
                _ = provider.loadObject(ofClass: NSImage.self) { obj, _ in
                    if let img = obj as? NSImage, let data = img.pngData() {
                        DispatchQueue.main.async { addImageData(data) }
                    }
                }
            } else if provider.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) {
                _ = provider.loadObject(ofClass: URL.self) { url, _ in
                    if let url, let data = try? Data(contentsOf: url) {
                        DispatchQueue.main.async { addImageData(data) }
                    }
                }
            }
        }
    }

    private func addImageData(_ data: Data?) {
        guard let data, let img = NSImage(data: data) else { return }
        images.append(DroppedImage(data: data, nsImage: img))
    }

    private func runAnalyze() {
        let language = languageDisplay == "Tiếng Việt" ? "Vietnamese" : "English"
        let product = Product(name: name, desc: desc, goal: goal,
                              targetCustomers: targetCustomers, contentLanguage: language)
        store.analyze(product: product, referenceImages: images.map(\.data), n: n, m: m)
    }
}

struct DroppedImage: Identifiable {
    let id = UUID()
    let data: Data
    let nsImage: NSImage
}
