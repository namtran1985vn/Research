import SwiftUI

struct ToolbarBar: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        let project = store.selectedProject
        let totals = project?.totals ?? Project.Totals()
        let failed = project?.failedCount ?? 0

        HStack(spacing: 9) {
            AppButton(icon: "sidebar", variant: .ghost) { store.sidebarOpen.toggle() }
                .help("Toggle sidebar (⌃⌘S)")

            // Title / breadcrumb
            HStack(spacing: 7) {
                Text(store.screen == .input ? "New project" : (project?.name ?? "Ad Creative Studio"))
                    .font(.system(size: 13.5, weight: .bold)).tracking(-0.1)
                    .lineLimit(1)
                if store.screen == .results {
                    Glyph(name: "chevron", size: 13, color: Theme.ink4)
                    if let project, !project.personas.isEmpty {
                        PersonaBreadcrumbMenu(project: project)
                    } else {
                        Text("Creatives").font(.system(size: 13)).foregroundStyle(Theme.ink3)
                    }
                }
            }

            Spacer(minLength: 8)

            if store.screen == .results && store.engine.isRunning {
                GlobalProgress(done: totals.done, total: totals.total) { store.cancelBatch() }
            }

            if store.screen == .results && failed > 0 && !store.engine.isRunning {
                Button(action: { store.retryAll() }) {
                    HStack(spacing: 6) {
                        Glyph(name: "warn", size: 13, color: Theme.err)
                        Text("Failed (\(failed)) · Retry all").font(.system(size: 12, weight: .semibold))
                    }
                    .foregroundStyle(Theme.err)
                    .padding(.horizontal, 11).padding(.vertical, 5)
                    .background(Theme.errBg)
                    .overlay(Capsule().strokeBorder(Theme.errLine, lineWidth: 0.5))
                    .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }

            AppButton(icon: "plus", variant: .ghost, action: { store.startNewProject() })

            if store.screen == .results {
                AppButton(title: "Export", icon: "export", variant: .secondary) { store.exportAll() }
                Button(action: { store.inspectorOpen.toggle() }) {
                    Glyph(name: "sliders", size: 16,
                          color: store.inspectorOpen ? Theme.accentInk : Theme.ink2)
                        .frame(width: 31, height: 31)
                        .background(store.inspectorOpen ? Theme.accentSoft : Theme.surface)
                        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
                        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
                        .cardShadow()
                }
                .buttonStyle(.plain)
                .help("Toggle inspector")
            }

            AppButton(icon: "settings", variant: .ghost, action: { store.activeSheet = .settings })
        }
        .padding(.leading, store.sidebarOpen ? 14 : 78)   // clear the traffic lights when collapsed
        .padding(.trailing, 14)
        .frame(height: 52)
        .background(Theme.bgWindow)
    }
}

/// Breadcrumb dropdown that switches the selected persona within the current campaign.
/// Sits where the static "Creatives" label used to be: "Campaign  ›  [Persona ▾]".
struct PersonaBreadcrumbMenu: View {
    @EnvironmentObject var store: AppStore
    let project: Project

    var body: some View {
        let current = store.selectedPersona
        Menu {
            ForEach(project.personas) { persona in
                Button {
                    store.selectPersona(persona.id)
                } label: {
                    // Checkmark marks the active persona; plain text for the rest.
                    if persona.id == current?.id {
                        Label(persona.name, systemImage: "checkmark")
                    } else {
                        Text(persona.name)
                    }
                }
            }
        } label: {
            HStack(spacing: 4) {
                Text(current?.name ?? "Creatives")
                    .font(.system(size: 13)).foregroundStyle(Theme.ink3).lineLimit(1)
                Image(systemName: "chevron.down")
                    .font(.system(size: 8, weight: .bold)).foregroundStyle(Theme.ink4)
            }
            .contentShape(Rectangle())
        }
        .menuStyle(.button)
        .buttonStyle(.plain)
        .menuIndicator(.hidden)
        .fixedSize()
        .help("Switch persona")
    }
}

/// The pill batch-progress indicator shown in the toolbar while images generate.
struct GlobalProgress: View {
    let done: Int
    let total: Int
    let onCancel: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            Spinner(size: 13, lineWidth: 1.6)
            Text("\(done)/\(total) images")
                .font(.system(size: 12, weight: .semibold)).monospacedDigit()
                .foregroundStyle(Theme.ink)
                .fixedSize()
            ProgressBar(fraction: total > 0 ? Double(done) / Double(total) : 0).frame(width: 92, height: 5)
            Button(action: onCancel) {
                Glyph(name: "close", size: 12, color: Theme.ink2)
                    .frame(width: 24, height: 24)
                    .background(Theme.surface2)
                    .overlay(RoundedRectangle(cornerRadius: 6).strokeBorder(Theme.border, lineWidth: 0.5))
                    .clipShape(RoundedRectangle(cornerRadius: 6))
            }
            .buttonStyle(.plain)
            .help("Cancel batch")
        }
        .padding(.leading, 12).padding(.trailing, 6).padding(.vertical, 5)
        .background(Theme.surface)
        .overlay(Capsule().strokeBorder(Theme.borderStrong, lineWidth: 0.5))
        .clipShape(Capsule())
        .cardShadow()
    }
}

struct ProgressBar: View {
    let fraction: Double
    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Capsule().fill(Theme.surface3)
                Capsule().fill(Theme.progressGradient)
                    .frame(width: max(0, min(1, fraction)) * geo.size.width)
                    .animation(.easeOut(duration: 0.4), value: fraction)
            }
        }
    }
}
