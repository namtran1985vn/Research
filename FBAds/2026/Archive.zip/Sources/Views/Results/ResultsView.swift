import SwiftUI

struct ResultsView: View {
    @EnvironmentObject var store: AppStore
    @State private var filter = "all"
    @State private var adjustCID: UUID?   // creative whose image-adjust editor is open (double-click)

    var body: some View {
        if let project = store.selectedProject {
            if project.isAnalyzing {
                AnalyzingView(name: project.name)
            } else if project.analyzeFailed {
                AnalyzeFailedView(message: project.analyzeErrorMessage,
                                  onRetry: { store.retryAnalyze(project: project.id) },
                                  onNew: { store.startNewProject() })
            } else if let persona = store.selectedPersona {
                content(project: project, persona: persona)
            } else {
                EmptyResults()
            }
        } else {
            EmptyResults()
        }
    }

    private func content(project: Project, persona: Persona) -> some View {
        let creatives = filteredSorted(persona.creatives)
        let queueOrder = persona.creatives.filter { $0.status == .queued }.map(\.id)

        return ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                OfferHeader(offer: project.offer)
                    .padding(.bottom, 16)
                PersonaHeader(persona: persona,
                              personaCount: project.personaCount,
                              onGenerateSet: { store.generatePersona(project: project.id, persona: persona.id) })
                    .padding(.bottom, 14)
                FilterBar(filter: $filter, counts: counts(persona.creatives))
                    .padding(.bottom, 14)

                if creatives.isEmpty {
                    Text("Nothing matches this filter.")
                        .font(.system(size: 13)).foregroundStyle(Theme.ink3)
                        .frame(maxWidth: .infinity).padding(.vertical, 48)
                } else {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 158, maximum: 213), spacing: 16, alignment: .top)],
                              alignment: .leading, spacing: 16) {
                        ForEach(creatives) { c in
                            CreativeCardView(
                                creative: c, persona: persona, projectID: project.id,
                                selected: store.selectedCreativeID == c.id,
                                queuePos: queueOrder.firstIndex(of: c.id).map { $0 + 1 },
                                onSelect: { store.selectedCreativeID = c.id; if !store.inspectorOpen { store.inspectorOpen = true } },
                                onGenerate: { store.generateOne(project: project.id, persona: persona.id, creative: c.id) },
                                onToggleWinner: { store.toggleWinner(project: project.id, creative: c.id) },
                                onCopy: { store.copyToPasteboard(c.primaryText, kind: "Primary text") },
                                onEditImage: { if c.imageFilename != nil { adjustCID = c.id } })
                        }
                    }
                }
            }
            .frame(maxWidth: 1080, alignment: .leading)
            .padding(.horizontal, 22).padding(.top, 18).padding(.bottom, 40)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.automatic)
        .background(Theme.bgWindow)
        .sheet(isPresented: Binding(get: { adjustCID != nil }, set: { if !$0 { adjustCID = nil } })) {
            if let cid = adjustCID, let c = persona.creatives.first(where: { $0.id == cid }) {
                ImageAdjustSheet(projectID: project.id, creativeID: cid, initial: c.adjustments)
                    .environmentObject(store)
            }
        }
    }

    private func filteredSorted(_ list: [Creative]) -> [Creative] {
        var out = list
        switch filter {
        case "done":   out = out.filter { $0.status == .done }
        case "winner": out = out.filter { $0.winner }
        case "todo":   out = out.filter { $0.status.needsGeneration }
        default: break
        }
        out.sort { $0.rank < $1.rank }
        return out
    }

    private func counts(_ list: [Creative]) -> [String: Int] {
        ["all": list.count,
         "done": list.filter { $0.status == .done }.count,
         "winner": list.filter { $0.winner }.count,
         "todo": list.filter { $0.status.needsGeneration }.count]
    }
}

// MARK: - Offer header

struct OfferHeader: View {
    let offer: Offer
    @EnvironmentObject var store: AppStore
    @State private var open = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button(action: { withAnimation(.easeOut(duration: 0.15)) { open.toggle() } }) {
                HStack(spacing: 9) {
                    Glyph(name: "sparkle", size: 15, color: Theme.accent)
                    Text("Recommended offer").font(.system(size: 12.5, weight: .bold))
                    if !open {
                        Text(offer.chosen).font(.system(size: 12)).foregroundStyle(Theme.ink2).lineLimit(1)
                    }
                    Spacer(minLength: 8)
                    Glyph(name: "chevDown", size: 15, color: Theme.ink3)
                        .rotationEffect(.degrees(open ? 0 : -90))
                }
                .padding(.horizontal, 14).padding(.vertical, 11)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if open {
                VStack(alignment: .leading, spacing: 0) {
                    Text(offer.chosen)
                        .font(.system(size: 13, weight: .semibold)).foregroundStyle(Theme.accentInk).lineSpacing(2)
                        .padding(.horizontal, 12).padding(.vertical, 10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Theme.accentSoft)
                        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.accentLine, lineWidth: 0.5))
                        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
                    Text(offer.rationale).font(.system(size: 12)).foregroundStyle(Theme.ink2).lineSpacing(2)
                        .padding(.top, 9).padding(.bottom, 10)
                    HStack(spacing: 8) {
                        Text("Alternatives:").font(.system(size: 11, weight: .semibold)).foregroundStyle(Theme.ink3)
                        ForEach(Array(offer.alternatives.enumerated()), id: \.offset) { _, a in
                            Tag(text: a)
                        }
                        Spacer(minLength: 0)
                        Button(action: { store.activeSheet = .ranking }) {
                            HStack(spacing: 4) {
                                Glyph(name: "rank", size: 13, color: Theme.accent)
                                Text("View persona ranking").font(.system(size: 12, weight: .semibold))
                            }.foregroundStyle(Theme.accent)
                        }.buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 14).padding(.bottom, 13)
            }
        }
        .background(Theme.surface)
        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.card).strokeBorder(Theme.border, lineWidth: 0.5))
        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.card))
        .cardShadow()
    }
}

// MARK: - Persona header

struct PersonaHeader: View {
    let persona: Persona
    let personaCount: Int
    let onGenerateSet: () -> Void
    @EnvironmentObject var store: AppStore
    /// Persona description + insight rows are collapsed by default; the user expands on demand.
    @State private var detailsOpen = false

    private var remaining: Int { persona.creatives.filter { $0.status.needsGeneration }.count }

    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            // ── Title row: name + meta pills on the left, primary action pinned top-right.
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 8) {
                    Text(persona.name).font(.system(size: 20, weight: .bold)).tracking(-0.4)
                        .fixedSize(horizontal: false, vertical: true)
                    HStack(spacing: 6) {
                        AudienceTag(audience: persona.audience)
                        scorePill
                        detailsToggle
                    }
                }
                Spacer(minLength: 12)
                AppButton(title: remaining > 0 ? "Generate this set (\(remaining))" : "Generate this set",
                          icon: "sparkle", variant: .secondary, disabled: remaining == 0, action: onGenerateSet)
                    .fixedSize()
            }

            if detailsOpen {
                // ── Persona description.
                Text(persona.desc).font(.system(size: 12.5)).foregroundStyle(Theme.ink2).lineSpacing(2.5)
                    .fixedSize(horizontal: false, vertical: true)

                // ── Insight rows: consistent, scannable. LTV (neutral) + Why (accent, opens ranking).
                VStack(spacing: 8) {
                    insightRow(icon: "dollar", label: "LTV", text: persona.ltv,
                               tint: Theme.ink2, bg: Theme.surface2, line: Theme.border, action: nil)
                    insightRow(icon: "rank", label: "Why this persona made the top \(personaCount)",
                               text: persona.reasonTop, tint: Theme.accentInk,
                               bg: Theme.accentSoft, line: Theme.accentLine,
                               action: { store.activeSheet = .ranking })
                }
            }
        }
    }

    /// Disclosure pill that expands/collapses the persona's description + insight rows.
    private var detailsToggle: some View {
        Button { withAnimation(.easeOut(duration: 0.16)) { detailsOpen.toggle() } } label: {
            HStack(spacing: 3) {
                Glyph(name: "chevron", size: 9, weight: .semibold, color: Theme.ink3)
                    .rotationEffect(.degrees(detailsOpen ? 90 : 0))
                Text(detailsOpen ? "Hide" : "Details").font(.system(size: 11, weight: .semibold)).foregroundStyle(Theme.ink3)
            }
            .padding(.horizontal, 8).padding(.vertical, 2.5)
            .background(Theme.surface2)
            .overlay(Capsule().strokeBorder(Theme.border, lineWidth: 0.5))
            .clipShape(Capsule())
        }
        .buttonStyle(.plain)
        .help(detailsOpen ? "Hide persona details" : "Show persona details")
    }

    private var scorePill: some View {
        HStack(spacing: 3) {
            Glyph(name: "star", size: 10.5, color: Theme.accent)
            Text("\(persona.score)").font(.system(size: 11, weight: .bold)).monospacedDigit()
                .foregroundStyle(Theme.accentInk)
        }
        .padding(.horizontal, 8).padding(.vertical, 2.5)
        .background(Theme.accentSoft)
        .overlay(Capsule().strokeBorder(Theme.accentLine, lineWidth: 0.5))
        .clipShape(Capsule())
    }

    @ViewBuilder
    private func insightRow(icon: String, label: String, text: String,
                            tint: Color, bg: Color, line: Color, action: (() -> Void)?) -> some View {
        let content = HStack(alignment: .top, spacing: 8) {
            Glyph(name: icon, size: 12.5, color: tint).padding(.top, 1.5)
            (Text(label + ":  ").font(.system(size: 12, weight: .bold)) + Text(text).font(.system(size: 12)))
                .foregroundStyle(tint).lineSpacing(2)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 4)
            if action != nil { Glyph(name: "chevron", size: 11, color: tint.opacity(0.55)).padding(.top, 2) }
        }
        .padding(.horizontal, 12).padding(.vertical, 9)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(bg)
        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(line, lineWidth: 0.5))
        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))

        if let action {
            Button(action: action) { content }.buttonStyle(.plain)
        } else {
            content
        }
    }
}

// MARK: - Filter bar

struct FilterBar: View {
    @Binding var filter: String
    let counts: [String: Int]

    var body: some View {
        HStack(spacing: 7) {
            chip("all", "All")
            chip("done", "Ready")
            chip("winner", "♡ Winners")
            chip("todo", "Not generated")
            Spacer(minLength: 0)
        }
    }

    private func chip(_ id: String, _ label: String) -> some View {
        let active = filter == id
        let n = counts[id] ?? 0
        return Button(action: { filter = id }) {
            HStack(spacing: 5) {
                Text(label).font(.system(size: 12, weight: .semibold))
                Text("\(n)").font(.system(size: 10.5)).monospacedDigit().opacity(0.7)
            }
            .foregroundStyle(active ? Theme.accentInk : Theme.ink2)
            .padding(.horizontal, 11).padding(.vertical, 4)
            .background(active ? Theme.accentSoft : Theme.surface)
            .overlay(Capsule().strokeBorder(active ? Theme.accentLine : Theme.border, lineWidth: 0.5))
            .clipShape(Capsule())
            .modifier(ChipShadow(active: active))
        }.buttonStyle(.plain)
    }
}

private struct ChipShadow: ViewModifier {
    let active: Bool
    func body(content: Content) -> some View { active ? AnyView(content) : AnyView(content.cardShadow()) }
}

// MARK: - Empty state

// MARK: - Loading skeleton (while GPT builds the strategy in the background)

struct AnalyzingView: View {
    let name: String
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack(spacing: 9) {
                    Spinner(size: 15, lineWidth: 2, track: Theme.accentLine, tint: Theme.accent)
                    Text("Building your strategy…").font(.system(size: 13, weight: .semibold)).foregroundStyle(Theme.ink2)
                    Spacer()
                }
                skeleton(height: 96)                 // offer card
                skeleton(height: 64)                 // persona header
                HStack(spacing: 7) { ForEach(0..<4, id: \.self) { _ in skeleton(height: 28, width: 88, radius: 999) }; Spacer() }
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 158, maximum: 213), spacing: 16, alignment: .top)],
                          alignment: .leading, spacing: 16) {
                    ForEach(0..<6, id: \.self) { _ in cardSkeleton }
                }
            }
            .frame(maxWidth: 1080, alignment: .leading)
            .padding(.horizontal, 22).padding(.top, 18).padding(.bottom, 40)
            .frame(maxWidth: .infinity)
        }
        .background(Theme.bgWindow)
    }

    private func skeleton(height: CGFloat, width: CGFloat? = nil, radius: CGFloat = Theme.Radius.card) -> some View {
        Shimmer().frame(width: width, height: height).frame(maxWidth: width == nil ? .infinity : width)
            .clipShape(RoundedRectangle(cornerRadius: radius))
    }

    private var cardSkeleton: some View {
        VStack(spacing: 0) {
            Shimmer().aspectRatio(4.0/5.0, contentMode: .fit).frame(maxWidth: .infinity)
            VStack(alignment: .leading, spacing: 8) {
                Shimmer().frame(height: 14).frame(maxWidth: .infinity).clipShape(Capsule())
                Shimmer().frame(width: 120, height: 11).clipShape(Capsule())
            }.padding(12)
        }
        .background(Theme.surface)
        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.card).strokeBorder(Theme.border, lineWidth: 0.5))
        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.card))
        .cardShadow()
    }
}

struct AnalyzeFailedView: View {
    var message: String? = nil
    let onRetry: () -> Void
    let onNew: () -> Void
    var body: some View {
        VStack(spacing: 14) {
            Glyph(name: "warn", size: 24, color: Theme.err)
                .frame(width: 56, height: 56).background(Theme.errBg)
                .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(Theme.errLine, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: 14))
            Text("Couldn't build the strategy").font(.system(size: 16, weight: .bold))
            Text(message ?? "The request to OpenAI failed. Check your API key / connection and try again.")
                .font(.system(size: 13)).foregroundStyle(Theme.ink3).multilineTextAlignment(.center).frame(maxWidth: 420)
                .textSelection(.enabled)
            HStack(spacing: 10) {
                AppButton(title: "Try again", icon: "refresh", variant: .primary, action: onRetry)
                AppButton(title: "New project", icon: "plus", variant: .secondary, action: onNew)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Theme.bgWindow)
    }
}

struct EmptyResults: View {
    @EnvironmentObject var store: AppStore
    var body: some View {
        VStack(spacing: 14) {
            Glyph(name: "layers", size: 26, color: Theme.ink3)
                .frame(width: 56, height: 56).background(Theme.surface2)
                .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(Theme.border, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: 14))
            Text("No campaign yet").font(.system(size: 16, weight: .bold))
            Text("Create a project to rank personas and draft ranked ad creatives.")
                .font(.system(size: 13)).foregroundStyle(Theme.ink3).multilineTextAlignment(.center)
            AppButton(title: "New project", icon: "plus", variant: .primary) { store.startNewProject() }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Theme.bgWindow)
    }
}
