import SwiftUI
import AppKit

/// Live, pannable preview of a placeholder *sample grid*. Each cell shows its reference photo
/// filling the cell; dragging a cell repositions which part of the photo is visible (pan only — the
/// photo always fills the cell). On release the offset is persisted and the store recomposes the flat
/// composite PNG, so the list-card thumbnail and any export match what's shown here.
///
/// Replaces `DraggableAdView` only for placeholder sample grids; generated/imported images keep using
/// `DraggableAdView` (with its editable text layers). Sample placeholders carry no visible text yet,
/// so this editor focuses purely on per-cell panning.
struct SampleGridEditor: View {
    let creative: Creative
    let projectID: UUID
    @EnvironmentObject var store: AppStore

    /// One slot per cell, aligned to `creative.sampleRefs` — `nil` for an empty Before/After cell.
    @State private var cellImages: [NSImage?] = []
    /// While a drag is active: which cell, and the current finger translation (display px).
    @State private var drag: (index: Int, tx: CGFloat, ty: CGFloat)?
    /// Currently selected hook/text layer (shared with the TextLayerCanvas).
    @State private var selectedID: UUID?
    /// Currently focused cell for panning. A drag only moves the focused item, so cell-pan and
    /// hook-move never fight. `focusedCell` and `selectedID` are mutually exclusive — clicking one
    /// clears the other; clicks hit the topmost item, so overlaps resolve by z-order.
    @State private var focusedCell: Int?
    /// The After cell awaiting a free-text note before AI-generating its Before (drives the note sheet).
    @State private var noteTarget: NoteTarget?
    /// The Solution cell awaiting a problem description before AI-generating its Problem (drives the sheet).
    @State private var problemTarget: NoteTarget?
    /// The cell awaiting a free-text prompt for "Edit with AI" (drives the edit sheet).
    @State private var editTarget: NoteTarget?
    /// The cell whose photo is being tuned with the Brightness/Shadows/… sliders (drives the adjust sheet).
    @State private var adjustTarget: NoteTarget?

    /// Identifiable wrapper so the note/edit sheets know which cell they're acting on.
    private struct NoteTarget: Identifiable { let id: Int }

    private var cols: Int { max(1, creative.sampleCols) }
    private var rows: Int { max(1, creative.sampleRows) }
    /// Split mode (Before/After or Comparison): a 2-col grid the user fills by dropping photos per cell.
    private var isSplit: Bool { creative.isSplit }
    /// Before/After specifically — only this mode offers the AI "generate the other side" actions.
    private var isBA: Bool { creative.isBeforeAfter }
    /// Problem/Solution — right column = real product photos, left column = AI-generated problem scenes.
    private var isPS: Bool { creative.isProblemSolution }
    /// The faint label shown on an empty split cell so the user drops into the correct column. Uses
    /// the creative's stored labels; falls back to mode defaults for legacy projects saved before the
    /// label fields existed (the actual rendered label still comes from the text layer).
    private func columnLabel(_ i: Int) -> String {
        let isLeft = i % cols == 0
        let stored = isLeft ? creative.splitLeftLabel : creative.splitRightLabel
        if !stored.isEmpty { return stored }
        if creative.isBeforeAfter { return isLeft ? "Before" : "After" }
        if creative.isProblemSolution { return isLeft ? "Problem" : "Solution" }
        return isLeft ? "Common" : "Premium"
    }
    /// Reload the source photos only when the photo SET changes — not on pure offset edits.
    private var cellsKey: String { "\(creative.sampleRefs.joined(separator: "|"))#\(cols)x\(rows)" }

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width, h = geo.size.height
            let rsW = GridComposer.highResSize(creative.ratio.size).width
            let baseGap: CGFloat = isBA ? max(8, rsW * 0.006) : 12   // Before/After uses a tighter seam
            let gap = rsW > 0 ? baseGap * w / rsW : 3            // mirror the composite's hairline gaps
            let cellW = (w - gap * CGFloat(cols + 1)) / CGFloat(cols)
            let cellH = (h - gap * CGFloat(rows + 1)) / CGFloat(rows)
            ZStack(alignment: .topLeading) {
                Theme.surface2
                ForEach(Array(0..<(cols * rows)), id: \.self) { i in
                    cell(i, cellW: cellW, cellH: cellH)
                        .frame(width: cellW, height: cellH)
                        .overlay(RoundedRectangle(cornerRadius: 4)
                            .strokeBorder(focusedCell == i ? Theme.accent : .clear, lineWidth: 2))
                        .overlay {
                            if let label = store.cellBusyLabel(creative.id, index: i) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 4).fill(Color.black.opacity(0.28))
                                    VStack(spacing: 6) {
                                        Spinner(size: 20, lineWidth: 2)
                                        Text(label).font(.system(size: 10, weight: .semibold))
                                            .foregroundStyle(.white)
                                    }
                                }
                            }
                        }
                        .contextMenu { cellMenu(i) }
                        // Per-cell drop for ALL sample grids (split AND regular). Dropping a local image
                        // onto a cell replaces only that cell — without this, the drop falls through to
                        // the inspector canvas and replaces the whole creative with one flat image.
                        .onDrop(of: [.fileURL, .image], isTargeted: nil) { providers in
                            ImageDrop.load(providers) { imgs in
                                if let first = imgs.first {
                                    store.setCellImage(project: projectID, creative: creative.id, index: i, image: first)
                                }
                            }
                            return true
                        }
                        .offset(x: gap + CGFloat(i % cols) * (cellW + gap),
                                y: gap + CGFloat(i / cols) * (cellH + gap))
                }

                // Split seams — cosmetic preview match for the composited divider lines.
                if isSplit {
                    let seam = Color(hex: 0xE7DEC9)
                    Rectangle().fill(seam).frame(width: gap, height: h)
                        .offset(x: gap + cellW)
                    ForEach(Array(1..<max(1, rows)), id: \.self) { r in
                        Rectangle().fill(seam).frame(width: w, height: gap)
                            .offset(y: CGFloat(r) * (cellH + gap))
                    }
                }

                // Interactive hook/text overlay on top of the cells. It has no full-size background,
                // so empty space still reaches the cells underneath; only the text boxes + handles
                // take hits. `requireSelectToMove` means a hook only moves once clicked, so it never
                // fights the cell-pan when they overlap.
                TextLayerCanvas(creative: creative, projectID: projectID,
                                selectedID: $selectedID, requireSelectToMove: true, w: w, h: h)
            }
            .frame(width: w, height: h)
            .onChange(of: selectedID) { _, id in if id != nil { focusedCell = nil } }   // hook ↔ cell exclusive
        }
        .task(id: cellsKey) { await loadCells() }
        .sheet(item: $noteTarget) { target in
            BeforeNoteSheet { note in
                store.generateBeforeFromAfter(project: projectID, creative: creative.id,
                                              afterIndex: target.id, note: note)
            }
        }
        .sheet(item: $editTarget) { target in
            AIEditSheet { prompt in
                store.editCellWithAI(project: projectID, creative: creative.id,
                                     index: target.id, prompt: prompt)
            }
        }
        .sheet(item: $problemTarget) { target in
            ProblemPromptSheet(initial: store.problemPrompt(creative.id, in: projectID, solutionIndex: target.id)) { prompt in
                store.generateProblemCell(project: projectID, creative: creative.id,
                                          solutionIndex: target.id, prompt: prompt)
            }
        }
        .sheet(item: $adjustTarget) { target in
            if let img = cellImages.indices.contains(target.id) ? cellImages[target.id] : nil {
                CellAdjustSheet(source: img) { adj in
                    store.adjustCellImage(project: projectID, creative: creative.id,
                                          index: target.id, adj)
                }
            }
        }
    }

    @ViewBuilder
    private func cell(_ i: Int, cellW: CGFloat, cellH: CGFloat) -> some View {
        let loaded: NSImage? = cellImages.indices.contains(i) ? cellImages[i] : nil
        if let img = loaded {
            let iw = CGFloat(img.pixelWidth), ih = CGFloat(img.pixelHeight)
            let scale = max(cellW / iw, cellH / ih)
            let dw = iw * scale, dh = ih * scale
            let ovX = max(0, dw - cellW), ovY = max(0, dh - cellH)   // pannable slack per axis
            let stored = storedOffset(i)
            let baseX = stored.x * ovX / 2, baseY = stored.y * ovY / 2
            let active = drag?.index == i
            let px = clamp(baseX + (active ? drag!.tx : 0), -ovX / 2, ovX / 2)
            let py = clamp(baseY + (active ? drag!.ty : 0), -ovY / 2, ovY / 2)
            Color.clear
                .frame(width: cellW, height: cellH)
                .overlay(Image(nsImage: img).resizable().frame(width: dw, height: dh).offset(x: px, y: py))
                .clipShape(RoundedRectangle(cornerRadius: 4))
                .contentShape(Rectangle())
                .onTapGesture { focusedCell = i; selectedID = nil }   // click a cell to focus it
                .gesture(
                    DragGesture(minimumDistance: 2)
                        .onChanged { v in
                            focusedCell = i; selectedID = nil   // dragging a cell focuses + pans it directly
                            drag = (i, v.translation.width, v.translation.height)
                        }
                        .onEnded { v in
                            let fx = ovX > 0 ? clamp(baseX + v.translation.width, -ovX / 2, ovX / 2) / (ovX / 2) : 0
                            let fy = ovY > 0 ? clamp(baseY + v.translation.height, -ovY / 2, ovY / 2) / (ovY / 2) : 0
                            drag = nil
                            store.setCellOffset(project: projectID, creative: creative.id,
                                                index: i, offset: CGPoint(x: fx, y: fy))
                        }
                )
                .help((ovX > 1 || ovY > 1) ? "Drag to reposition this photo" : "")
        } else if isSplit {
            // Empty split cell — hint which column it is and that the user should drop a photo.
            RoundedRectangle(cornerRadius: 4).fill(Theme.surface)
                .overlay {
                    // Hide the drop hint while this cell is generating (the spinner overlay shows instead).
                    if !store.isGeneratingCell(creative.id, index: i) {
                        // Problem/Solution's empty Problem (left) cell is filled by AI from the Solution
                        // beside it, so it points at the right-click action instead of a plain drop hint.
                        let psProblemCell = isPS && i % cols == 0
                        VStack(spacing: 3) {
                            Text(columnLabel(i))
                                .font(.system(size: 12, weight: .bold)).foregroundStyle(Theme.ink3)
                                .multilineTextAlignment(.center).lineLimit(2)
                                .padding(.horizontal, 6)
                            Text(psProblemCell ? "Right-click the Solution cell to generate" : "Drop image here")
                                .font(.system(size: 9.5)).foregroundStyle(Theme.ink4)
                                .multilineTextAlignment(.center).lineLimit(2)
                                .padding(.horizontal, 6)
                        }
                    }
                }
        } else {
            RoundedRectangle(cornerRadius: 4).fill(Theme.surface)
        }
    }

    /// Variant grid — every cell holds a different real pattern of the same product. Right-clicking a
    /// cell offers it as the layout ANCHOR (all other cells re-render to its scene, each keeping its own
    /// pattern), a per-cell repair against another cell, and a whole-grid re-roll.
    private var isVariant: Bool { creative.isVariant }

    /// Right-click actions for a single cell. Grid cells re-roll from the project photos; split cells
    /// (user-dropped real photos) can re-roll the right column from the pool or be removed. Before/After
    /// adds the AI "generate the Before" actions. Variant cells drive the per-cell "Vary". All cells can
    /// be edited/adjusted and recenter their pan.
    @ViewBuilder
    private func cellMenu(_ i: Int) -> some View {
        // Any cell that holds a photo can be edited with AI (erase/recolor/replace via free-text prompt)
        // or tuned with the brightness/shadows/saturation/clarity sliders.
        if !storedRef(i).isEmpty {
            Button {
                editTarget = NoteTarget(id: i)
            } label: { Label("Edit with AI…", systemImage: "wand.and.stars") }
            Button {
                adjustTarget = NoteTarget(id: i)
            } label: { Label("Adjust…", systemImage: "slider.horizontal.3") }
            Divider()
        }
        if isSplit {
            // On a right-column cell with a photo: re-roll it from the input pool.
            if i % cols == 1, !storedRef(i).isEmpty {
                Button {
                    store.reSampleAfterCell(project: projectID, creative: creative.id, index: i)
                } label: { Label("Re-sample this photo", systemImage: "arrow.triangle.2.circlepath") }
                // Before/After only: synthesize the matching Before from this After.
                if isBA {
                    Button {
                        store.generateBeforeFromAfter(project: projectID, creative: creative.id, afterIndex: i)
                    } label: { Label("Generate Before with AI", systemImage: "wand.and.stars") }
                    Button {
                        noteTarget = NoteTarget(id: i)
                    } label: { Label("Generate Before with AI + Note…", systemImage: "wand.and.stars.inverse") }
                }
                // Problem/Solution only: describe a situation → AI fills the Problem cell beside it.
                if isPS {
                    let hasProblem = !storedRef(i - 1).isEmpty
                    Button {
                        problemTarget = NoteTarget(id: i)
                    } label: {
                        Label(hasProblem ? "Edit / regenerate Problem (AI)…" : "Generate Problem scene (AI)…",
                              systemImage: "wand.and.stars")
                    }
                }
            }
            if !storedRef(i).isEmpty {
                Button {
                    store.clearCellImage(project: projectID, creative: creative.id, index: i)
                } label: { Label("Remove photo", systemImage: "trash") }
            }
        } else if isVariant {
            // NOTE: keep this menu FLAT — a nested `Menu` (submenu) inside `.contextMenu` breaks the
            // cell's own click/right-click hit-testing on macOS (the whole cell goes inert).
            Button {
                store.varyVariantGrid(project: projectID, creative: creative.id, anchorIndex: i)
            } label: { Label("Vary — match every cell to this one", systemImage: "rectangle.3.group") }
            Button {
                store.reSampleVariantCell(project: projectID, creative: creative.id, index: i)
            } label: { Label("New pattern for this cell", systemImage: "arrow.triangle.2.circlepath") }
        } else {
            Button {
                store.reSampleCell(project: projectID, creative: creative.id, index: i)
            } label: { Label("Re-sample this cell", systemImage: "arrow.triangle.2.circlepath") }
        }
    }

    private func storedOffset(_ i: Int) -> CGPoint {
        creative.sampleOffsets.indices.contains(i) ? creative.sampleOffsets[i] : .zero
    }
    private func storedRef(_ i: Int) -> String {
        creative.sampleRefs.indices.contains(i) ? creative.sampleRefs[i] : ""
    }
    private func clamp(_ v: CGFloat, _ lo: CGFloat, _ hi: CGFloat) -> CGFloat { min(hi, max(lo, v)) }

    private func loadCells() async {
        let refs = creative.sampleRefs
        guard !refs.isEmpty else { cellImages = []; return }
        let pid = projectID
        // Decode off-main, ONE slot per ref so indices stay aligned — empty refs (Before/After
        // unfilled cells) decode to nil rather than collapsing the array.
        cellImages = await Task.detached {
            refs.map { name -> NSImage? in
                guard !name.isEmpty,
                      let data = ProjectStore.shared.referenceImageData(projectID: pid, filenames: [name]).first
                else { return nil }
                return NSImage(data: data)
            }
        }.value
    }
}

/// Sheet that collects an optional free-text note before AI-generating a Before image, so the user
/// can steer what the empty "before" scene should look like. Leaving it blank matches the plain
/// "Generate Before with AI" action. The note is passed back to the caller, which calls the model.
private struct BeforeNoteSheet: View {
    let onGenerate: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var note = ""

    private let suggestions = ["Messy / cluttered room", "Old worn furniture",
                               "Empty bare floor", "Dull lighting"]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 7) {
                Glyph(name: "sparkle", size: 15, color: Theme.accent)
                Text("Generate Before with AI").font(.system(size: 14, weight: .bold))
            }
            Text("Optional: describe how the Before scene should look. Leave blank for a plain empty version.")
                .font(.system(size: 11.5)).foregroundStyle(Theme.ink3)

            ZStack(alignment: .topLeading) {
                if note.isEmpty {
                    Text("e.g. messy living room with an old, faded rug")
                        .font(.system(size: 12)).foregroundStyle(Theme.ink4)
                        .padding(.horizontal, 9).padding(.vertical, 8).allowsHitTesting(false)
                }
                TextEditor(text: $note)
                    .font(.system(size: 12)).scrollContentBackground(.hidden)
                    .frame(height: 72).padding(.horizontal, 5).padding(.vertical, 3)
            }
            .background(Theme.surface)
            .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
            .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))

            FlexChips(items: suggestions) { note = $0 }

            HStack {
                Spacer()
                AppButton(title: "Cancel", variant: .secondary, size: .sm) { dismiss() }
                AppButton(title: "Generate", icon: "sparkle", variant: .primary, size: .sm) {
                    onGenerate(note); dismiss()
                }
            }
        }
        .padding(16)
        .frame(width: 340)
    }
}

/// Sheet that collects the REQUIRED problem-scene description for a Problem/Solution row. The AI uses
/// the row's Solution photo as the reference scene and renders the same setting WITHOUT the product,
/// showing the pain the user describes. Pre-filled with the saved prompt when regenerating a cell.
private struct ProblemPromptSheet: View {
    let initial: String
    let onGenerate: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var note: String

    init(initial: String, onGenerate: @escaping (String) -> Void) {
        self.initial = initial
        self.onGenerate = onGenerate
        _note = State(initialValue: initial)
    }

    private let suggestions = ["Old, worn version in use", "Stained / dirty surface",
                               "Pet hair & scratches", "Cluttered, uncomfortable scene"]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 7) {
                Glyph(name: "sparkle", size: 15, color: Theme.accent)
                Text("Generate Problem scene with AI").font(.system(size: 14, weight: .bold))
            }
            Text("Describe the problem situation. The AI keeps the same room & angle as the Solution photo but removes the product and shows this pain.")
                .font(.system(size: 11.5)).foregroundStyle(Theme.ink3)

            ZStack(alignment: .topLeading) {
                if note.isEmpty {
                    Text("e.g. old sofa with frayed fabric, scratches and cat hair")
                        .font(.system(size: 12)).foregroundStyle(Theme.ink4)
                        .padding(.horizontal, 9).padding(.vertical, 8).allowsHitTesting(false)
                }
                TextEditor(text: $note)
                    .font(.system(size: 12)).scrollContentBackground(.hidden)
                    .frame(height: 72).padding(.horizontal, 5).padding(.vertical, 3)
            }
            .background(Theme.surface)
            .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
            .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))

            FlexChips(items: suggestions) { note = $0 }

            HStack {
                Spacer()
                AppButton(title: "Cancel", variant: .secondary, size: .sm) { dismiss() }
                AppButton(title: "Generate", icon: "sparkle", variant: .primary, size: .sm) {
                    let trimmed = note.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !trimmed.isEmpty else { return }
                    onGenerate(trimmed); dismiss()
                }
            }
        }
        .padding(16)
        .frame(width: 360)
    }
}
