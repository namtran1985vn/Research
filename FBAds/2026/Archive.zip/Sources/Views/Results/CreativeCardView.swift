import SwiftUI
import UniformTypeIdentifiers

struct CreativeCardView: View {
    let creative: Creative
    let persona: Persona
    let projectID: UUID
    let selected: Bool
    let queuePos: Int?
    let onSelect: () -> Void
    let onGenerate: () -> Void
    let onToggleWinner: () -> Void
    let onCopy: () -> Void
    var onEditImage: () -> Void = {}

    @EnvironmentObject var store: AppStore
    @EnvironmentObject var settings: AppSettings
    @State private var hover = false
    @State private var dropTarget = false
    @State private var showAIEdit = false

    private var isPlaceholder: Bool {
        creative.status == .idle && creative.imageIsPlaceholder && creative.imageFilename != nil
    }

    /// Title shown when no on-image hook is selected: the bigIdea, else the first non-empty hook,
    /// else the concept — so a card is never headed by a blank line.
    private var cardTitle: String {
        let bi = creative.bigIdea.trimmingCharacters(in: .whitespacesAndNewlines)
        if !bi.isEmpty { return bi }
        if let h = creative.hooks.first(where: { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) { return h }
        return creative.concept
    }

    var body: some View {
        VStack(spacing: 0) {
            frame
            meta
        }
        .background(Theme.surface)
        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.card)
            .strokeBorder(selected ? Theme.accent : Theme.border, lineWidth: selected ? 1.5 : 0.5))
        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.card))
        .modifier(CardShadow(selected: selected, hover: hover))
        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.card)
            .strokeBorder(Theme.accentSoft, lineWidth: selected ? 3 : 0).padding(-2).opacity(selected ? 1 : 0))
        .offset(y: hover && !selected ? -2 : 0)
        .contentShape(Rectangle())
        .onTapGesture(count: 2) { onEditImage() }   // double-click → open the image adjustments editor
        .onTapGesture { onSelect() }
        .onHover { hover = $0 }
        .animation(.easeOut(duration: 0.15), value: hover)
        .animation(.easeOut(duration: 0.15), value: selected)
    }

    // MARK: Image frame + states

    private var frame: some View {
        ZStack {
            Color.clear
            switch creative.status {
            case .done:       AdImageView(creative: creative, projectID: projectID).transition(.opacity)
            case .generating: GeneratingOverlay()
            case .queued:     QueuedOverlay(pos: queuePos)
            case .error:      ErrorOverlay(message: creative.errorMessage, onRetry: onGenerate)
            case .idle:
                if isPlaceholder { SampleGridView(creative: creative, projectID: projectID, onGenerate: onGenerate) }
                else { IdleOverlay(onGenerate: onGenerate).onAppear { store.ensureSampleGrid(project: projectID, creative: creative.id) } }
            }
        }
        .aspectRatio(creative.ratio.value, contentMode: .fit)
        .frame(maxWidth: .infinity)
        .background(Theme.surface2)
        .clipped()
        .overlay(alignment: .bottomTrailing) {
            if creative.winner {
                Glyph(name: "heart", size: 14, color: Theme.winner, fill: true)
                    .frame(width: 26, height: 26).background(Color.white.opacity(0.9)).clipShape(Circle())
                    .shadow(color: .black.opacity(0.18), radius: 2, y: 1)
                    .padding(9)
            }
        }
        .overlay(alignment: .bottom) { Rectangle().fill(Theme.border).frame(height: 0.5) }
        .overlay(RoundedRectangle(cornerRadius: 1).strokeBorder(Theme.accent, lineWidth: dropTarget ? 2 : 0))
        .onDrop(of: [.fileURL, .image], isTargeted: $dropTarget) { providers in importProviders(providers) }
        .contextMenu {
            if creative.imageFilename != nil {
                // "Edit with AI" applies to a single image; placeholder sample grids are edited per-cell
                // in the inspector (SampleGridEditor), so the whole-card edit is hidden for those.
                if !creative.imageIsPlaceholder {
                    Button { showAIEdit = true } label: { Label("Edit with AI…", systemImage: "wand.and.stars") }
                }
                Button { store.saveImageToDisk(project: projectID, creative: creative.id) } label: { Label("Save Image…", systemImage: "square.and.arrow.down") }
                Button { store.copyImage(project: projectID, creative: creative.id) } label: { Label("Copy Image", systemImage: "doc.on.doc") }
                Divider()
            }
            Button { onCopy() } label: { Label("Copy Primary Text", systemImage: "doc.on.clipboard") }
            Button { onGenerate() } label: { Label(creative.status == .done ? "Regenerate Image" : "Generate AI Image", systemImage: "sparkles") }
            Button { store.duplicateCreative(project: projectID, persona: persona.id, creative: creative.id) } label: { Label("Duplicate Creative", systemImage: "plus.square.on.square") }
            Button { onToggleWinner() } label: { Label(creative.winner ? "Unmark Winner" : "Mark as Winner", systemImage: "heart") }
        }
        .sheet(isPresented: $showAIEdit) {
            AIEditSheet { prompt in
                store.editImageWithAI(project: projectID, creative: creative.id, prompt: prompt)
            }
        }
    }

    private func importProviders(_ providers: [NSItemProvider]) -> Bool {
        ImageDrop.load(providers) { images in
            store.importImages(project: projectID, persona: persona.id, creative: creative.id, images: images)
        }
        return true
    }

    // MARK: Meta + actions

    private var meta: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: 8) {
                Group {
                    // Show the chosen on-image hook when one is selected; otherwise fall back to the
                    // creative's bigIdea so every card always carries a title (a fresh creative has
                    // selHook == -1 → empty hook). Older creatives with no bigIdea fall back further.
                    if creative.selHook >= 0, !creative.hook.isEmpty {
                        Text(highlightedHook(creative.hook, creative.highlight))
                    } else {
                        Text(cardTitle)
                    }
                }
                .font(.system(size: 14, weight: .bold)).tracking(-0.1)
                .lineLimit(2)
                Spacer(minLength: 0)
                if !isPlaceholder {
                    StatusChip(status: creative.status).padding(.top, 1)
                }
            }
            Text(creative.concept).font(.system(size: 11.5)).foregroundStyle(Theme.ink3)
                .lineLimit(2).lineSpacing(1).padding(.top, 4)
        }
        .padding(.horizontal, 12).padding(.top, 11).padding(.bottom, 12)
    }

}

private struct CardShadow: ViewModifier {
    let selected: Bool
    let hover: Bool
    func body(content: Content) -> some View {
        if selected || hover { return AnyView(content.raiseShadow()) }
        return AnyView(content.cardShadow())
    }
}

// MARK: - State overlays

/// Default starting image: the random 3×3 sample grid, with a hover affordance to generate the AI image.
struct SampleGridView: View {
    let creative: Creative
    let projectID: UUID
    let onGenerate: () -> Void
    @EnvironmentObject var store: AppStore

    var body: some View {
        ZStack {
            AdImageView(creative: creative, projectID: projectID, showText: true)
        }
        .overlay {
            if store.rebuildingGrids.contains(creative.id) {
                ZStack { Color.black.opacity(0.18); Spinner(size: 20, lineWidth: 2) }
                    .transition(.opacity)
            }
        }
        .animation(.easeOut(duration: 0.15), value: store.rebuildingGrids.contains(creative.id))
        .overlay(alignment: .bottomLeading) {
            HStack(spacing: 4) {
                Glyph(name: "grid", size: 10, color: .white)
                Text("Sample · \(creative.sampleCols)×\(creative.sampleRows)").font(.system(size: 10, weight: .semibold)).foregroundStyle(.white)
            }
            .padding(.horizontal, 7).padding(.vertical, 3)
            .background(Color(hex: 0x211E18).opacity(0.5)).clipShape(Capsule())
            .padding(8)
        }
    }
}

struct IdleOverlay: View {
    let onGenerate: () -> Void
    var body: some View {
        VStack(spacing: 12) {
            Glyph(name: "image", size: 19, color: Theme.ink3)
                .frame(width: 40, height: 40).background(Theme.surface)
                .overlay(RoundedRectangle(cornerRadius: 11).strokeBorder(Theme.border, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: 11)).cardShadow()
            AppButton(title: "Generate image", icon: "sparkle", variant: .soft, action: onGenerate)
        }
    }
}

struct QueuedOverlay: View {
    let pos: Int?
    @State private var pulse = false
    var body: some View {
        ZStack {
            StripePattern()
            VStack(spacing: 10) {
                Circle().fill(Theme.queue).frame(width: 8, height: 8).opacity(pulse ? 0.45 : 1)
                    .animation(.easeInOut(duration: 0.65).repeatForever(autoreverses: true), value: pulse)
                Text(pos != nil ? "Queued · #\(pos!)" : "Queued")
                    .font(.system(size: 12, weight: .semibold)).foregroundStyle(Theme.queue)
            }
        }
        .onAppear { pulse = true }
    }
}

struct GeneratingOverlay: View {
    var body: some View {
        ZStack {
            Shimmer()
            VStack(spacing: 12) {
                Spinner(size: 30, lineWidth: 2.5)
                Text("Generating image…").font(.system(size: 12, weight: .semibold)).foregroundStyle(Theme.run)
            }
        }
    }
}

struct ErrorOverlay: View {
    let message: String?
    let onRetry: () -> Void
    var body: some View {
        VStack(spacing: 12) {
            Glyph(name: "warn", size: 20, color: Theme.err)
                .frame(width: 38, height: 38).background(Theme.err.opacity(0.12)).clipShape(Circle())
            Text(message ?? "Generation failed")
                .font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.err)
                .multilineTextAlignment(.center).lineLimit(3)
            AppButton(title: "Retry now", icon: "refresh", variant: .danger, size: .sm, action: onRetry)
        }
        .padding(18)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Theme.errBg)
    }
}

/// Diagonal stripe pattern for the queued state.
struct StripePattern: View {
    var body: some View {
        GeometryReader { geo in
            let size = max(geo.size.width, geo.size.height) * 1.5
            Canvas { ctx, _ in
                ctx.fill(Path(CGRect(origin: .zero, size: geo.size)), with: .color(Theme.surface2))
                var x: CGFloat = -size
                while x < size {
                    var p = Path()
                    p.move(to: CGPoint(x: x, y: 0))
                    p.addLine(to: CGPoint(x: x + size, y: size))
                    p.addLine(to: CGPoint(x: x + size + 12, y: size))
                    p.addLine(to: CGPoint(x: x + 12, y: 0))
                    ctx.fill(p, with: .color(Theme.queueBg))
                    x += 24
                }
            }
        }
    }
}

/// Animated shimmer for the generating state.
struct Shimmer: View {
    @State private var phase: CGFloat = -1
    var body: some View {
        GeometryReader { geo in
            LinearGradient(colors: [Theme.surface2, Theme.surface3, Theme.surface2],
                           startPoint: .leading, endPoint: .trailing)
                .frame(width: geo.size.width * 2)
                .offset(x: phase * geo.size.width)
                .onAppear {
                    withAnimation(.linear(duration: 1.4).repeatForever(autoreverses: false)) { phase = 1 }
                }
        }
    }
}
