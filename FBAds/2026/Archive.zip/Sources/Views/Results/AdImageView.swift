import SwiftUI
import AppKit

/// One hook/text layer rendered as a "tutorial banner": bold white text on a sharp-cornered
/// near-black box with a cyan top+left border and a hot-pink bottom border.
/// Shared by the canvas, the live preview, and the drag overlay so everything matches.
struct HookText: View {
    let layer: TextLayer
    let scale: CGFloat
    let containerWidth: CGFloat

    private static let bannerCyan = Color(hex: 0x00D6D6)
    private static let bannerPink = Color(hex: 0xFF2B5F)

    /// Arrow width in 1024-canvas points per unit of `fontSize` — lets the existing fontSize-based
    /// resize handles scale the arrow (fontSize 24…140 → ~144…840 pt wide).
    static let arrowWidthPerFont: CGFloat = 6
    static let arrowAspect: CGFloat = 383.0 / 651.0   // bundled arrow.png is 651×383

    var body: some View {
        if layer.isArrow {
            arrowView
        } else {
            switch layer.hookStyle {
            case .stickyNote: stickyNote
            case .stamp:      stampView
            case .chatBubble: chatBubbleView
            case .annotation: annotationView
            default:          standard
            }
        }
    }

    /// Decorative Before/After arrow: the bundled red brush PNG sized by `fontSize`. The whole image
    /// is grabbable, so it moves/resizes like any block.
    private var arrowView: some View {
        let w = layer.fontSize * Self.arrowWidthPerFont * scale
        let h = w * Self.arrowAspect
        return Group {
            if let img = Arrows.image {
                Image(nsImage: img).resizable().interpolation(.high)
            } else {
                Image(systemName: "arrow.right").resizable().foregroundStyle(Color(hex: 0xE23B3B))
            }
        }
        .frame(width: w, height: h)
        .contentShape(Rectangle())
    }

    /// Sticky Note: flat ink sitting ON the paper (no glyph shadow), with the drop shadow cast by the
    /// PAPER only — the shadow lives on the background image, so the text never gets its own shadow and
    /// never looks like it floats above the note.
    private var stickyNote: some View {
        let s = layer.fontSize * scale
        let seed = StickyNote.seed(for: layer.id)
        return Text(highlighted)
            .font(font)
            .multilineTextAlignment(textAlign)
            .fixedSize(horizontal: true, vertical: true)
            .padding(.horizontal, s * 0.70)
            .padding(.vertical, s * 0.60)
            .background {
                // Shadow lives on the paper, not the composite — so only the paper casts it.
                Group {
                    if let paper = StickyNote.pick(seed: seed) {
                        Image(nsImage: paper).resizable()
                    } else {
                        RoundedRectangle(cornerRadius: s * 0.04, style: .continuous)
                            .fill(Color(hex: HookPalette.noteYellow))
                    }
                }
                .shadow(color: .black.opacity(0.30), radius: s * 0.16, x: s * 0.05, y: s * 0.07)
            }
            .rotationEffect(.degrees(StickyNote.tiltDegrees(seed: seed)))
    }

    /// Stamp: short text centred on a real craft-stamp PNG. The STAMP drives the layer's frame (text
    /// measured up-front) so the whole seal is draggable, the handles sit on the stamp, and the editor
    /// position matches the export (which anchors the stamp top-left at the layer position).
    private var stampView: some View {
        let s = layer.fontSize * scale
        let seed = StickyNote.seed(for: layer.id)
        let stamp = Stamps.at(layer.stampVariant)
        let aspect = stamp.map { $0.size.width / max(1, $0.size.height) } ?? 1
        // Portrait hang-tag (aspect < 0.75): rectangular body, 61.5% usable height (body starts at
        // 35.5% of PNG height — measured from pixel data), 65% usable width.
        // Round/badge: inscribe text diagonal in the inner circle.
        let isPortrait = aspect < 0.75
        // Portrait stamps get generous line-height so multiline text breathes on the hang tag.
        let lhm: CGFloat = isPortrait ? 1.4 : 1.05
        let t = measuredTextSize(alignment: .center, lineHeightMultiple: lhm)
        let w: CGFloat
        let h: CGFloat
        if isPortrait {
            let wFromWidth  = t.width  / 0.65
            let wFromHeight = (t.height / 0.615) * aspect
            w = max(wFromWidth, wFromHeight)
            h = w / aspect
        } else {
            let diag = (t.width * t.width + t.height * t.height).squareRoot()
            w = diag / 0.80
            h = w / aspect
        }
        // Body centre is at 66.3% from the PNG top (body starts at 35.5%, measured from pixel data).
        // Offset = 66.3% - 50% (ZStack default centre) = 16.3% of stamp height.
        let textYOffset: CGFloat = isPortrait ? h * 0.163 : 0
        return ZStack {
            Group {
                if let stamp {
                    Image(nsImage: stamp).resizable()
                } else {
                    Circle().strokeBorder(Color(hex: HookPalette.stampRed), lineWidth: max(2, s * 0.12))
                }
            }
            .frame(width: w, height: h)
            .shadow(color: .black.opacity(0.26), radius: s * 0.13, x: s * 0.04, y: s * 0.06)
            Text(highlighted)
                .font(font)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: true, vertical: true)
                .lineSpacing(isPortrait ? s * 0.45 : 0)   // match lhm=1.4 spacing for hang-tag
                .offset(y: textYOffset)
        }
        .frame(width: w, height: h)
        .contentShape(Rectangle())                               // whole stamp is grabbable
        .rotationEffect(.degrees(-1.0 - Double(abs(seed) % 4)))
    }

    /// Measures the layer's text in canvas points (same metrics the AppKit renderer uses), so views
    /// whose background art is bigger than the text (e.g. Stamp) can size themselves up-front.
    private func measuredTextSize(alignment: NSTextAlignment, lineHeightMultiple: CGFloat = 1.05) -> CGSize {
        let sz = layer.fontSize * scale
        let f: NSFont
        if layer.fontName.isEmpty || layer.fontName.hasPrefix("SF Pro") {
            f = .systemFont(ofSize: sz, weight: layer.bold ? .heavy : .regular)   // matches `font`
        } else {
            var ff = NSFont(name: layer.fontName, size: sz) ?? .systemFont(ofSize: sz)
            if layer.bold { ff = NSFontManager.shared.convert(ff, toHaveTrait: .boldFontMask) }
            f = ff
        }
        let p = NSMutableParagraphStyle(); p.alignment = alignment; p.lineHeightMultiple = lineHeightMultiple
        let str = NSAttributedString(string: CopyText.clean(layer.text),
                                     attributes: [.font: f, .paragraphStyle: p])
        let b = str.boundingRect(with: CGSize(width: 100_000, height: 100_000),
                                 options: [.usesLineFragmentOrigin, .usesFontLeading])
        return CGSize(width: ceil(b.width), height: ceil(b.height))
    }

    /// Chat Bubble: a real iMessage-style bubble PNG, nine-sliced at the measured text size so corners
    /// and tail never distort. The whole bubble is the layer frame (draggable everywhere), white text.
    private var chatBubbleView: some View {
        let s = layer.fontSize * scale
        let padH = s * 0.20, padV = s * 0.12
        if let bubble = ChatBubbles.first {
            let corner = s * 0.42
            let caps = ChatBubbles.caps(bubble, corner: corner)
            let t = measuredTextSize(alignment: .left)
            let bw = t.width + caps.left + caps.right + padH * 2
            let bh = t.height + caps.top + caps.bottom + padV * 2
            let img = ChatBubbles.sliced(bubble, size: CGSize(width: bw, height: bh), corner: corner)
            return AnyView(
                ZStack(alignment: .topLeading) {
                    Image(nsImage: img)
                        .shadow(color: .black.opacity(0.16), radius: s * 0.10, y: s * 0.03)
                    Text(highlighted)
                        .font(font)
                        .multilineTextAlignment(.leading)
                        .fixedSize(horizontal: true, vertical: true)
                        .padding(.leading, caps.left + padH)
                        .padding(.top, caps.top + padV)
                }
                .frame(width: bw, height: bh, alignment: .topLeading)
                .contentShape(Rectangle())
            )
        }
        return AnyView(
            Text(highlighted).font(font).multilineTextAlignment(.leading)
                .fixedSize(horizontal: true, vertical: true)
                .padding(.horizontal, s * 0.5).padding(.vertical, s * 0.4)
                .background { RoundedRectangle(cornerRadius: s * 0.45).fill(Color(hex: layer.boxColorHex)) }
        )
    }

    /// Annotation text with a TIGHT WHITE outline hugging every glyph (built from 8 offset white
    /// copies behind the coloured text — SwiftUI Text has no native stroke). Matches the export's
    /// white stroke so the handwriting pops off any photo.
    private var outlinedText: some View {
        let s = layer.fontSize * scale
        let o = max(1, s * 0.05)
        let plain = CopyText.clean(layer.text)
        let dirs: [(CGFloat, CGFloat)] = [(-1, -1), (0, -1), (1, -1), (-1, 0),
                                          (1, 0), (-1, 1), (0, 1), (1, 1)]
        return ZStack {
            ForEach(0..<dirs.count, id: \.self) { i in
                Text(plain).font(font).multilineTextAlignment(textAlign)
                    .fixedSize(horizontal: true, vertical: true)
                    .foregroundColor(.white)
                    .offset(x: dirs[i].0 * o, y: dirs[i].1 * o)
            }
            Text(highlighted).font(font).multilineTextAlignment(textAlign)
                .fixedSize(horizontal: true, vertical: true)
        }
    }

    /// Annotation: white-outlined handwriting + a hand-drawn mark
    /// (underline below / circle around / arrow beside) sized relative to the text.
    private var annotationView: some View {
        let s = layer.fontSize * scale
        let kind = layer.annotationKind
        return outlinedText
            .background(alignment: .center) {
                if kind == .circle, let img = Annotations.image(.circle) {
                    GeometryReader { g in
                        let aspect = img.size.width / max(1, img.size.height)
                        let cw = g.size.width * 1.35
                        let ch = max(cw / aspect, g.size.height * 1.6)
                        outlinedMark(img, .circle, width: cw, height: ch)
                            .position(x: g.size.width / 2, y: g.size.height / 2)
                    }
                }
            }
            .overlay(alignment: .bottom) {
                if kind == .underline, let img = Annotations.image(.underline) {
                    GeometryReader { g in
                        let aspect = img.size.width / max(1, img.size.height)
                        let uw = g.size.width * 1.02
                        let uh = uw / aspect
                        outlinedMark(img, .underline, width: uw, height: uh)
                            .position(x: g.size.width / 2, y: g.size.height + s * 0.18)
                    }
                }
            }
            .overlay(alignment: .topTrailing) {
                if kind == .arrow, let img = Annotations.image(.arrow) {
                    GeometryReader { g in
                        let aspect = img.size.width / max(1, img.size.height)
                        let aw = max(g.size.width * 0.55, s * 3)
                        let ah = aw / aspect
                        outlinedMark(img, .arrow, width: aw, height: ah)
                            .position(x: g.size.width + aw * 0.05, y: -ah * 0.05)
                    }
                }
            }
    }

    /// A hand-drawn mark with a thin white outline (8 offset white silhouettes behind the coloured one).
    @ViewBuilder
    private func outlinedMark(_ img: NSImage, _ kind: AnnotationKind, width: CGFloat, height: CGFloat) -> some View {
        let o = max(1, layer.fontSize * scale * 0.045)
        let dirs: [(CGFloat, CGFloat)] = [(-1, -1), (0, -1), (1, -1), (-1, 0),
                                          (1, 0), (-1, 1), (0, 1), (1, 1)]
        ZStack {
            if let white = Annotations.whiteImage(kind) {
                ForEach(0..<dirs.count, id: \.self) { i in
                    Image(nsImage: white).resizable().frame(width: width, height: height)
                        .offset(x: dirs[i].0 * o, y: dirs[i].1 * o)
                }
            }
            Image(nsImage: img).resizable().frame(width: width, height: height)
        }
    }

    private var standard: some View {
        let s = layer.fontSize * scale
        let bw = max(3, s * 0.17)
        let borders = layer.shadow && layer.hookStyle.hasBorders
        let dashed = layer.shadow && layer.hookStyle.hasDashedBorder
        return Text(highlighted)
            .font(font)
            .multilineTextAlignment(textAlign)
            .fixedSize(horizontal: true, vertical: true)   // hug the (short) hook tightly
            .padding(.horizontal, s * 0.40)
            .padding(.vertical, s * 0.26)
            .background {
                if layer.shadow {
                    RoundedRectangle(cornerRadius: s * layer.hookStyle.cornerRadiusFactor, style: .continuous)
                        .fill(Color(hex: layer.boxColorHex).opacity(Double(layer.hookStyle.boxOpacity)))
                }
            }
            .overlay(alignment: .top)      { if borders { Self.bannerCyan.frame(height: bw) } }
            .overlay(alignment: .leading)  { if borders { Self.bannerCyan.frame(width: bw) } }
            .overlay(alignment: .bottom)   { if borders { Self.bannerPink.frame(height: bw) } }
            .overlay(alignment: .trailing) { if borders { Self.bannerPink.frame(width: bw) } }
            .overlay {
                if dashed {
                    Rectangle().strokeBorder(Color(hex: layer.colorHex),
                                             style: StrokeStyle(lineWidth: max(2, s * 0.07),
                                                                dash: [max(4, s * 0.24), max(3, s * 0.16)]))
                }
            }
            // No box (Clean Float): a soft dark halo keeps the text legible and lifts it off the
            // photo. Two passes = a tight contrast edge + a wider gradient glow. No-op when boxed.
            .shadow(color: .black.opacity(layer.shadow ? 0 : 0.60), radius: layer.shadow ? 0 : s * 0.09, y: layer.shadow ? 0 : s * 0.03)
            .shadow(color: .black.opacity(layer.shadow ? 0 : 0.45), radius: layer.shadow ? 0 : s * 0.22)
    }

    private var font: Font {
        let s = layer.fontSize * scale
        let base: Font = (layer.fontName.isEmpty || layer.fontName.hasPrefix("SF Pro"))
            ? .system(size: s, weight: layer.bold ? .heavy : .regular)
            : .custom(layer.fontName, size: s).weight(layer.bold ? .heavy : .regular)
        return layer.italic ? base.italic() : base
    }
    private var highlighted: AttributedString {
        var str = AttributedString(CopyText.clean(layer.text))
        str.foregroundColor = Color(hex: layer.colorHex)
        for term in CopyText.highlightTerms(layer.highlightWord) {
            if let range = str.range(of: term, options: .caseInsensitive) {
                str[range].foregroundColor = Color(hex: layer.highlightColorHex)
            }
        }
        return str
    }
    private var textAlign: TextAlignment {
        switch layer.alignment { case "center": return .center; case "trailing": return .trailing; default: return .leading }
    }
    private var frameAlign: Alignment {
        switch layer.alignment { case "center": return .top; case "trailing": return .topTrailing; default: return .topLeading }
    }
}

/// A Messenger/Telegram-style chat bubble: a strongly-rounded rectangle with a small curved tail
/// at the bottom-left (received-message look). The tail occupies the bottom `tail` band of the rect.
struct ChatBubbleShape: Shape {
    var cornerRadius: CGFloat
    var tail: CGFloat
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let b = CGRect(x: rect.minX, y: rect.minY, width: rect.width, height: rect.height - tail)
        let r = min(cornerRadius, b.height * 0.42, b.width * 0.5)
        p.addRoundedRect(in: b, cornerSize: CGSize(width: r, height: r))
        // Soft incoming tail flaring from the bottom-left corner (iMessage/Messenger style):
        // out from the left edge, down to a rounded tip, then back up onto the bottom edge.
        let bx = b.minX, by = b.maxY
        p.move(to: CGPoint(x: bx, y: by - r * 0.9))
        p.addQuadCurve(to: CGPoint(x: bx - tail * 0.85, y: by + tail * 0.05),
                       control: CGPoint(x: bx - tail * 0.15, y: by - tail * 0.25))
        p.addQuadCurve(to: CGPoint(x: bx + r * 0.75, y: by),
                       control: CGPoint(x: bx - tail * 0.15, y: by + tail * 0.1))
        p.closeSubpath()
        return p
    }
}

/// The single source of truth for rendering an ad (base image + text layers). Used both for the
/// on-screen preview (via the store's renderer) and for export, so the saved PNG matches exactly.
struct AdCanvas: View {
    let baseImage: NSImage?
    let layers: [TextLayer]
    let size: CGSize

    var body: some View {
        let scale = size.width / 1024
        ZStack(alignment: .topLeading) {
            if let baseImage {
                Image(nsImage: baseImage).resizable().scaledToFill()
                    .frame(width: size.width, height: size.height).clipped()
            } else {
                Theme.surface2
            }
            LinearGradient(colors: [.clear, .black.opacity(0.18)], startPoint: .center, endPoint: .bottom)

            ForEach(layers) { layer in
                if layer.isArrow || !CopyText.clean(layer.text).isEmpty {
                    HookText(layer: layer, scale: scale, containerWidth: size.width)
                        .offset(x: size.width * layer.xFrac, y: size.height * layer.yFrac)
                }
            }
        }
        .frame(width: size.width, height: size.height)
    }
}

/// On-screen preview: displays the EXACT rendered bitmap that export produces (when showing text),
/// so the saved file looks identical. Falls back to the bare base image when text is hidden.
struct AdImageView: View {
    let creative: Creative
    let projectID: UUID
    var showText: Bool = true
    @EnvironmentObject var store: AppStore
    @State private var image: NSImage?

    /// Re-render only when something that affects the bitmap changes — not on every hover/scroll.
    private var renderKey: Int {
        var h = Hasher()
        h.combine(creative.imageToken)   // base-bitmap identity (filename+ratio+version+status)
        h.combine(showText); if showText { h.combine(creative.textLayers) }
        return h.finalize()
    }

    /// Cache-only best guess shown instantly (no disk read, no render) so switching back to an
    /// already-seen project/persona has no blank flash. The `.task` fills cold cases.
    private var instant: NSImage? {
        if showText, let p = store.cachedPreview(for: creative) { return p }
        guard let url = store.generatedImageURL(for: creative, in: projectID) else { return nil }
        return ImageStore.shared.cached(url)
    }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                if let shown = image ?? instant {
                    Image(nsImage: shown).resizable().scaledToFill()
                        .frame(width: geo.size.width, height: geo.size.height).clipped()
                } else {
                    Theme.surface2
                }
            }
            .task(id: renderKey) {
                image = await store.displayImage(for: creative, in: projectID, showText: showText)
            }
        }
    }
}

/// Inspector preview that lets the user select, DRAG, resize and edit the hook text on the image.
/// Shows the bare base bitmap with an interactive `TextLayerCanvas` on top; edits commit to the
/// store, which re-renders the baked bitmap.
struct DraggableAdView: View {
    let creative: Creative
    let projectID: UUID
    @EnvironmentObject var store: AppStore

    @State private var selectedID: UUID?
    @State private var base: NSImage?

    /// `imageToken` is the single source of base-bitmap identity (filename+ratio+version+status),
    /// so reloading on it never drifts from the list card or the preview cache.
    private var baseKey: Int { creative.imageToken }

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width, h = geo.size.height
            let hasText = creative.textLayers.contains { !CopyText.clean($0.text).isEmpty }
            ZStack(alignment: .topLeading) {
                // Base image — loaded once (cached, off-main) so editing text never re-reads disk.
                if let base {
                    Image(nsImage: base).resizable().scaledToFill().frame(width: w, height: h).clipped()
                } else { Theme.surface2 }

                TextLayerCanvas(creative: creative, projectID: projectID, selectedID: $selectedID, w: w, h: h)
            }
            .frame(width: w, height: h)
            .contentShape(Rectangle())
            .onTapGesture { selectedID = nil }   // tap empty canvas to deselect
            .task(id: baseKey) {
                base = await store.displayImage(for: creative, in: projectID, showText: false)
            }
            .help(hasText ? "Click to select · drag to move · drag corners to resize · double-click to edit" : "")
        }
    }
}

/// Hook text with its highlight word emphasised in accent (for the card/inspector text rows).
func highlightedHook(_ hook: String, _ highlight: String) -> AttributedString {
    var str = AttributedString(CopyText.clean(hook))
    for term in CopyText.highlightTerms(highlight) {
        if let range = str.range(of: term, options: .caseInsensitive) {
            str[range].foregroundColor = Theme.accent
        }
    }
    return str
}
