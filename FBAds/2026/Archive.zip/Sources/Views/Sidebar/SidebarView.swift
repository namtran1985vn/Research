import SwiftUI
import AppKit

struct SidebarView: View {
    @EnvironmentObject var store: AppStore

    /// User-chosen height of the Campaign region, set by dragging the divider. Persisted so the
    /// split survives relaunch. Clamped at render time to keep both regions usable.
    @AppStorage("sidebarCampaignHeight") private var campaignHeightPref: Double = 240
    /// Campaign height captured when a divider drag begins, so translation is applied to a stable base.
    @State private var dragStartHeight: CGFloat?
    @State private var dividerHover = false

    private let minProjects: CGFloat = 140   // Projects always keeps at least this much
    private let minCampaign: CGFloat = 78     // Campaign never collapses below its header + 1 row

    var body: some View {
        GeometryReader { geo in
            let maxCampaign = max(minCampaign, geo.size.height - minProjects)
            let campaignH = min(max(CGFloat(campaignHeightPref), minCampaign), maxCampaign)

            VStack(spacing: 0) {
                // PROJECTS — flexible top region with its own scroll; a long list scrolls here
                // instead of pushing the Campaign off-screen.
                VStack(alignment: .leading, spacing: 0) {
                    Color.clear.frame(height: 38)   // clear the traffic lights
                    SidebarHeader("Projects")
                    ScrollView {
                        VStack(spacing: 2) {
                            if store.projects.isEmpty {
                                Text("No projects yet")
                                    .font(.system(size: 11.5)).foregroundStyle(Theme.ink3)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(.horizontal, 9).padding(.vertical, 8)
                            }
                            ForEach(store.projects) { project in
                                ProjectItem(project: project,
                                            active: store.selectedProjectID == project.id,
                                            running: project.isAnalyzing || isRunning(project))
                                    .onTapGesture { store.selectProject(project.id) }
                                    .contextMenu {
                                        Button { store.togglePin(project.id) } label: {
                                            Label(project.pinned ? "Unpin" : "Pin", systemImage: project.pinned ? "pin.slash" : "pin")
                                        }
                                        Divider()
                                        Button { store.activeSheet = .regenerateProject(project.id) } label: { Label("Re-generate Project…", systemImage: "arrow.clockwise") }
                                        if store.hasBackup(project: project.id) {
                                            Button { store.restoreBackup(project: project.id) } label: { Label("Restore Version Before Regenerate", systemImage: "clock.arrow.circlepath") }
                                        }
                                        Button { store.activeSheet = .duplicateProject(project.id) } label: { Label("Duplicate Project…", systemImage: "plus.square.on.square") }
                                        Divider()
                                        Button("Delete Project", role: .destructive) { store.deleteProject(project.id) }
                                    }
                            }
                        }
                        .padding(.horizontal, 10).padding(.bottom, 12)
                    }
                    .scrollIndicators(.never)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)

                // CAMPAIGN — pinned to the bottom, always visible. Its height is set by dragging
                // the divider above it; it scrolls internally when a project has many personas.
                if let project = store.selectedProject {
                    divider(maxCampaign: maxCampaign)
                    VStack(alignment: .leading, spacing: 0) {
                        HStack(spacing: 0) {
                            SidebarHeader("Campaign")
                            Spacer(minLength: 0)
                            Button { store.activeSheet = .ranking } label: {
                                Glyph(name: "plus", size: 11, weight: .semibold, color: Theme.ink2)
                                    .frame(width: 20, height: 20)
                                    .background(Theme.surface)
                                    .overlay(RoundedRectangle(cornerRadius: 6).strokeBorder(Theme.border, lineWidth: 0.5))
                                    .clipShape(RoundedRectangle(cornerRadius: 6))
                            }
                            .buttonStyle(.plain)
                            .help("Add persona — open persona ranking")
                            .padding(.trailing, 14)
                        }
                        ScrollView {
                            campaignContent(project)
                        }
                        .scrollIndicators(.never)
                    }
                    .frame(maxWidth: .infinity, alignment: .top)
                    .frame(height: campaignH)
                    .clipped()
                    .padding(.bottom, 12)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .background(Theme.sidebar)
        }
        .background(Theme.sidebar)
        .overlay(alignment: .trailing) { Rectangle().fill(Theme.borderStrong).frame(width: 0.5) }
    }

    /// Draggable splitter between Projects and Campaign. Drag up → Campaign grows, Projects shrinks;
    /// drag down → the reverse. A grab handle + row-resize cursor signal it's interactive.
    private func divider(maxCampaign: CGFloat) -> some View {
        ZStack {
            Rectangle().fill(Theme.borderStrong).frame(height: 0.5)
            // Grip pill — brightens on hover/drag so the divider reads as a control.
            Capsule()
                .fill((dividerHover || dragStartHeight != nil) ? Theme.accent : Theme.ink4.opacity(0.5))
                .frame(width: 26, height: 3)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 11)
        .contentShape(Rectangle())   // whole 11pt strip is the hit target, not just the hairline
        .onHover { hovering in
            dividerHover = hovering
            if hovering { NSCursor.resizeUpDown.push() } else { NSCursor.pop() }
        }
        .gesture(
            DragGesture(minimumDistance: 1)
                .onChanged { value in
                    let base = dragStartHeight ?? CGFloat(campaignHeightPref)
                    if dragStartHeight == nil { dragStartHeight = base }
                    // Drag up (negative translation) enlarges Campaign.
                    let proposed = base - value.translation.height
                    campaignHeightPref = Double(min(max(proposed, minCampaign), maxCampaign))
                }
                .onEnded { _ in dragStartHeight = nil }
        )
    }

    @ViewBuilder
    private func campaignContent(_ project: Project) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 6) {
                Glyph(name: "layers", size: 13, color: Theme.accent)
                Text(project.name).font(.system(size: 12, weight: .bold))
                    .foregroundStyle(Theme.ink2).lineLimit(1)
            }
            .padding(.horizontal, 9).padding(.vertical, 5)

            VStack(spacing: 0) {
                ForEach(project.personas) { persona in
                    PersonaRow(persona: persona,
                               selected: store.selectedPersonaID == persona.id,
                               regenerating: store.regeneratingPersonaIDs.contains(persona.id))
                        .onTapGesture { store.selectPersona(persona.id) }
                        .contextMenu {
                            Button { store.togglePersonaWinner(project: project.id, persona: persona.id) } label: {
                                Label(persona.winner ? "Unmark Winner" : "Mark as Winner",
                                      systemImage: persona.winner ? "trophy.fill" : "trophy")
                            }
                            Button { store.activeSheet = .regeneratePersona(project: project.id, persona: persona.id) } label: {
                                Label("Re-generate…", systemImage: "arrow.clockwise")
                            }
                            Button { store.duplicatePersona(project: project.id, persona: persona.id) } label: {
                                Label("Duplicate", systemImage: "plus.square.on.square")
                            }
                            Divider()
                            Button("Remove", role: .destructive) {
                                store.removePersona(project: project.id, persona: persona.id)
                            }
                        }
                }

                // Loading placeholders for personas being generated right now — appear the instant
                // the user taps "Add" / "Add persona", before the model returns.
                ForEach(project.ranking.filter { store.addingPersonaIDs.contains($0.id) && !$0.picked }) { r in
                    PendingPersonaRow(name: r.name, audience: r.audience, score: r.score)
                }
                if store.addingCustomPersonaPID == project.id {
                    PendingPersonaRow(name: "Persona mới…")
                }
            }
            .padding(.leading, 6)
            .overlay(alignment: .leading) {
                Rectangle().fill(Theme.borderStrong).frame(width: 1)
            }
            .padding(.leading, 6)
        }
        .padding(.horizontal, 10)
    }

    private func isRunning(_ project: Project) -> Bool {
        project.personas.contains { $0.creatives.contains { $0.status.isInFlight } }
    }
}

struct SidebarHeader: View {
    let title: String
    init(_ title: String) { self.title = title }
    var body: some View {
        Text(title.uppercased())
            .font(.system(size: 10.5, weight: .bold)).tracking(0.6)
            .foregroundStyle(Theme.ink3)
            .padding(.horizontal, 18).padding(.top, 4).padding(.bottom, 6)
    }
}

struct ProjectItem: View {
    let project: Project
    let active: Bool
    let running: Bool
    @State private var hover = false

    private var meta: String {
        if project.isAnalyzing { return "Analyzing strategy…" }
        if running {
            let t = project.totals
            return "Generating · \(t.done)/\(t.total)"
        }
        return "\(project.personas.count) personas · \(project.totals.total) creatives"
    }

    var body: some View {
        HStack(spacing: 8) {
            ZStack {
                RoundedRectangle(cornerRadius: 6)
                    .fill(active ? AnyShapeStyle(Theme.accentGradient) : AnyShapeStyle(Theme.surface3))
                    .overlay(RoundedRectangle(cornerRadius: 6).strokeBorder(Theme.border, lineWidth: 0.5))
                    .frame(width: 24, height: 24)
                Glyph(name: "grid", size: 12, color: active ? Color(hex: 0xFBF7EE) : Theme.ink3)
            }
            VStack(alignment: .leading, spacing: 1) {
                Text(project.name).font(.system(size: 12.5, weight: active ? .bold : .semibold))
                    .foregroundStyle(Theme.ink).lineLimit(1)
                HStack(spacing: 4) {
                    if running { Spinner(size: 8, lineWidth: 1.3) }
                    Text(meta).font(.system(size: 10.5)).foregroundStyle(running ? Theme.run : Theme.ink3)
                }
            }
            Spacer(minLength: 0)
            if project.pinned {
                Glyph(name: "pin", size: 10, color: Theme.ink3)
            }
        }
        .padding(.horizontal, 9).padding(.vertical, 7)
        .background(active ? Theme.accentSoft : (hover ? Color.white.opacity(0.5) : Color.clear))
        .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(active ? Theme.accentLine : .clear, lineWidth: 0.5))
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .contentShape(Rectangle())
        .onHover { hover = $0 }
    }
}

struct PersonaRow: View {
    let persona: Persona
    let selected: Bool
    var regenerating: Bool = false
    @State private var hover = false

    private var done: Int { persona.creatives.filter { $0.status == .done }.count }
    private var total: Int { persona.creatives.count }
    private var running: Bool { persona.creatives.contains { $0.status.isInFlight } }

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 6) {
                Circle().fill(selected ? Theme.accent : Theme.ink4).frame(width: 4, height: 4)
                Text(persona.name).font(.system(size: 12.5, weight: selected ? .bold : .semibold))
                    .tracking(-0.1).foregroundStyle(Theme.ink).lineLimit(1)
                Spacer(minLength: 0)
                if regenerating { Spinner(size: 9, lineWidth: 1.4) }
                if persona.winner {
                    Image(systemName: "trophy.fill").font(.system(size: 9)).foregroundStyle(Theme.accent)
                }
            }
            HStack(spacing: 6) {
                AudienceTag(audience: persona.audience)
                HStack(spacing: 2.5) {
                    Glyph(name: "star", size: 10, color: Theme.accent)
                    Text("\(persona.score)").font(.system(size: 10.5, weight: .bold)).foregroundStyle(Theme.accentInk)
                }
                Spacer(minLength: 0)
                if running { Spinner(size: 9, lineWidth: 1.4) }
                Text("\(done)/\(total)").font(.system(size: 10, weight: .semibold)).monospacedDigit()
                    .foregroundStyle(Theme.ink3)
                ProgressPips(done: done, total: total)
            }
            .padding(.leading, 10)
        }
        .padding(.horizontal, 9).padding(.vertical, 7)
        .background(selected ? Theme.surface : (hover ? Color.white.opacity(0.5) : Color.clear))
        .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(selected ? Theme.borderStrong : .clear, lineWidth: 0.5))
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .modifier(ConditionalRowShadow(active: selected))
        .contentShape(Rectangle())
        .onHover { hover = $0 }
    }
}

/// A non-interactive campaign row shown while a persona is still being generated by the model.
/// Mirrors `PersonaRow`'s layout so the real row slides in seamlessly once generation completes.
struct PendingPersonaRow: View {
    let name: String
    var audience: String? = nil
    var score: Int? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 6) {
                Circle().fill(Theme.ink4).frame(width: 4, height: 4)
                Text(name).font(.system(size: 12.5, weight: .semibold))
                    .tracking(-0.1).foregroundStyle(Theme.ink2).lineLimit(1)
                Spacer(minLength: 0)
                Spinner(size: 9, lineWidth: 1.4)
            }
            HStack(spacing: 6) {
                if let audience { AudienceTag(audience: audience) }
                if let score {
                    HStack(spacing: 2.5) {
                        Glyph(name: "star", size: 10, color: Theme.accent)
                        Text("\(score)").font(.system(size: 10.5, weight: .bold)).foregroundStyle(Theme.accentInk)
                    }
                }
                Spacer(minLength: 0)
                Text("Đang tạo…").font(.system(size: 10, weight: .semibold)).foregroundStyle(Theme.ink3)
            }
            .padding(.leading, 10)
        }
        .padding(.horizontal, 9).padding(.vertical, 7)
        .opacity(0.7)
        .contentShape(Rectangle())
    }
}

private struct ConditionalRowShadow: ViewModifier {
    let active: Bool
    func body(content: Content) -> some View { active ? AnyView(content.cardShadow()) : AnyView(content) }
}

struct ProgressPips: View {
    let done: Int
    let total: Int
    var body: some View {
        HStack(spacing: 2.5) {
            ForEach(0..<max(0, total), id: \.self) { i in
                Circle().fill(i < done ? Theme.ok : Theme.borderStrong).frame(width: 5, height: 5)
            }
        }
    }
}
