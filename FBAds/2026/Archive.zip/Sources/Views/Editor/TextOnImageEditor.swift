import SwiftUI
import AppKit

/// S3 — light text-on-image editor. Drag text blocks over the AI render (which left
/// negative space), tune font/size/color/highlight/alignment, then composite + save a clean PNG.
struct TextOnImageEditor: View {
    let creative: Creative
    let persona: Persona
    let projectID: UUID
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss

    @State private var layers: [TextLayer]
    @State private var selectedID: UUID?
    @State private var base: NSImage?
    @State private var blocksExpanded = false

    init(creative: Creative, persona: Persona, projectID: UUID) {
        self.creative = creative; self.persona = persona; self.projectID = projectID
        let seeded = creative.textLayers.isEmpty ? [TextLayer.seed(from: creative)] : creative.textLayers
        _layers = State(initialValue: seeded)
        _selectedID = State(initialValue: seeded.first?.id)
    }

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider().overlay(Theme.border)
            HStack(spacing: 0) {
                canvas
                Divider().overlay(Theme.borderStrong)
                controls.frame(width: 300)
            }
        }
        // Cap against the logical canvas so the editor stays inside the window at any zoom level.
        // The canvas area derives its size from geometry, so it absorbs the smaller frame cleanly.
        .frame(width: min(900, store.canvasSize.width - 32),
               height: min(640, store.canvasSize.height - 32))
        .background(Theme.bgWindow)
    }

    private var header: some View {
        HStack(spacing: 10) {
            Glyph(name: "text", size: 15, color: Theme.accent)
            Text("Text-on-image editor").font(.system(size: 15, weight: .bold))
            Text("·  \(persona.name) · #\(creative.rank)").font(.system(size: 12)).foregroundStyle(Theme.ink3)
            Spacer()
            AppButton(title: "Done", variant: .secondary, size: .sm) { commit(); dismiss() }
        }
        .padding(.horizontal, 16).padding(.vertical, 12)
    }

    // MARK: Canvas

    private var canvas: some View {
        GeometryReader { geo in
            let maxW = geo.size.width - 40
            let maxH = geo.size.height - 40
            let ratio = creative.ratio.value           // width / height
            let w = min(maxW, maxH * ratio)
            let h = w / ratio
            // top-leading anchor MUST match AdCanvas (the export/preview renderer) so a layer's
            // xFrac/yFrac lands in the same spot here as it does on the image outside.
            ZStack(alignment: .topLeading) {
                if let base {
                    Image(nsImage: base).resizable().scaledToFill().frame(width: w, height: h).clipped()
                } else { Theme.surface2.frame(width: w, height: h) }

                ForEach($layers) { $layer in
                    EditableLayer(layer: $layer, canvasW: w, canvasH: h,
                                  selected: selectedID == layer.id,
                                  onSelect: { selectedID = layer.id },
                                  onChange: { commit() })
                }
            }
            .frame(width: w, height: h)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .overlay(RoundedRectangle(cornerRadius: 10).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
            .cardShadow()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            // ⌘C / ⌘V / Delete for the selected block — same window-local monitor as the inline canvas.
            .background(LayerKeyCommands(
                hasSelection: selectedID != nil,
                onCopy: {
                    if let id = selectedID, let layer = layers.first(where: { $0.id == id }) { store.copyLayer(layer) }
                },
                onPaste: {
                    guard let clip = store.layerClipboard else { return }
                    let copy = AppStore.pastedCopy(of: clip)
                    layers.append(copy); selectedID = copy.id; commit()
                },
                onDelete: {
                    if let id = selectedID { removeBlock(id) }
                }))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Theme.surface2)
        .task(id: creative.imageFilename) {
            base = await store.displayImage(for: creative, in: projectID, showText: false)
        }
    }

    // MARK: Controls

    private var controls: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Button(action: { withAnimation(.easeInOut(duration: 0.18)) { blocksExpanded.toggle() } }) {
                        HStack(spacing: 5) {
                            Glyph(name: "chevron", size: 9, weight: .bold, color: Theme.ink3)
                                .rotationEffect(.degrees(blocksExpanded ? 90 : 0))
                            Text("TEXT BLOCKS").font(.system(size: 10.5, weight: .bold)).tracking(0.4).foregroundStyle(Theme.ink3)
                            Text("\(layers.count)").font(.system(size: 10.5, weight: .bold)).foregroundStyle(Theme.ink3.opacity(0.7))
                        }
                    }.buttonStyle(.plain)
                    Spacer()
                    Menu {
                        Button("Add text", action: addBlock)
                        Button("Add arrow", action: addArrow)
                    } label: { Glyph(name: "plus", size: 13, color: Theme.accent) }
                        .menuStyle(.borderlessButton).menuIndicator(.hidden).fixedSize()
                }
                if blocksExpanded {
                    ForEach(layers) { layer in
                        Button(action: { selectedID = layer.id }) {
                            HStack(spacing: 8) {
                                Glyph(name: "text", size: 12, color: selectedID == layer.id ? Theme.accentInk : Theme.ink3)
                                Text(layer.isArrow ? "Arrow  ➜" : (layer.text.isEmpty ? "Empty block" : layer.text)).font(.system(size: 12)).lineLimit(1)
                                    .foregroundStyle(Theme.ink)
                                Spacer(minLength: 0)
                                if layers.count > 1 {
                                    Button(action: { removeBlock(layer.id) }) { Glyph(name: "trash", size: 12, color: Theme.ink3) }.buttonStyle(.plain)
                                }
                            }
                            .padding(.horizontal, 10).padding(.vertical, 7)
                            .background(selectedID == layer.id ? Theme.accentSoft : Theme.surface)
                            .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(selectedID == layer.id ? Theme.accentLine : Theme.border, lineWidth: 0.5))
                            .clipShape(RoundedRectangle(cornerRadius: 7))
                        }.buttonStyle(.plain)
                    }
                }

                if let idx = layers.firstIndex(where: { $0.id == selectedID }) {
                    Divider().overlay(Theme.border)
                    layerControls(idx)
                }
            }
            .padding(16)
        }
        .scrollIndicators(.automatic)
        .background(Theme.bgWindow)
    }

    /// A wrapping row of color swatches (premium + DR palettes don't fit one line). The selected
    /// swatch gets an accent ring; every swatch keeps a hairline border so white reads on white.
    private func swatchGrid(_ colors: [UInt], selected: UInt, pick: @escaping (UInt) -> Void) -> some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 22, maximum: 22), spacing: 8)],
                  alignment: .leading, spacing: 8) {
            ForEach(colors, id: \.self) { hex in
                Circle().fill(Color(hex: hex)).frame(width: 22, height: 22)
                    .overlay(Circle().strokeBorder(selected == hex ? Theme.accent : Theme.border,
                                                   lineWidth: selected == hex ? 2 : 0.5))
                    .onTapGesture { pick(hex) }
            }
        }
    }

    @ViewBuilder
    private func layerControls(_ idx: Int) -> some View {
        let binding = $layers[idx]
        if layers[idx].isArrow {
            // Arrow blocks have no text/style/font — just size (drag corners on canvas also resizes).
            VStack(alignment: .leading, spacing: 12) {
                ctlLabel("Before → After arrow")
                Text("Drag to move · drag a corner to resize.")
                    .font(.system(size: 11)).foregroundStyle(Theme.ink3)
                ctlLabel("Size  ·  \(Int(layers[idx].fontSize))")
                Slider(value: binding.fontSize, in: 24...140, step: 1).tint(Theme.accent)
                    .onChange(of: layers[idx].fontSize) { _, _ in commit() }
            }
        } else {
            textLayerControls(idx)
        }
    }

    @ViewBuilder
    private func textLayerControls(_ idx: Int) -> some View {
        let binding = $layers[idx]
        VStack(alignment: .leading, spacing: 12) {
            ctlLabel("Text")
            TextEditor(text: binding.text)
                .font(.system(size: 13)).scrollContentBackground(.hidden).frame(height: 56)
                .padding(7).background(Theme.surface)
                .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: 7))
                .onChange(of: layers[idx].text) { _, _ in commit() }

            ctlLabel("Style")
            Picker("", selection: binding.hookStyle) {
                ForEach(HookStyle.allCases, id: \.self) { Text($0.label).tag($0) }
            }.labelsHidden()
                .onChange(of: layers[idx].hookStyle) { _, newStyle in
                    // Style is a preset: seed the explicit colors / box / weight / font, which the
                    // swatches below can then override.
                    layers[idx].apply(style: newStyle)
                    commit()
                }

            if layers[idx].hookStyle == .annotation {
                ctlLabel("Annotation mark")
                Picker("", selection: binding.annotationKind) {
                    ForEach(AnnotationKind.allCases, id: \.self) { Text($0.label).tag($0) }
                }.labelsHidden().pickerStyle(.segmented)
                    .onChange(of: layers[idx].annotationKind) { _, _ in commit() }
            }

            if layers[idx].hookStyle == .stamp && Stamps.images.count > 1 {
                ctlLabel("Stamp")
                Picker("", selection: binding.stampVariant) {
                    ForEach(0..<Stamps.images.count, id: \.self) { Text(Stamps.label($0)).tag($0) }
                }.labelsHidden().pickerStyle(.segmented)
                    .onChange(of: layers[idx].stampVariant) { _, _ in commit() }
            }

            ctlLabel("Font")
            Picker("", selection: binding.fontName) {
                ForEach(AppSettings.fontOptions, id: \.self) { Text($0).tag($0) }
            }.labelsHidden()

            ctlLabel("Size  ·  \(Int(layers[idx].fontSize))")
            Slider(value: binding.fontSize, in: 24...140, step: 1).tint(Theme.accent)
                .onChange(of: layers[idx].fontSize) { _, _ in commit() }

            ctlLabel("Color")
            swatchGrid(HookPalette.text, selected: layers[idx].colorHex) { layers[idx].colorHex = $0; commit() }

            ctlLabel("Background")
            swatchGrid(HookPalette.box, selected: layers[idx].boxColorHex) { layers[idx].boxColorHex = $0; commit() }

            ctlLabel("Highlight word")
            TextField("e.g. clinic, sạch sẽ", text: binding.highlightWord)
                .textFieldStyle(.plain).font(.system(size: 12))
                .padding(.horizontal, 9).padding(.vertical, 6)
                .background(Theme.surface)
                .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: 7))
                .onChange(of: layers[idx].highlightWord) { _, _ in commit() }

            ctlLabel("Highlight color")
            swatchGrid(HookPalette.highlight, selected: layers[idx].highlightColorHex) { layers[idx].highlightColorHex = $0; commit() }

            ctlLabel("Alignment")
            SegmentedControl(selection: binding.alignment, options: ["leading", "center", "trailing"])
                .onChange(of: layers[idx].alignment) { _, _ in commit() }

            HStack(spacing: 16) {
                Toggle(isOn: binding.bold) { Text("Bold").font(.system(size: 12)) }.toggleStyle(.checkbox)
                    .onChange(of: layers[idx].bold) { _, _ in commit() }
                Toggle(isOn: binding.italic) { Text("Italic").font(.system(size: 12)) }.toggleStyle(.checkbox)
                    .onChange(of: layers[idx].italic) { _, _ in commit() }
                Toggle(isOn: binding.shadow) { Text("Caption box").font(.system(size: 12)) }.toggleStyle(.checkbox)
                    .onChange(of: layers[idx].shadow) { _, _ in commit() }
            }

            let coverage = layers[idx].widthFrac * Double(layers[idx].fontSize) / 600.0
            if coverage > 0.25 {
                HStack(spacing: 5) {
                    Glyph(name: "warn", size: 11, color: Theme.queue)
                    Text("Text may cover a lot of the image — keep it under ~¼.")
                        .font(.system(size: 10.5)).foregroundStyle(Theme.queue)
                }
            }
        }
    }

    private func ctlLabel(_ t: String) -> some View {
        Text(t.uppercased()).font(.system(size: 10, weight: .bold)).tracking(0.3).foregroundStyle(Theme.ink3)
    }

    // MARK: Actions

    private func addBlock() {
        var l = TextLayer(text: "New text", yFrac: 0.5)
        l.fontSize = 48
        layers.append(l)
        selectedID = l.id
        commit()
    }
    private func addArrow() {
        var l = TextLayer(text: "")
        l.isArrow = true
        l.fontSize = 28
        l.xFrac = 0.42; l.yFrac = 0.46
        layers.append(l)
        selectedID = l.id
        commit()
    }
    private func removeBlock(_ id: UUID) {
        layers.removeAll { $0.id == id }
        if selectedID == id { selectedID = layers.first?.id }
        commit()
    }
    private func commit() {
        store.updateTextLayers(project: projectID, creative: creative.id, layers: layers)
    }
}

/// A draggable, selectable text layer overlaid on the editor canvas.
struct EditableLayer: View {
    @Binding var layer: TextLayer
    let canvasW: CGFloat
    let canvasH: CGFloat
    let selected: Bool
    let onSelect: () -> Void
    let onChange: () -> Void

    @State private var dragOrigin: CGPoint?      // layer position (frac) captured at gesture start
    @State private var resizeStartFont: Double?

    var body: some View {
        let scale = canvasW / 1024
        // The text block carries the MOVE gesture. Handles are layered on top AFTER this,
        // so a press on a handle never reaches the move gesture underneath.
        let block = HookText(layer: layer, scale: scale, containerWidth: canvasW)
            .padding(4)
            .overlay(RoundedRectangle(cornerRadius: 4).strokeBorder(Theme.accent, style: StrokeStyle(lineWidth: selected ? 1 : 0, dash: [3,3])))
            .contentShape(Rectangle())
            .onTapGesture { onSelect() }
            // .global space + an origin captured once → translation is pure cursor movement,
            // immune to the block's own offset shifting under it (which caused jitter).
            .gesture(
                DragGesture(minimumDistance: 2, coordinateSpace: .global)
                    .onChanged { value in
                        onSelect()
                        let origin = dragOrigin ?? CGPoint(x: layer.xFrac, y: layer.yFrac)
                        if dragOrigin == nil { dragOrigin = origin }
                        // Free placement across the whole canvas — the editor mirrors the export
                        // pixel-for-pixel, so the user sees exactly where text lands.
                        layer.xFrac = min(max(0, origin.x + value.translation.width / canvasW), 0.95)
                        layer.yFrac = min(max(0, origin.y + value.translation.height / canvasH), 0.95)
                    }
                    .onEnded { _ in dragOrigin = nil; onChange() }
            )

        block
            .overlay(alignment: .topLeading) {
                if selected { sizeControl.offset(y: -38).fixedSize() }
            }
            // Corner resize handles, drawn on top of (and outside) the move gesture.
            .overlay(alignment: .topLeading)     { handle(.tl, scale: scale) }
            .overlay(alignment: .topTrailing)    { handle(.tr, scale: scale) }
            .overlay(alignment: .bottomLeading)  { handle(.bl, scale: scale) }
            .overlay(alignment: .bottomTrailing) { handle(.br, scale: scale) }
            // -4 cancels the block's padding(4) so the TEXT corner (not the padded box corner)
            // sits at xFrac/yFrac — matching HookText's offset in AdCanvas exactly.
            .offset(x: canvasW * layer.xFrac - 4, y: canvasH * layer.yFrac - 4)
    }

    /// Which corner a resize handle sits on — `dir` points "outward" (the grow direction).
    private enum Corner {
        case tl, tr, bl, br
        var dir: CGSize {
            switch self {
            case .tl: return CGSize(width: -1, height: -1)
            case .tr: return CGSize(width:  1, height: -1)
            case .bl: return CGSize(width: -1, height:  1)
            case .br: return CGSize(width:  1, height:  1)
            }
        }
    }

    @ViewBuilder
    private func handle(_ corner: Corner, scale: CGFloat) -> some View {
        if selected {
            let dot: CGFloat = 13      // visible knob
            let hit: CGFloat = 30      // generous grab zone
            Circle()
                .fill(Color.white)
                .overlay(Circle().strokeBorder(Theme.accent, lineWidth: 1.5))
                .frame(width: dot, height: dot)
                .shadow(color: .black.opacity(0.22), radius: 1.5, y: 0.5)
                .frame(width: hit, height: hit)        // enlarge hit target, knob stays centered
                .contentShape(Circle())
                .offset(x: corner.dir.width * hit, y: corner.dir.height * hit)  // inner edge at corner, fully outside block's contentShape
                .onHover { inside in
                    if inside { NSCursor.crosshair.push() } else { NSCursor.pop() }
                }
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            onSelect()
                            if resizeStartFont == nil { resizeStartFont = layer.fontSize }
                            let start = resizeStartFont ?? layer.fontSize
                            // Drag projected onto the corner's outward diagonal, averaged across the two
                            // axes, then converted from screen px → canvas points.
                            let proj = (value.translation.width * corner.dir.width
                                        + value.translation.height * corner.dir.height) / 2
                            let delta = (proj / max(scale, 0.0001)) / 1.3
                            layer.fontSize = min(140, max(24, (start + delta).rounded()))
                        }
                        .onEnded { _ in resizeStartFont = nil; onChange() }
                )
                .zIndex(1)
        }
    }

    /// Inline font-size stepper that floats just above the selected block.
    private var sizeControl: some View {
        HStack(spacing: 4) {
            sizeBtn(icon: "minus") { adjustSize(-2) }
            Text("\(Int(layer.fontSize))")
                .font(.system(size: 11, weight: .bold)).monospacedDigit()
                .foregroundStyle(.white).frame(minWidth: 24)
            sizeBtn(icon: "plus") { adjustSize(2) }
        }
        .padding(.horizontal, 6).padding(.vertical, 4)
        .background(Capsule().fill(Color.black.opacity(0.82)))
        .overlay(Capsule().strokeBorder(Theme.accent.opacity(0.7), lineWidth: 0.5))
    }

    private func sizeBtn(icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Glyph(name: icon, size: 11, weight: .bold, color: .white)
                .frame(width: 20, height: 20)
                .background(Color.white.opacity(0.14))
                .clipShape(Circle())
        }
        .buttonStyle(.plain)
    }

    private func adjustSize(_ delta: Double) {
        layer.fontSize = min(140, max(24, layer.fontSize + delta))
        onChange()
    }
}
