import SwiftUI

struct RootView: View {
    @EnvironmentObject var store: AppStore

    /// Inspector sizing. It shrinks from `max` down to `min` as the window narrows, and below
    /// `minContent + min` there isn't enough room to keep both panes usable, so the inspector
    /// auto-collapses (the user re-opens it once the window grows back).
    private let inspectorMax: CGFloat = 460
    private let inspectorMin: CGFloat = 300
    private let minContent: CGFloat = 340

    var body: some View {
        HStack(spacing: 0) {
            if store.sidebarOpen {
                SidebarView()
                    .frame(width: 244)
                    .transition(.move(edge: .leading).combined(with: .opacity))
            }

            VStack(spacing: 0) {
                ToolbarBar()
                Divider().overlay(Theme.border)
                GeometryReader { geo in
                    let avail = geo.size.width
                    let showInspector = store.screen == .results && store.inspectorOpen
                    let inspectorW = min(inspectorMax, max(inspectorMin, avail - minContent))
                    HStack(spacing: 0) {
                        Group {
                            if store.screen == .input {
                                InputScreen()
                            } else {
                                ResultsView()
                            }
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)

                        if showInspector {
                            Divider().overlay(Theme.borderStrong)
                            InspectorView()
                                .frame(width: inspectorW)
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    // Auto-collapse the inspector when the content area would be squeezed below a
                    // usable width (e.g. when zoomed in or the window is dragged narrow).
                    .onChange(of: avail) { _, w in
                        if store.inspectorOpen && w < minContent + inspectorMin {
                            store.inspectorOpen = false
                        }
                    }
                }
            }
            .background(Theme.bgWindow)
        }
        .background(Theme.bgWindow)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .overlay(alignment: .bottom) {
            if let toast = store.toast { ToastView(toast: toast).padding(.bottom, 20) }
        }
        .sheet(item: $store.activeSheet) { sheet in
            switch sheet {
            case .settings: SettingsSheet()
            case .ranking:  PersonaRankingSheet()
            case .regenerateProject(let id): RegenerateProjectSheet(projectID: id, mode: .regenerate)
            case .duplicateProject(let id): RegenerateProjectSheet(projectID: id, mode: .duplicate)
            case .regeneratePersona(let pid, let personaID): RegeneratePersonaSheet(projectID: pid, personaID: personaID)
            }
        }
        .animation(.easeInOut(duration: 0.22), value: store.inspectorOpen)
        .animation(.easeInOut(duration: 0.22), value: store.sidebarOpen)
        .animation(.easeOut(duration: 0.2), value: store.toast)
    }
}
