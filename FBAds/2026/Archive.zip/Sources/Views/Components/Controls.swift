import SwiftUI

/// Big N×M number stepper card used on the input screen.
struct NumberStepper: View {
    let label: String
    let sub: String
    @Binding var value: Int
    let range: ClosedRange<Int>

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(label).font(.system(size: 12.5, weight: .bold)).foregroundStyle(Theme.ink)
            Text(sub).font(.system(size: 11)).foregroundStyle(Theme.ink3).padding(.top, 1)
            HStack(spacing: 12) {
                stepBtn(icon: "minus", enabled: value > range.lowerBound) { value = max(range.lowerBound, value - 1) }
                Text("\(value)")
                    .font(.system(size: 28, weight: .bold)).tracking(-0.5)
                    .monospacedDigit()
                    .foregroundStyle(Theme.ink)
                    .frame(minWidth: 36)
                stepBtn(icon: "plus", enabled: value < range.upperBound) { value = min(range.upperBound, value + 1) }
            }
            .padding(.top, 11)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(Theme.surface)
        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.card).strokeBorder(Theme.border, lineWidth: 0.5))
        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.card))
        .cardShadow()
    }

    private func stepBtn(icon: String, enabled: Bool, action: @escaping () -> Void) -> some View {
        Button(action: { if enabled { action() } }) {
            Glyph(name: icon, size: 14, weight: .semibold, color: enabled ? Theme.ink : Theme.ink4)
                .frame(width: 30, height: 30)
                .background(enabled ? Theme.surface : Theme.surface2)
                .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: 7))
        }
        .buttonStyle(.plain)
    }
}

/// Segmented control (Sales/Leads, Rank/Score …).
struct SegmentedControl: View {
    @Binding var selection: String
    let options: [String]

    var body: some View {
        HStack(spacing: 2) {
            ForEach(options, id: \.self) { o in
                Button(action: { selection = o }) {
                    Text(o)
                        .font(.system(size: 11, weight: .semibold))
                        .lineLimit(1).fixedSize()
                        .foregroundStyle(selection == o ? Theme.ink : Theme.ink2)
                        .padding(.vertical, 6).padding(.horizontal, 11)
                        .background(selection == o ? Theme.surface : Color.clear)
                        .clipShape(RoundedRectangle(cornerRadius: 6))
                        .modifier(ConditionalCardShadow(active: selection == o))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(3)
        .background(Theme.surface2)
        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.border, lineWidth: 0.5))
        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
    }
}

extension View {
    /// Conditionally apply a modifier. Keeps call sites readable when something (e.g. a context
    /// menu) should attach only in certain states.
    @ViewBuilder func applyIf<V: View>(_ condition: Bool, _ transform: (Self) -> V) -> some View {
        if condition { transform(self) } else { self }
    }
}

private struct ConditionalCardShadow: ViewModifier {
    let active: Bool
    func body(content: Content) -> some View { active ? AnyView(content.cardShadow()) : AnyView(content) }
}

/// Pill toggle switch.
struct PillToggle: View {
    @Binding var isOn: Bool
    var body: some View {
        Button(action: { isOn.toggle() }) {
            ZStack(alignment: isOn ? .trailing : .leading) {
                Capsule().fill(isOn ? Theme.ok : Theme.borderStrong).frame(width: 40, height: 23)
                Circle().fill(.white).frame(width: 19, height: 19)
                    .shadow(color: .black.opacity(0.25), radius: 1.5, y: 1)
                    .padding(2)
            }
        }
        .buttonStyle(.plain)
        .animation(.easeOut(duration: 0.16), value: isOn)
    }
}

/// Labeled text field / textarea used on the input form & settings.
struct FormField: View {
    let label: String
    @Binding var text: String
    var placeholder: String = ""
    var required: Bool = false
    var multiline: Bool = false
    var suffix: String? = nil
    var secure: Bool = false

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 0) {
                Text(label).font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.ink2)
                if required { Text(" *").font(.system(size: 11.5, weight: .semibold)).foregroundStyle(Theme.accent) }
            }
            if multiline {
                TextEditor(text: $text)
                    .font(.system(size: 13)).foregroundStyle(Theme.ink)
                    .scrollContentBackground(.hidden)
                    .frame(minHeight: 72)
                    .padding(.horizontal, 7).padding(.vertical, 6)
                    .background(Theme.surface)
                    .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
                    .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
                    .cardShadow()
            } else {
                HStack(spacing: 0) {
                    Group {
                        if secure { SecureField(placeholder, text: $text) }
                        else { TextField(placeholder, text: $text) }
                    }
                    .textFieldStyle(.plain)
                    .font(.system(size: 13)).foregroundStyle(Theme.ink)
                    if let suffix { Text(suffix).font(.system(size: 12)).foregroundStyle(Theme.ink3) }
                }
                .padding(.horizontal, 11)
                .frame(height: 34)
                .background(Theme.surface)
                .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
                .cardShadow()
            }
        }
    }
}
