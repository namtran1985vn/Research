import SwiftUI

/// A selectable list of AI-written variants. The chosen one is highlighted and becomes the
/// active value used for rendering / export / generation. Optional per-row copy button.
struct VariantPicker: View {
    let variants: [String]
    let selected: Int
    var monospaced: Bool = false
    var copyKind: String? = nil
    let onSelect: (Int) -> Void

    @EnvironmentObject var store: AppStore

    var body: some View {
        VStack(spacing: 6) {
            ForEach(Array(variants.enumerated()), id: \.offset) { idx, text in
                Row(index: idx, text: text, isSelected: idx == selected,
                    monospaced: monospaced, copyKind: copyKind,
                    onTap: { onSelect(idx) },
                    onCopy: { if let k = copyKind { store.copyToPasteboard(text, kind: k) } })
            }
        }
    }

    private struct Row: View {
        let index: Int
        let text: String
        let isSelected: Bool
        let monospaced: Bool
        let copyKind: String?
        let onTap: () -> Void
        let onCopy: () -> Void
        @State private var hover = false

        var body: some View {
            HStack(alignment: .top, spacing: 9) {
                // selection marker + variant number
                ZStack {
                    Circle().strokeBorder(isSelected ? Theme.accent : Theme.borderStrong, lineWidth: isSelected ? 5 : 1)
                        .frame(width: 16, height: 16)
                }
                .padding(.top, 1)

                Text(text)
                    .font(monospaced ? .system(size: 11.5, design: .monospaced) : .system(size: 12.5))
                    .foregroundStyle(Theme.ink).lineSpacing(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .fixedSize(horizontal: false, vertical: true)

                if copyKind != nil {
                    Button(action: onCopy) {
                        Glyph(name: "copy", size: 12, color: Theme.ink2)
                            .frame(width: 22, height: 22).background(Theme.surface)
                            .overlay(RoundedRectangle(cornerRadius: 6).strokeBorder(Theme.border, lineWidth: 0.5))
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                    }
                    .buttonStyle(.plain).opacity(hover ? 1 : 0)
                }
            }
            .overlay(alignment: .topLeading) {
                Text("\(index + 1)").font(.system(size: 8, weight: .bold)).foregroundStyle(isSelected ? Theme.accent : Theme.ink4)
                    .offset(x: 4.5, y: 4)
            }
            .padding(.horizontal, 10).padding(.vertical, 9)
            .background(isSelected ? Theme.accentSoft : Theme.surface2)
            .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl)
                .strokeBorder(isSelected ? Theme.accentLine : Theme.border, lineWidth: isSelected ? 1 : 0.5))
            .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
            .contentShape(Rectangle())
            .onTapGesture { onTap() }
            .onHover { hover = $0 }
        }
    }
}
