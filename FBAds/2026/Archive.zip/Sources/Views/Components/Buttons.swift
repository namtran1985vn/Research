import SwiftUI

enum BtnVariant { case primary, secondary, ghost, soft, danger }
enum BtnSize { case sm, md, lg }

/// Port of the prototype `Btn` — variants × sizes with hover lift.
struct AppButton: View {
    var title: String? = nil
    var icon: String? = nil
    var variant: BtnVariant = .secondary
    var size: BtnSize = .md
    var disabled: Bool = false
    var fullWidth: Bool = false
    let action: () -> Void

    @State private var hover = false

    private var height: CGFloat { size == .sm ? 26 : size == .md ? 31 : 40 }
    private var fontSize: CGFloat { size == .sm ? 12 : size == .md ? 13 : 14 }
    private var iconSize: CGFloat { size == .lg ? 17 : 15 }
    private var hPad: CGFloat {
        if icon != nil && title == nil { return size == .sm ? 5 : 7 }
        return size == .sm ? 10 : size == .lg ? 20 : 13
    }

    var body: some View {
        Button(action: { if !disabled { action() } }) {
            HStack(spacing: 6) {
                if let icon { Glyph(name: icon, size: iconSize, weight: .semibold) }
                if let title { Text(title).font(.system(size: fontSize, weight: .semibold)) }
            }
            .frame(maxWidth: fullWidth ? .infinity : nil)
            .frame(height: height)
            .padding(.horizontal, hPad)
            .foregroundStyle(fg)
            .background(bg)
            .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(borderColor, lineWidth: 0.5))
            .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
            .modifier(BtnShadow(variant: variant))
            .offset(y: liftOffset)
            .opacity(disabled ? 0.45 : 1)
        }
        .buttonStyle(.plain)
        .onHover { hover = $0 && !disabled }
        .animation(.easeOut(duration: 0.14), value: hover)
    }

    private var liftOffset: CGFloat {
        guard hover, variant == .secondary || variant == .soft || variant == .danger else { return 0 }
        return -0.5
    }

    @ViewBuilder private var bg: some View {
        switch variant {
        case .primary:   Theme.accentGradient.brightness(hover ? 0.05 : 0)
        case .secondary: (hover ? Theme.surface2 : Theme.surface)
        case .ghost:     (hover ? Theme.surface2 : Color.clear)
        case .soft:      Theme.accentSoft
        case .danger:    Theme.errBg
        }
    }

    private var fg: Color {
        switch variant {
        case .primary:   return Color(hex: 0xFBF7EE)
        case .secondary: return Theme.ink
        case .ghost:     return hover ? Theme.ink : Theme.ink2
        case .soft:      return Theme.accentInk
        case .danger:    return Theme.err
        }
    }

    private var borderColor: Color {
        switch variant {
        case .primary:   return Theme.accentDeep
        case .secondary: return Theme.borderStrong
        case .ghost:     return .clear
        case .soft:      return Theme.accentLine
        case .danger:    return Theme.errLine
        }
    }
}

private struct BtnShadow: ViewModifier {
    let variant: BtnVariant
    func body(content: Content) -> some View {
        switch variant {
        case .primary:
            content.shadow(color: Theme.accentDeep.opacity(0.35), radius: 1, x: 0, y: 1)
        case .secondary:
            content.cardShadow()
        default:
            content
        }
    }
}

/// A small square icon-only control button used in card action rows / toolbars.
struct IconControl: View {
    let icon: String
    var label: String = ""
    var tone: Color = Theme.ink2
    var active: Bool = false
    var fill: Bool = false
    var side: CGFloat = 28
    let action: () -> Void

    @State private var hover = false

    var body: some View {
        Button(action: action) {
            Glyph(name: icon, size: 15, weight: .medium,
                  color: active ? tone : (hover ? Theme.ink : tone), fill: fill && active)
                .frame(width: side, height: side)
                .background(active ? Theme.accentSoft : (hover ? Theme.surface2 : Color.clear))
                .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(active ? Theme.accentLine : .clear, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: 7))
        }
        .buttonStyle(.plain)
        .help(label)
        .onHover { hover = $0 }
    }
}
