import SwiftUI

/// Small label chip (audience, image-style, alternatives…).
struct Tag: View {
    let text: String
    var color: Color = Theme.ink2
    var bg: Color = Theme.surface2
    var line: Color = Theme.border
    var icon: String? = nil

    var body: some View {
        HStack(spacing: 4) {
            if let icon { Glyph(name: icon, size: 10, weight: .semibold, color: color) }
            Text(text).font(.system(size: 10.5, weight: .semibold)).tracking(0.2)
        }
        .foregroundStyle(color)
        .padding(.horizontal, 7).padding(.vertical, 2)
        .background(bg)
        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.chip).strokeBorder(line, lineWidth: 0.5))
        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.chip))
    }
}

struct AudienceTag: View {
    let audience: String
    var body: some View {
        Tag(text: "Set \(audience)",
            color: AudienceStyle.color(audience),
            bg: AudienceStyle.bg(audience),
            line: AudienceStyle.line(audience))
    }
}

/// The shared status chip for the 5 creative states.
struct StatusChip: View {
    let status: CreativeStatus
    var size: CGFloat = 10.5

    var body: some View {
        HStack(spacing: 5) {
            StatusDot(status: status)
            Text(status.label).font(.system(size: size, weight: .semibold)).tracking(0.1)
        }
        .foregroundStyle(status.color)
        .padding(.horizontal, 6).padding(.vertical, 2)
        .background(status.bg)
        .overlay(Capsule().strokeBorder(status.line, lineWidth: 0.5))
        .clipShape(Capsule())
        .fixedSize()
    }
}

struct StatusDot: View {
    let status: CreativeStatus
    @State private var pulse = false

    var body: some View {
        switch status {
        case .generating:
            Spinner(size: 11, lineWidth: 1.6, track: status.line, tint: status.color)
        case .queued:
            Circle().fill(status.color).frame(width: 7, height: 7)
                .opacity(pulse ? 0.45 : 1)
                .animation(.easeInOut(duration: 0.65).repeatForever(autoreverses: true), value: pulse)
                .onAppear { pulse = true }
        case .done:
            Glyph(name: "check", size: 11, weight: .bold, color: status.color)
        case .error:
            Glyph(name: "warn", size: 11, weight: .semibold, color: status.color)
        case .idle:
            Circle().fill(Theme.ink4).frame(width: 7, height: 7)
        }
    }
}
