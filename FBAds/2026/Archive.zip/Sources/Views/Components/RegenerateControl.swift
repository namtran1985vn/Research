import SwiftUI

/// A regenerate affordance for any AI-created content. Tapping opens a popover with an optional
/// free-text instruction ("make it punchier", "add urgency", "warmer lighting") and a Regenerate
/// button. The instruction is passed back to the caller, which calls the model.
struct RegenerateControl: View {
    var title: String = "Regenerate with AI"
    var placeholder: String = "Optional: tell the AI what to change…"
    /// Compact = small icon-only button (card/field rows). Otherwise a labelled button.
    var compact: Bool = true
    var label: String = "Regenerate"
    var icon: String = "refresh"
    var busy: Bool = false
    /// When labelled (non-compact), expand to fill the available width — for equal-column rows.
    var fullWidth: Bool = false
    /// Examples shown as quick-fill chips under the field.
    var suggestions: [String] = []
    let onRegenerate: (String) -> Void

    @State private var showPopover = false
    @State private var instruction = ""
    @State private var hover = false

    var body: some View {
        Button(action: { if !busy { showPopover = true } }) {
            if compact {
                Group {
                    if busy { Spinner(size: 13, lineWidth: 1.6, track: Theme.accentLine, tint: Theme.accent) }
                    else { Glyph(name: icon, size: 15, color: hover ? Theme.ink : Theme.ink2) }
                }
                .frame(width: 28, height: 28)
                .background(hover ? Theme.surface2 : Color.clear)
                .clipShape(RoundedRectangle(cornerRadius: 7))
            } else {
                HStack(spacing: 6) {
                    if busy { Spinner(size: 13, lineWidth: 1.6, track: Theme.accentLine, tint: Theme.accent) }
                    else { Glyph(name: icon, size: 14, color: Theme.ink2) }
                    Text(label).font(.system(size: 12, weight: .semibold)).foregroundStyle(Theme.ink2)
                }
                .padding(.horizontal, 11)
                .frame(maxWidth: fullWidth ? .infinity : nil).frame(height: 26)
                .background(Theme.surface)
                .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
            }
        }
        .buttonStyle(.plain)
        .help(label)
        .onHover { hover = $0 }
        .popover(isPresented: $showPopover, arrowEdge: .bottom) {
            popover
        }
    }

    private var popover: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 7) {
                Glyph(name: "sparkle", size: 14, color: Theme.accent)
                Text(title).font(.system(size: 13, weight: .bold))
            }
            ZStack(alignment: .topLeading) {
                if instruction.isEmpty {
                    Text(placeholder).font(.system(size: 12)).foregroundStyle(Theme.ink4)
                        .padding(.horizontal, 9).padding(.vertical, 8).allowsHitTesting(false)
                }
                TextEditor(text: $instruction)
                    .font(.system(size: 12)).scrollContentBackground(.hidden)
                    .frame(height: 64).padding(.horizontal, 5).padding(.vertical, 3)
            }
            .background(Theme.surface)
            .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
            .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))

            if !suggestions.isEmpty {
                FlexChips(items: suggestions) { instruction = $0 }
            }

            HStack {
                Text("Leave blank to just refresh.").font(.system(size: 10.5)).foregroundStyle(Theme.ink4)
                Spacer()
                AppButton(title: "Regenerate", icon: "sparkle", variant: .primary, size: .sm) {
                    onRegenerate(instruction); instruction = ""; showPopover = false
                }
            }
        }
        .padding(14)
        .frame(width: 300)
    }
}

/// Simple wrapping row of tappable suggestion chips.
struct FlexChips: View {
    let items: [String]
    let onTap: (String) -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(rows(), id: \.self) { row in
                HStack(spacing: 6) {
                    ForEach(row, id: \.self) { item in
                        Button(action: { onTap(item) }) {
                            Text(item).font(.system(size: 11, weight: .medium)).foregroundStyle(Theme.ink2)
                                .padding(.horizontal, 9).padding(.vertical, 4)
                                .background(Theme.surface2)
                                .overlay(Capsule().strokeBorder(Theme.border, lineWidth: 0.5))
                                .clipShape(Capsule())
                        }.buttonStyle(.plain)
                    }
                    Spacer(minLength: 0)
                }
            }
        }
    }
    /// Greedy 2-per-row layout (chips are short).
    private func rows() -> [[String]] {
        stride(from: 0, to: items.count, by: 2).map { Array(items[$0..<min($0 + 2, items.count)]) }
    }
}
