import SwiftUI

/// Maps the prototype's custom line-icon names to native SF Symbols so the app
/// reads as a real macOS citizen while preserving the design's iconography.
struct Glyph: View {
    let name: String
    var size: CGFloat = 16
    var weight: Font.Weight = .medium
    var color: Color? = nil
    var fill: Bool = false

    private static let map: [String: String] = [
        "plus": "plus", "minus": "minus",
        "bolt": "bolt.fill",
        "sparkle": "sparkles",
        "wand": "wand.and.stars",
        "export": "square.and.arrow.up",
        "download": "square.and.arrow.down",
        "settings": "gearshape",
        "search": "magnifyingglass",
        "image": "photo",
        "heart": "heart",
        "heart.fill": "heart.fill",
        "info": "info.circle",
        "copy": "doc.on.doc",
        "refresh": "arrow.clockwise",
        "close": "xmark",
        "check": "checkmark",
        "warn": "exclamationmark.triangle",
        "chevron": "chevron.right",
        "chevDown": "chevron.down",
        "user": "person.crop.circle",
        "layers": "square.stack.3d.up",
        "sliders": "slider.horizontal.3",
        "star": "star.fill",
        "dollar": "dollarsign",
        "text": "textformat",
        "grid": "square.grid.2x2",
        "upload": "arrow.up.doc",
        "trash": "trash",
        "rank": "chart.bar",
        "eye": "eye",
        "arrowRight": "arrow.right",
        "arrowLeft": "arrow.left",
        "drag": "line.3.horizontal",
        "folder": "folder",
        "pin": "pin.fill",
        "key": "key",
        "lock": "lock",
        "sidebar": "sidebar.left",
        "sidebarRight": "sidebar.right",
    ]

    var body: some View {
        let symbol = Glyph.map[name] ?? "questionmark"
        Image(systemName: fill ? (symbol.hasSuffix(".fill") ? symbol : symbol + ".fill") : symbol)
            .font(.system(size: size, weight: weight))
            .foregroundStyle(color ?? .primary)
    }
}

/// A continuously spinning ring — the shared "working" affordance.
struct Spinner: View {
    var size: CGFloat = 16
    var lineWidth: CGFloat = 1.7
    var track: Color = Theme.runLine
    var tint: Color = Theme.run
    @State private var spin = false

    var body: some View {
        Circle()
            .trim(from: 0, to: 0.72)
            .stroke(
                AngularGradient(colors: [track, tint], center: .center),
                style: StrokeStyle(lineWidth: lineWidth, lineCap: .round))
            .frame(width: size, height: size)
            .rotationEffect(.degrees(spin ? 360 : 0))
            .animation(.linear(duration: 0.8).repeatForever(autoreverses: false), value: spin)
            .onAppear { spin = true }
    }
}
