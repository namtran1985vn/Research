import SwiftUI
import UniformTypeIdentifiers

struct InspectorView: View {
    @EnvironmentObject var store: AppStore
    @State private var showEditor = false
    @State private var showAIEdit = false
    @State private var dropTarget = false
    /// The creative the inspector is CURRENTLY showing. It trails `store.selectedCreativeID` by one
    /// runloop tick: a click commits the selection highlight + grid in the first frame (instant feel),
    /// and the heavy inspector detail rebuilds in the NEXT frame instead of blocking that first one.
    /// During the (~1-frame) gap the previous detail stays on screen, so there's no blank/loader flash.
    @State private var shownCreativeID: UUID?

    var body: some View {
        Group {
            if let project = store.selectedProject,
               let id = shownCreativeID,
               let (persona, creative) = find(id, in: project) {
                detail(project: project, persona: persona, creative: creative)
            } else {
                placeholder
            }
        }
        .background(Theme.bgWindow)
        .onAppear { shownCreativeID = store.selectedCreativeID }
        .onChange(of: store.selectedCreativeID) { _, newID in
            // Optimistic UI: yield this frame to the selection effect, build the detail on the next.
            Task { @MainActor in shownCreativeID = newID }
        }
        .sheet(isPresented: $showEditor) {
            if let project = store.selectedProject, let persona = store.selectedPersona, let c = store.selectedCreative {
                TextOnImageEditor(creative: c, persona: persona, projectID: project.id)
            }
        }
        .sheet(isPresented: $showAIEdit) {
            if let project = store.selectedProject, let c = store.selectedCreative {
                AIEditSheet { prompt in
                    store.editImageWithAI(project: project.id, creative: c.id, prompt: prompt)
                }
            }
        }
    }

    /// Locate a creative (and its persona) by id within a project — cheap (a handful of personas).
    private func find(_ id: UUID, in project: Project) -> (Persona, Creative)? {
        for p in project.personas {
            if let c = p.creatives.first(where: { $0.id == id }) { return (p, c) }
        }
        return nil
    }

    private var placeholder: some View {
        VStack(spacing: 12) {
            Glyph(name: "eye", size: 22, color: Theme.ink3)
                .frame(width: 46, height: 46).background(Theme.surface2)
                .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(Theme.border, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            Text("Select a creative to inspect its render, copy, and image-prompt.")
                .font(.system(size: 13)).foregroundStyle(Theme.ink3).multilineTextAlignment(.center)
                .frame(maxWidth: 220)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity).padding(30)
    }

    private func detail(project: Project, persona: Persona, creative: Creative) -> some View {
        let done = creative.status == .done
        return VStack(spacing: 0) {
            // sticky header
            HStack(spacing: 8) {
                HStack(spacing: 4) {
                    Glyph(name: "star", size: 12, color: Theme.accent)
                    Text("#\(creative.rank) · \(creative.score)").font(.system(size: 12, weight: .bold)).foregroundStyle(Theme.accentInk)
                }
                Tag(text: ImageStyleMeta.label(creative.style), color: ImageStyleMeta.tone(creative.style))
                Spacer()
                if creative.imageFilename != nil {
                    AppButton(title: "Save", icon: "download", variant: .soft, size: .sm) {
                        store.quickSaveImage(project: project.id, creative: creative.id)
                    }
                    .help("Quick-save to \(store.settings.exportFolderDisplay)")
                }
            }
            .padding(.horizontal, 14).padding(.vertical, 11)
            .background(Theme.bgWindow)
            Divider().overlay(Theme.border)

            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    // render canvas
                    ZStack {
                        if done {
                            DraggableAdView(creative: creative, projectID: project.id)
                        } else if creative.status == .generating {
                            ZStack { Theme.surface2; VStack(spacing: 10) { Spinner(size: 26, lineWidth: 2.5); Text("Generating…").font(.system(size: 12, weight: .semibold)).foregroundStyle(Theme.run) } }
                        } else if creative.imageIsPlaceholder, creative.imageFilename != nil {
                            SampleGridEditor(creative: creative, projectID: project.id)
                        } else {
                            ZStack { Theme.surface2
                                VStack(spacing: 10) {
                                    Glyph(name: "image", size: 22, color: Theme.ink3)
                                    AppButton(title: "Generate image", icon: "sparkle", variant: .soft) { generate(project, persona, creative) }
                                    Text("or drag image(s) here · 4 → 2×2, 9 → 3×3").font(.system(size: 11)).foregroundStyle(Theme.ink4)
                                }
                            }
                        }
                    }
                    .aspectRatio(creative.ratio.value, contentMode: .fit)
                    .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.card))
                    .overlay {
                        if store.rebuildingGrids.contains(creative.id) {
                            ZStack { Color.black.opacity(0.18); Spinner(size: 22, lineWidth: 2) }
                                .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.card))
                                .transition(.opacity)
                        } else if store.isEditingImage(creative.id) {
                            ZStack {
                                Color.black.opacity(0.28)
                                VStack(spacing: 8) {
                                    Spinner(size: 22, lineWidth: 2)
                                    Text("AI editing…").font(.system(size: 11, weight: .semibold)).foregroundStyle(.white)
                                }
                            }
                            .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.card))
                            .transition(.opacity)
                        }
                    }
                    .animation(.easeOut(duration: 0.15), value: store.rebuildingGrids.contains(creative.id))
                    .animation(.easeOut(duration: 0.15), value: store.isEditingImage(creative.id))
                    .overlay(RoundedRectangle(cornerRadius: Theme.Radius.card)
                        .strokeBorder(dropTarget ? Theme.accent : Theme.border, lineWidth: dropTarget ? 1.5 : 0.5))
                    .onDrop(of: [.fileURL, .image], isTargeted: $dropTarget) { providers in
                        // Sample grids (split AND regular) fill cells via per-cell drops (see
                        // SampleGridEditor); a stray drop on the canvas must NOT replace the whole
                        // creative with one flat image. Only non-placeholder slots import a whole image.
                        if creative.imageIsPlaceholder { return false }
                        return importProviders(providers, project, persona, creative)
                    }
                    // Whole-image menu only for real images; the sample grid uses per-cell menus
                    // (see SampleGridEditor) so each child photo can be re-sampled individually.
                    .applyIf(!creative.imageIsPlaceholder) { view in
                        view.contextMenu {
                            if creative.imageFilename != nil {
                                Button { showAIEdit = true } label: { Label("Edit with AI…", systemImage: "wand.and.stars") }
                                Divider()
                            }
                            Button { generate(project, persona, creative) } label: { Label(done ? "Regenerate Image" : "Generate AI Image", systemImage: "sparkles") }
                            Button { pickAndImport(project, persona, creative) } label: { Label("Replace with My Own Image…", systemImage: "photo") }
                        }
                    }
                    .overlay(alignment: .bottomLeading) {
                        if done {
                            Text("Text layer editable · matches export")
                                .font(.system(size: 9.5, weight: .semibold)).foregroundStyle(Color(hex: 0xFBF7EE))
                                .padding(.horizontal, 7).padding(.vertical, 2)
                                .background(Color(hex: 0x211E18).opacity(0.55)).clipShape(Capsule())
                                .padding(8)
                        }
                    }
                    .cardShadow()
                    .padding(.bottom, 8)

                    HStack(spacing: 8) {
                        Text("RATIO").font(.system(size: 10.5, weight: .bold)).tracking(0.4).foregroundStyle(Theme.ink3)
                        SegmentedControl(selection: Binding(
                            get: { creative.ratio.rawValue },
                            set: { store.setRatio(project: project.id, creative: creative.id, ratio: AdRatio(rawValue: $0) ?? .r45) }),
                            options: ["4:5", "1:1"])
                        Spacer(minLength: 0)
                    }
                    .padding(.bottom, 8)

                    // Image ad TYPE — a dropdown below RATIO. `Grid` (default) drives the sample-grid
                    // layout picker below; `Before/After` switches to a 2-col Before|After pair grid.
                    HStack(spacing: 8) {
                        Text("TYPE").font(.system(size: 10.5, weight: .bold)).tracking(0.4).foregroundStyle(Theme.ink3)
                        Picker("", selection: Binding(
                            get: { creative.type },
                            set: { store.setAdType(project: project.id, creative: creative.id, type: $0) })) {
                            ForEach(AdType.allCases, id: \.self) { Text($0.label).tag($0) }
                        }.labelsHidden().frame(width: 160)
                        Spacer(minLength: 0)
                    }
                    .padding(.bottom, 8)

                    // Sample-grid layout — shown whenever the ad TYPE is Grid (1×1 … 3×3).
                    if creative.type == .grid {
                        HStack(spacing: 8) {
                            Text("GRID").font(.system(size: 10.5, weight: .bold)).tracking(0.4).foregroundStyle(Theme.ink3)
                            SegmentedControl(selection: Binding(
                                get: { "\(creative.sampleCols)×\(creative.sampleRows)" },
                                set: { sel in
                                    let d = sel.split(separator: "×").compactMap { Int($0) }
                                    if d.count == 2 { store.setSampleGrid(project: project.id, creative: creative.id, cols: d[0], rows: d[1]) }
                                }),
                                options: ["1×1", "2×2", "2×3", "2×4", "3×3"])
                            Spacer(minLength: 0)
                        }
                        .padding(.bottom, 12)
                    } else if creative.isSplit {
                        // Split (Before/After, Comparison or Problem/Solution): pick the row count
                        // (= pairs). Cols locked to 2. Comparison allows 1…4, Before/After 2…4,
                        // Problem/Solution 2…3.
                        let isCmp = creative.isComparison
                        let isPS = creative.isProblemSolution
                        let minRows = isCmp ? 1 : 2
                        let maxRows = isPS ? 3 : 4
                        let rowOptions = isCmp ? ["1", "2", "3", "4"] : (isPS ? ["2", "3"] : ["2", "3", "4"])
                        HStack(spacing: 8) {
                            Text(isCmp || isPS ? "ROWS" : "PAIRS").font(.system(size: 10.5, weight: .bold)).tracking(0.4).foregroundStyle(Theme.ink3)
                            SegmentedControl(selection: Binding(
                                get: { "\(max(minRows, min(maxRows, creative.sampleRows)))" },
                                set: { sel in if let r = Int(sel) { store.setSplitRows(project: project.id, creative: creative.id, rows: r) } }),
                                options: rowOptions)
                            Spacer(minLength: 0)
                        }
                        .padding(.bottom, 8)
                        // Editable column labels (rendered onto the image as text layers). Press Return to apply.
                        VStack(spacing: 6) {
                            SplitLabelField(title: "LEFT", initial: creative.splitLeftLabel) { left in
                                store.setSplitLabels(project: project.id, creative: creative.id,
                                                     left: left, right: creative.splitRightLabel)
                            }.id("\(creative.id)-left")
                            SplitLabelField(title: "RIGHT", initial: creative.splitRightLabel) { right in
                                store.setSplitLabels(project: project.id, creative: creative.id,
                                                     left: creative.splitLeftLabel, right: right)
                            }.id("\(creative.id)-right")
                        }
                        .padding(.bottom, 6)
                        Text(isCmp
                             ? "Left = the common market version, right = your premium product. Each row is one comparison. Drop a real photo into each cell — shoot both at the same angle and lighting; compare by type, never disparage a specific competitor."
                             : (isPS
                                ? "Right column = your real product photo (Solution), seeded at random. Left column = Problem: right-click a Solution cell → “Generate Problem scene (AI)…”, describe the pain, and the AI renders the same room without the product. Each row should show a different problem."
                                : "Left column = Before, right = After. Each row is one pair. Drop a real photo into each cell — shoot both at the same angle and lighting so they match."))
                            .font(.system(size: 10.5)).foregroundStyle(Theme.ink4).lineSpacing(2)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.bottom, 12)
                    } else if creative.isVariant {
                        // Variant: each cell is the same product with a different real pattern. The user
                        // picks the layout (rows × cols); per-cell "Vary" + pattern swap live in the
                        // cell right-click menu.
                        HStack(spacing: 8) {
                            Text("LAYOUT").font(.system(size: 10.5, weight: .bold)).tracking(0.4).foregroundStyle(Theme.ink3)
                            SegmentedControl(selection: Binding(
                                get: { "\(max(1, creative.sampleRows))×\(max(1, creative.sampleCols))" },
                                set: { sel in
                                    // "rows×cols" (the user's notation) → setVariantGrid(rows:cols:).
                                    let d = sel.split(separator: "×").compactMap { Int($0) }
                                    if d.count == 2 { store.setVariantGrid(project: project.id, creative: creative.id, rows: d[0], cols: d[1]) }
                                }),
                                options: ["3×1", "3×2", "2×2", "3×3"])
                            Spacer(minLength: 0)
                        }
                        .padding(.bottom, 8)
                        Text("Every cell is the same product with a different real pattern. Right-click a cell → “Vary” to re-render the other cells to match that cell's scene & angle, each keeping its own pattern. The anchor cell stays a real photo; use “Vary just this cell” to fix any that come out wrong, or “New pattern for this cell” to swap a cell's pattern.")
                            .font(.system(size: 10.5)).foregroundStyle(Theme.ink4).lineSpacing(2)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.bottom, 12)
                    }

                    if done {
                        // Edit text · Regenerate / Re-sample · Replace — uniform 2×2 grid of equal columns.
                        VStack(spacing: 6) {
                            HStack(spacing: 6) {
                                AppButton(title: "Edit text", icon: "text", variant: .secondary, size: .sm, fullWidth: true) { showEditor = true }
                                RegenerateControl(title: "Regenerate image", placeholder: "e.g. warmer lighting, different angle, more product focus…",
                                                  compact: false, label: "Regenerate", fullWidth: true,
                                                  suggestions: ["Warmer light", "Different angle", "More minimal", "Bolder colors"]) { instruction in
                                    store.regenerateImage(project: project.id, persona: persona.id, creative: creative.id, instruction: instruction)
                                }
                            }
                            HStack(spacing: 6) {
                                if !project.product.imageFilenames.isEmpty && creative.type == .grid {
                                    AppButton(title: "Re-sample", icon: "refresh", variant: .secondary, size: .sm, fullWidth: true) { store.reSample(project: project.id, creative: creative.id) }
                                }
                                AppButton(title: "Replace", icon: "upload", variant: .secondary, size: .sm, fullWidth: true) { pickAndImport(project, persona, creative) }
                            }
                        }.padding(.bottom, 14)
                    } else if creative.status != .generating {
                        // Edit text · Re-sample · Generate image — all on one line. (Import removed:
                        // drag image files onto the preview area above to import.)
                        HStack(spacing: 6) {
                            // Sample-grid placeholders carry text layers too — let the same editor
                            // tune the hook over the sample, exactly like a real AI image.
                            if creative.imageIsPlaceholder, creative.imageFilename != nil {
                                AppButton(title: "Edit text", icon: "text", variant: .secondary, size: .sm, fullWidth: true) { showEditor = true }
                            }
                            if !project.product.imageFilenames.isEmpty && creative.type == .grid {
                                AppButton(title: "Re-sample", icon: "refresh", variant: .secondary, size: .sm, fullWidth: true) { store.reSample(project: project.id, creative: creative.id) }
                            }
                            AppButton(title: "Generate image", icon: "sparkle", variant: .primary, size: .sm, fullWidth: true) { generate(project, persona, creative) }
                        }
                        .padding(.bottom, 14)
                    }

                    // why ranked
                    VStack(alignment: .leading, spacing: 5) {
                        HStack(spacing: 6) {
                            Glyph(name: "rank", size: 13, color: Theme.accent)
                            Text("WHY IT RANKED #\(creative.rank)").font(.system(size: 11, weight: .bold)).tracking(0.2).foregroundStyle(Theme.accentInk)
                        }
                        Text(creative.reasonTop).font(.system(size: 12)).foregroundStyle(Theme.accentInk).lineSpacing(2)
                    }
                    .padding(.horizontal, 12).padding(.vertical, 10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Theme.accentSoft)
                    .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.accentLine, lineWidth: 0.5))
                    .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
                    .padding(.bottom, 16)

                    // The creative's distinct selling insight — the thing diversity must live in.
                    if !creative.bigIdea.isEmpty {
                        InspectorField(label: "Big idea") {
                            Text(creative.bigIdea).font(.system(size: 13, weight: .semibold))
                                .foregroundStyle(Theme.ink).lineSpacing(2)
                        }
                    }
                    // Andromeda axis tags for this creative.
                    if !creative.emotionAxis.isEmpty || !creative.moment.isEmpty
                        || !creative.messageStrategy.isEmpty {
                        InspectorField(label: "Andromeda axes") {
                            HStack(spacing: 6) {
                                if !creative.emotionAxis.isEmpty { Tag(text: creative.emotionAxis, color: Theme.accent) }
                                if !creative.moment.isEmpty { Tag(text: creative.moment, color: Theme.ink2) }
                                if !creative.messageStrategy.isEmpty { Tag(text: creative.messageStrategy, color: Theme.ink3) }
                                Spacer(minLength: 0)
                            }
                        }
                    }
                    if !creative.valueSignal.isEmpty {
                        InspectorField(label: "Value signal (axis 5)") {
                            Text(creative.valueSignal).font(.system(size: 12.5))
                                .foregroundStyle(Theme.ink2).lineSpacing(2)
                        }
                    }
                    // Persona lens + coverage map.
                    if !persona.coreEmotion.isEmpty || !persona.selfImage.isEmpty
                        || !persona.psychLever.isEmpty || !persona.coverage.emotions.isEmpty
                        || !persona.coverage.moments.isEmpty {
                        CollapsibleField(label: "Persona lens · \(persona.name)") {
                            VStack(alignment: .leading, spacing: 4) {
                                if !persona.coreEmotion.isEmpty { lensRow("Core emotion", persona.coreEmotion) }
                                if !persona.selfImage.isEmpty { lensRow("Self-image", persona.selfImage) }
                                if !persona.psychLever.isEmpty { lensRow("Lever", persona.psychLever) }
                                if !persona.coverage.emotions.isEmpty { lensRow("Emotions", persona.coverage.emotions.joined(separator: " · ")) }
                                if !persona.coverage.moments.isEmpty { lensRow("Moments", persona.coverage.moments.joined(separator: " · ")) }
                            }
                        }
                    }
                    // Campaign setup guidance (axes 1 & 5).
                    if let sg = project.setupGuidance,
                       !(sg.pixelCapi.isEmpty && sg.valueRules.isEmpty && sg.lookalike.isEmpty && sg.targeting.isEmpty && sg.structure.isEmpty) {
                        CollapsibleField(label: "Campaign setup (axes 1 & 5)") {
                            VStack(alignment: .leading, spacing: 4) {
                                if !sg.pixelCapi.isEmpty { lensRow("Pixel/CAPI", sg.pixelCapi) }
                                if !sg.valueRules.isEmpty { lensRow("Value rules", sg.valueRules) }
                                if !sg.lookalike.isEmpty { lensRow("Lookalike", sg.lookalike) }
                                if !sg.targeting.isEmpty { lensRow("Targeting", sg.targeting) }
                                if !sg.structure.isEmpty { lensRow("Cấu trúc campaign", sg.structure) }
                            }
                        }
                    }
                    // Per-project memory — what the on-device AI remembers from your feedback & edits.
                    ProjectMemorySection(project: project)

                    InspectorField(label: "Hook · \(creative.hooks.count) options · tap to choose · tap again to remove",
                                   trailing: AnyView(
                        RegenerateControl(title: "Regenerate hook", busy: store.isRewriting(creative.id, .hook),
                                          suggestions: ["Shorter", "More punch", "Add curiosity", "Different angle"]) { instr in
                            store.regenerateCopy(project: project.id, creative: creative.id, field: .hook, instruction: instr)
                        })) {
                        VariantPicker(variants: creative.hooks, selected: creative.selHook, copyKind: "Hook") { idx in
                            store.selectVariant(project: project.id, creative: creative.id, field: .hook, index: idx)
                        }
                    }
                    InspectorField(label: "Concept") {
                        Text(creative.concept).font(.system(size: 12.5)).foregroundStyle(Theme.ink2).lineSpacing(2)
                    }
                    InspectorField(label: "Primary text · \(creative.primaryTexts.count) options · tap to choose",
                                   trailing: AnyView(
                        RegenerateControl(title: "Regenerate primary text", busy: store.isRewriting(creative.id, .primaryText),
                                          suggestions: ["Shorter & punchier", "Add urgency", "More emotional", "More specific"]) { instr in
                            store.regenerateCopy(project: project.id, creative: creative.id, field: .primaryText, instruction: instr)
                        })) {
                        VariantPicker(variants: creative.primaryTexts, selected: creative.selPrimaryText, copyKind: "Primary text") { idx in
                            store.selectVariant(project: project.id, creative: creative.id, field: .primaryText, index: idx)
                        }
                    }
                    InspectorField(label: "Headline · \(creative.headlines.count) options · CTA \(persona.copy.cta)",
                                   trailing: AnyView(
                        RegenerateControl(title: "Regenerate headline", busy: store.isRewriting(creative.id, .headline),
                                          suggestions: ["Shorter", "Bolder claim", "Add a number", "Curiosity angle"]) { instr in
                            store.regenerateCopy(project: project.id, creative: creative.id, field: .headline, instruction: instr)
                        })) {
                        VariantPicker(variants: creative.headlines, selected: creative.selHeadline, copyKind: "Headline") { idx in
                            store.selectVariant(project: project.id, creative: creative.id, field: .headline, index: idx)
                        }
                    }
                    InspectorField(label: "Image prompt · \(creative.imagePrompts.count) options · tap to choose",
                                   trailing: AnyView(
                        RegenerateControl(title: "Regenerate image prompts", busy: store.isRegeneratingImagePrompts(creative.id),
                                          suggestions: ["Different scene", "Lifestyle", "Studio", "Close-up"]) { instr in
                            store.regenerateImagePromptVariants(project: project.id, creative: creative.id, instruction: instr)
                        })) {
                        VStack(alignment: .leading, spacing: 8) {
                            VariantPicker(variants: creative.imagePrompts, selected: creative.selImagePrompt, monospaced: true) { idx in
                                store.selectImagePrompt(project: project.id, creative: creative.id, index: idx)
                            }
                            // Own draft state lives INSIDE this child, so typing re-renders only the
                            // editor — not the whole inspector (image preview, pickers). Keyed by
                            // creative.id so switching creatives reseeds the draft.
                            ImagePromptEditor(prompt: creative.imagePrompt,
                                              modelLabel: store.settings.imageBackend.label) { newPrompt in
                                store.updateImagePrompt(project: project.id, creative: creative.id, prompt: newPrompt)
                                generate(project, persona, creative)
                            }
                            .id(creative.id)
                        }
                    }
                }
                .padding(14)
            }
            .scrollIndicators(.automatic)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .overlay(alignment: .leading) { Rectangle().fill(Theme.borderStrong).frame(width: 0.5) }
    }

    @ViewBuilder private func lensRow(_ k: String, _ v: String) -> some View {
        HStack(alignment: .top, spacing: 6) {
            Text(k.uppercased()).font(.system(size: 9.5, weight: .bold)).tracking(0.3)
                .foregroundStyle(Theme.ink4).frame(width: 80, alignment: .leading)
            Text(v).font(.system(size: 11.5)).foregroundStyle(Theme.ink2).lineSpacing(2)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private func generate(_ p: Project, _ persona: Persona, _ c: Creative) {
        store.generateOne(project: p.id, persona: persona.id, creative: c.id)
    }

    /// Handle a drag-drop of one or more images onto the canvas. Multiple → auto grid.
    private func importProviders(_ providers: [NSItemProvider], _ p: Project, _ persona: Persona, _ c: Creative) -> Bool {
        ImageDrop.load(providers) { images in
            store.importImages(project: p.id, persona: persona.id, creative: c.id, images: images)
        }
        return true
    }

    private func pickAndImport(_ p: Project, _ persona: Persona, _ c: Creative) {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.png, .jpeg, .image]
        panel.allowsMultipleSelection = true
        if panel.runModal() == .OK {
            let images = panel.urls.compactMap { NSImage(contentsOf: $0) }
            store.importImages(project: p.id, persona: persona.id, creative: c.id, images: images)
        }
    }
}

/// Isolated editor for the selected image prompt. It owns its own `draft` state so a keystroke
/// re-renders ONLY this small view — not the parent inspector (with its heavy image preview and
/// variant pickers), which was the cause of the per-keystroke typing lag. The parent keys it by
/// `creative.id`, so switching creatives recreates it and reseeds the draft via `onAppear`; picking
/// a different prompt variant for the same creative reseeds via `onChange(of: prompt)`.
private struct ImagePromptEditor: View {
    let prompt: String
    let modelLabel: String
    let onApply: (String) -> Void
    @State private var draft: String = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("EDIT SELECTED").font(.system(size: 9.5, weight: .bold)).tracking(0.4).foregroundStyle(Theme.ink4)
                Spacer()
                Button(action: { onApply(draft) }) {
                    HStack(spacing: 3) { Glyph(name: "refresh", size: 11, color: Theme.accent); Text("Apply & regenerate").font(.system(size: 10.5, weight: .semibold)) }.foregroundStyle(Theme.accent)
                }.buttonStyle(.plain)
            }
            TextEditor(text: $draft)
                .font(.system(size: 11.5, design: .monospaced)).foregroundStyle(Theme.ink2)
                .scrollContentBackground(.hidden)
                .frame(height: 92)
                .padding(8)
                .background(Theme.surface)
                .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.border, lineWidth: 0.5))
                .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
            HStack(spacing: 4) {
                Glyph(name: "info", size: 11, color: Theme.ink4)
                Text("Using \(modelLabel)")
                    .font(.system(size: 10.5)).foregroundStyle(Theme.ink4)
            }
        }
        .onAppear { draft = prompt }
        .onChange(of: prompt) { _, new in draft = new }
    }
}

struct InspectorField<Content: View>: View {
    let label: String
    var trailing: AnyView? = nil
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(label.uppercased()).font(.system(size: 10.5, weight: .bold)).tracking(0.4).foregroundStyle(Theme.ink3)
                Spacer()
                if let trailing { trailing }
            }
            content
        }
        .padding(.bottom, 14)
    }
}

/// A field whose body is hidden behind a tap-to-expand header. Used for reference
/// Per-project memory panel: shows what the on-device AI remembers from the user's feedback and
/// edits for this campaign, and lets them read/curate it. The memory feeds future prompts.
private struct ProjectMemorySection: View {
    @EnvironmentObject var store: AppStore
    let project: Project

    var body: some View {
        CollapsibleField(label: "Bộ nhớ dự án · AI nhớ feedback của bạn") {
            VStack(alignment: .leading, spacing: 6) {
                Text(store.localMemoryAvailable
                     ? "Tự cập nhật & nén bằng AI trên máy (Apple Intelligence) — không tốn token online."
                     : "Apple Intelligence đang tắt — vẫn lưu các ghi chú gần nhất; bật trong System Settings để AI tự nén gọn.")
                    .font(.system(size: 10.5)).foregroundStyle(Theme.ink4).fixedSize(horizontal: false, vertical: true)
                ProjectMemoryEditor(text: project.memoryForPrompt, projectID: project.id)
                Text("Sửa tay nếu AI nhớ sai — văn bản bạn nhập sẽ thành bản chính.")
                    .font(.system(size: 10)).foregroundStyle(Theme.ink4)
            }
        }
    }
}

/// Commit-on-blur editor for project memory (mirrors `LearningsEditor` — a local draft so typing
/// re-renders only this view, not the whole inspector). Reseeds when switching to another project.
private struct ProjectMemoryEditor: View {
    let text: String
    let projectID: UUID
    @EnvironmentObject var store: AppStore
    @State private var draft = ""
    @FocusState private var focused: Bool

    var body: some View {
        TextEditor(text: $draft)
            .font(.system(size: 12)).foregroundStyle(Theme.ink2)
            .scrollContentBackground(.hidden)
            .frame(minHeight: 80)
            .padding(.horizontal, 7).padding(.vertical, 6)
            .background(Theme.surface)
            .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.borderStrong, lineWidth: 0.5))
            .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
            .focused($focused)
            .onAppear { draft = text }
            .onChange(of: projectID) { _, _ in draft = text }
            // Background distillation can update the memory while this is on screen; pull in the new
            // text unless the user is actively editing (so a stale draft can't overwrite it on blur).
            .onChange(of: text) { _, new in if !focused { draft = new } }
            .onChange(of: focused) { _, isFocused in if !isFocused { commit() } }
            .onDisappear { commit() }
    }

    private func commit() { if draft != text { store.setProjectMemory(project: projectID, text: draft) } }
}

/// info that repeats across every creative in a persona/campaign (persona lens,
/// campaign setup) — collapsed by default so it doesn't drown the per-creative copy.
struct CollapsibleField<Content: View>: View {
    let label: String
    @ViewBuilder let content: Content
    @State private var open = false

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Button(action: { withAnimation(.easeOut(duration: 0.15)) { open.toggle() } }) {
                HStack(spacing: 6) {
                    Glyph(name: open ? "chevDown" : "chevron", size: 10, weight: .bold, color: Theme.ink4)
                    Text(label.uppercased()).font(.system(size: 10.5, weight: .bold)).tracking(0.4).foregroundStyle(Theme.ink3)
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if open { content }
        }
        .padding(.bottom, 14)
    }
}

struct CopyLine: View {
    let text: String
    let kind: String
    var regenTitle: String = "Regenerate with AI"
    var suggestions: [String] = []
    var busy: Bool = false
    var onRegenerate: ((String) -> Void)? = nil
    @EnvironmentObject var store: AppStore
    @State private var hover = false

    var body: some View {
        HStack(alignment: .top, spacing: 6) {
            Text(text).font(.system(size: 12.5)).foregroundStyle(Theme.ink).lineSpacing(2)
                .frame(maxWidth: .infinity, alignment: .leading)
            VStack(spacing: 2) {
                Button(action: { store.copyToPasteboard(text, kind: kind) }) {
                    Glyph(name: "copy", size: 12, color: Theme.ink2)
                        .frame(width: 22, height: 22).background(Theme.surface)
                        .overlay(RoundedRectangle(cornerRadius: 6).strokeBorder(Theme.border, lineWidth: 0.5))
                        .clipShape(RoundedRectangle(cornerRadius: 6))
                }
                .buttonStyle(.plain).opacity(hover ? 1 : 0)
                if let onRegenerate {
                    RegenerateControl(title: regenTitle, placeholder: "Tell the AI what to change…",
                                      label: "Regenerate \(kind)", busy: busy,
                                      suggestions: suggestions, onRegenerate: onRegenerate)
                }
            }
        }
        .padding(.horizontal, 10).padding(.vertical, 9)
        .background(Theme.surface2)
        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.ctl).strokeBorder(Theme.border, lineWidth: 0.5))
        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.ctl))
        .onHover { hover = $0 }
    }
}

/// A single editable split-grid column label. Holds its own draft text (seeded from `initial`) and
/// commits on Return or when focus leaves the field, so the grid isn't re-rendered on every keystroke.
/// The parent forces a fresh instance per creative via `.id(...)`, so the draft tracks the selection.
private struct SplitLabelField: View {
    let title: String
    let initial: String
    let onCommit: (String) -> Void
    @State private var text: String = ""
    @FocusState private var focused: Bool

    var body: some View {
        HStack(spacing: 8) {
            Text(title).font(.system(size: 10.5, weight: .bold)).tracking(0.4)
                .foregroundStyle(Theme.ink3).frame(width: 42, alignment: .leading)
            TextField("Column label", text: $text)
                .textFieldStyle(.roundedBorder).font(.system(size: 12))
                .focused($focused)
                .onSubmit { onCommit(text) }
                .onChange(of: focused) { _, isFocused in if !isFocused { onCommit(text) } }
            Spacer(minLength: 0)
        }
        .onAppear { text = initial }
    }
}
