import SwiftUI

@main
struct AdCreativeStudioApp: App {
    @StateObject private var settings = AppSettings()
    @StateObject private var store: AppStore

    init() {
        FontRegistration.registerBundledFonts()
        let s = AppSettings()
        _settings = StateObject(wrappedValue: s)
        _store = StateObject(wrappedValue: AppStore(settings: s))
    }

    var body: some Scene {
        WindowGroup {
            // Whole-UI zoom: lay the UI out in a logical canvas of (window / uiScale), then scale it
            // back up to fill the window. Dividing the frame first is what makes the layout REFLOW
            // (grids re-column, text re-wraps) instead of just magnifying and clipping.
            GeometryReader { geo in
                let logical = CGSize(width: geo.size.width / store.uiScale,
                                     height: geo.size.height / store.uiScale)
                RootView()
                    .environmentObject(store)
                    .environmentObject(settings)
                    .frame(width: logical.width, height: logical.height, alignment: .topLeading)
                    .scaleEffect(store.uiScale, anchor: .topLeading)
                    .onAppear { store.canvasSize = logical }
                    .onChange(of: logical) { _, s in store.canvasSize = s }
            }
            .frame(minWidth: 760, minHeight: 560)
        }
        .windowStyle(.hiddenTitleBar)
        .defaultSize(width: 1320, height: 840)
        .commands { AppCommands(store: store) }
    }
}

/// Menu-bar commands + the power-user keyboard shortcuts from spec §H.
struct AppCommands: Commands {
    @ObservedObject var store: AppStore

    var body: some Commands {
        CommandGroup(replacing: .newItem) {
            Button("New Project") { store.startNewProject() }
                .keyboardShortcut("n", modifiers: .command)
        }
        CommandGroup(replacing: .appSettings) {
            Button("Settings…") { store.activeSheet = .settings }
                .keyboardShortcut(",", modifiers: .command)
        }
        CommandGroup(replacing: .sidebar) {
            Button(store.sidebarOpen ? "Hide Sidebar" : "Show Sidebar") { store.sidebarOpen.toggle() }
                .keyboardShortcut("s", modifiers: [.control, .command])
            Button(store.inspectorOpen ? "Hide Inspector" : "Show Inspector") { store.inspectorOpen.toggle() }
                .keyboardShortcut("i", modifiers: [.option, .command])
                .disabled(store.screen != .results)
            Divider()
            // Whole-UI zoom. Bind the physical "=" key so the natural "Cmd +" press (no Shift)
            // works; "+" (Shift+=) is added as a second equivalent so both ⌘= and ⌘+ zoom in.
            Button("Zoom In")  { store.zoomIn() }
                .keyboardShortcut("=", modifiers: .command)
                .disabled(store.uiScale >= store.uiScaleRange.upperBound)
            Button("Zoom In ") { store.zoomIn() }   // ⌘+ (Shift+=) equivalent; hidden duplicate label
                .keyboardShortcut("+", modifiers: .command)
                .disabled(store.uiScale >= store.uiScaleRange.upperBound)
            Button("Zoom Out") { store.zoomOut() }
                .keyboardShortcut("-", modifiers: .command)
                .disabled(store.uiScale <= store.uiScaleRange.lowerBound)
            Button("Actual Size") { store.resetZoom() }
                .keyboardShortcut("0", modifiers: .command)
                .disabled(store.uiScale == 1.0)
            Divider()
        }
        CommandMenu("Generate") {
            Button("Generate All Images") { store.generateAll() }
                .keyboardShortcut("g", modifiers: .command)
                .disabled(store.screen != .results)
            Button("Regenerate Selected") {
                if let p = store.selectedProject, let persona = store.selectedPersona, let c = store.selectedCreative {
                    store.generateOne(project: p.id, persona: persona.id, creative: c.id)
                }
            }
            .keyboardShortcut("r", modifiers: .command)
            .disabled(store.selectedCreative == nil)
            Divider()
            Button("Export…") { store.exportAll() }
                .keyboardShortcut("e", modifiers: .command)
                .disabled(store.screen != .results)
        }
    }
}
