import CoreText
import Foundation

/// Registers the fonts bundled under `Resources/Fonts` so the text-hook editor can
/// actually render them. Without this, `NSFont(name:)` / `.custom(...)` silently fall
/// back to the system font for any family not installed on the machine — which is why
/// switching between Montserrat / Poppins / Be Vietnam Pro looked like a no-op.
///
/// Scope is `.process`: the fonts become available to *this* app on every launch, no
/// system install and no sandbox permission prompts. (The app is sandboxed, so writing
/// into the real `~/Library/Fonts` is not possible anyway.) Registration is idempotent —
/// "already registered" is treated as success.
enum FontRegistration {
    static func registerBundledFonts() {
        let urls = bundledFontURLs()
        guard !urls.isEmpty else {
            assertionFailure("No bundled .ttf fonts found — check the Fonts resource is in the target.")
            return
        }
        for url in urls {
            var errorRef: Unmanaged<CFError>?
            let ok = CTFontManagerRegisterFontsForURL(url as CFURL, .process, &errorRef)
            if !ok, let error = errorRef?.takeRetainedValue() {
                let code = CFErrorGetCode(error)
                // kCTFontManagerErrorAlreadyRegistered (105) is fine — nothing to do.
                if code != 105 {
                    NSLog("[FontRegistration] Failed to register \(url.lastPathComponent): \(error)")
                }
            }
        }
    }

    private static func bundledFontURLs() -> [URL] {
        var found: [URL] = []
        // Fonts may land in a "Fonts" subdirectory or flattened at the resource root,
        // depending on how the build copies them — look in both.
        for subdir in ["Fonts", nil] as [String?] {
            if let urls = Bundle.main.urls(forResourcesWithExtension: "ttf", subdirectory: subdir) {
                found.append(contentsOf: urls)
            }
        }
        // De-duplicate by resolved path.
        var seen = Set<String>()
        return found.filter { seen.insert($0.standardizedFileURL.path).inserted }
    }
}
