import SwiftUI

/// Faithful port of `tokens.css` — the quiet-luxury, warm-paper macOS palette.
/// Single source of truth for color, radius, shadow, type scale, and spacing.
enum Theme {

    // MARK: Surfaces — warm paper neutrals
    static let bgDesktop  = Color(hex: 0xC9C2B4)
    static let bgWindow   = Color(hex: 0xFBFAF7)
    static let surface    = Color(hex: 0xFFFFFF)
    static let surface2   = Color(hex: 0xF6F3EC)
    static let surface3   = Color(hex: 0xEFEBE1)
    static let sidebar    = Color(hex: 0xECE8DF)
    static let sidebar2   = Color(hex: 0xE4DFD3)

    // MARK: Lines
    static let border       = Color(hex: 0xE6E0D4)
    static let borderStrong = Color(hex: 0xD6CEBE)
    static let hairline     = Color(red: 33/255, green: 30/255, blue: 24/255, opacity: 0.08)

    // MARK: Ink
    static let ink   = Color(hex: 0x211E18)
    static let ink2  = Color(hex: 0x6B655A)
    static let ink3  = Color(hex: 0x9C9588)
    static let ink4  = Color(hex: 0xBCB5A6)

    // MARK: Accent — bronze / champagne
    static let accent     = Color(hex: 0x9C7A47)
    static let accentDeep = Color(hex: 0x7C6038)
    static let accentInk  = Color(hex: 0x5E4824)
    static let accentSoft = Color(hex: 0xF1E9DA)
    static let accentLine = Color(hex: 0xE2D3B7)

    // MARK: Status — muted, never neon
    static let ok       = Color(hex: 0x4E7A5E); static let okBg    = Color(hex: 0xE8F0E9); static let okLine    = Color(hex: 0xCFE2D3)
    static let queue    = Color(hex: 0x9A7E3C); static let queueBg = Color(hex: 0xF4ECD8); static let queueLine = Color(hex: 0xE6D8B5)
    static let run      = Color(hex: 0x4A6BA0); static let runBg   = Color(hex: 0xE7EDF6); static let runLine   = Color(hex: 0xCFDAED)
    static let err      = Color(hex: 0xAC4A3C); static let errBg   = Color(hex: 0xF7E7E2); static let errLine   = Color(hex: 0xECCFC7)
    static let winner   = Color(hex: 0xB0603A)

    // MARK: Radii
    enum Radius {
        static let window: CGFloat = 12
        static let card: CGFloat   = 12
        static let ctl: CGFloat    = 8
        static let chip: CGFloat   = 6
        static let pill: CGFloat   = 999
    }

    // MARK: Type scale (pt)
    enum FontSize {
        static let display: CGFloat = 26
        static let title: CGFloat   = 19
        static let h: CGFloat       = 15
        static let body: CGFloat    = 13
        static let sm: CGFloat      = 12
        static let xs: CGFloat      = 11
        static let xxs: CGFloat     = 10
    }

    // MARK: Spacing step = 4
    enum Space {
        static let s1: CGFloat = 4
        static let s2: CGFloat = 8
        static let s3: CGFloat = 12
        static let s4: CGFloat = 16
        static let s5: CGFloat = 20
        static let s6: CGFloat = 24
        static let s7: CGFloat = 32
        static let s8: CGFloat = 40
    }

    // MARK: Accent gradient (primary buttons, rank #1)
    static let accentGradient = LinearGradient(
        colors: [Color(hex: 0xA98A57), Color(hex: 0x8C6C3D)],
        startPoint: .top, endPoint: .bottom)

    static let progressGradient = LinearGradient(
        colors: [Color(hex: 0xC9A86A), Color(hex: 0x9C7A47)],
        startPoint: .leading, endPoint: .trailing)
}

// MARK: - Audience (Set A / Set B) palette
enum AudienceStyle {
    static func color(_ a: String) -> Color { a == "A" ? Color(hex: 0x5E4A86) : Color(hex: 0x3E6B8C) }
    static func bg(_ a: String) -> Color    { a == "A" ? Color(hex: 0xEEE9F5) : Color(hex: 0xE6EFF4) }
    static func line(_ a: String) -> Color  { a == "A" ? Color(hex: 0xDBD0EC) : Color(hex: 0xCFE0EA) }
}

// MARK: - Image-style chip palette
enum ImageStyleMeta {
    /// (label, tone) keyed by the style slug used in creatives.
    static let table: [String: (label: String, tone: Color)] = [
        "beauty":      ("Beauty",      Color(hex: 0x9C7A47)),
        "ugc":         ("UGC",         Color(hex: 0x4A6BA0)),
        "testimonial": ("Testimonial", Color(hex: 0x4E7A5E)),
        "lifestyle":   ("Lifestyle",   Color(hex: 0x8A6BA0)),
        "studio":      ("Studio",      Color(hex: 0x6B655A)),
    ]
    static func label(_ slug: String) -> String { table[slug]?.label ?? slug.capitalized }
    static func tone(_ slug: String) -> Color { table[slug]?.tone ?? Theme.ink2 }
}

// MARK: - Readable text-on-image treatment
/// Picks a contrasting outline color so the hook reads on any background
/// (dark text → white halo, light text → near-black halo).
enum ReadableInk {
    static func isDark(_ hex: UInt) -> Bool {
        let r = Double((hex >> 16) & 0xFF), g = Double((hex >> 8) & 0xFF), b = Double(hex & 0xFF)
        return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.55
    }
    static func outlineHex(forText textHex: UInt) -> UInt { isDark(textHex) ? 0xFFFFFF : 0x1A1712 }
}

// MARK: - Color hex helper
extension Color {
    init(hex: UInt, alpha: Double = 1.0) {
        self.init(
            .sRGB,
            red:   Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue:  Double(hex & 0xFF) / 255,
            opacity: alpha)
    }
}

// MARK: - Reusable shadow / card decorations
extension View {
    /// `--sh-card`
    func cardShadow() -> some View {
        self.shadow(color: Color(red: 33/255, green: 30/255, blue: 24/255, opacity: 0.05), radius: 1, x: 0, y: 1)
    }
    /// `--sh-raise`
    func raiseShadow() -> some View {
        self.shadow(color: Color(red: 33/255, green: 30/255, blue: 24/255, opacity: 0.10), radius: 7, x: 0, y: 4)
    }
    /// `--sh-pop` (popovers / sheets)
    func popShadow() -> some View {
        self.shadow(color: Color(red: 33/255, green: 30/255, blue: 24/255, opacity: 0.18), radius: 17, x: 0, y: 10)
    }
    /// `--sh-window`
    func windowShadow() -> some View {
        self.shadow(color: .black.opacity(0.34), radius: 35, x: 0, y: 24)
            .shadow(color: .black.opacity(0.18), radius: 11, x: 0, y: 8)
    }
}
