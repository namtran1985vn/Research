import Foundation

/// Single-user convenience: you can hardcode your OpenAI API key here so you never have to paste it.
/// Leave it as "" to use the key entered in Settings (stored in the Keychain) instead.
///
/// ⚠️ If you hardcode a key, do NOT commit this file or share the build. It's fine for personal use.
enum Secrets {
    static let openAIKey = ""   // e.g. "sk-proj-..."
}
