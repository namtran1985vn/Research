import Foundation
import AppKit

/// Handles on-disk persistence: one folder per project under Application Support, holding
/// `project.json`, reference product photos, and generated PNGs.
struct ProjectStore {
    static let shared = ProjectStore()

    private let fm = FileManager.default

    var root: URL {
        let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
            .appendingPathComponent("AdCreativeStudio", isDirectory: true)
            .appendingPathComponent("Projects", isDirectory: true)
        try? fm.createDirectory(at: base, withIntermediateDirectories: true)
        return base
    }

    /// Pure path — no filesystem side effects. Safe to call on the main thread in hot paths.
    func projectDirURL(_ id: UUID) -> URL {
        fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
            .appendingPathComponent("AdCreativeStudio", isDirectory: true)
            .appendingPathComponent("Projects", isDirectory: true)
            .appendingPathComponent(id.uuidString, isDirectory: true)
    }

    @discardableResult
    func projectDir(_ id: UUID) -> URL {
        let dir = root.appendingPathComponent(id.uuidString, isDirectory: true)
        try? fm.createDirectory(at: dir.appendingPathComponent("references"), withIntermediateDirectories: true)
        try? fm.createDirectory(at: dir.appendingPathComponent("generated"), withIntermediateDirectories: true)
        return dir
    }

    // MARK: Load / save

    func loadAll() -> [Project] {
        guard let dirs = try? fm.contentsOfDirectory(at: root, includingPropertiesForKeys: nil) else { return [] }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        var projects: [Project] = []
        for dir in dirs where dir.hasDirectoryPath {
            let file = dir.appendingPathComponent("project.json")
            guard let data = try? Data(contentsOf: file),
                  var p = try? decoder.decode(Project.self, from: data) else { continue }
            // Reset transient in-flight states from a previous, interrupted session (durable queue).
            for pi in p.personas.indices {
                for ci in p.personas[pi].creatives.indices where p.personas[pi].creatives[ci].status.isInFlight {
                    p.personas[pi].creatives[ci].status = .idle
                }
            }
            // An analyze/regenerate interrupted by app-close must not leave the project stuck on the
            // "Analyzing…" screen — the old content is intact, so just clear the transient flag.
            p.isAnalyzing = false
            // Heal any drift between the ranking sheet's `picked` flags and the personas that
            // actually exist: the kept personas are the source of truth for what's selected.
            // (Older projects were saved trusting the model's raw `picked`, which could mark more
            // entries than personas it emitted — leaving the sheet showing extra "Selected" rows.)
            let keptKeys = Set(p.personas.map { StrategyResponse.nameKey($0.name) })
            for ri in p.ranking.indices {
                p.ranking[ri].picked = keptKeys.contains(StrategyResponse.nameKey(p.ranking[ri].name))
            }
            projects.append(p)
        }
        return projects.sorted {
            if $0.pinned != $1.pinned { return $0.pinned }   // pinned projects first
            return $0.updatedAt > $1.updatedAt
        }
    }

    /// Persist a project. Encoding + disk write happen OFF the main thread and rapid successive
    /// saves for the same project coalesce into one write (see `ProjectSaver`), so UI-driven
    /// mutations (drag, status flips, toggles) never block the main thread on I/O.
    func save(_ project: Project) {
        ProjectSaver.shared.schedule(project, dir: projectDirURL(project.id))
    }

    /// Flush all pending saves synchronously — call on app termination so nothing is lost.
    func flushPendingSaves() {
        ProjectSaver.shared.flushAll()
    }

    // MARK: Backup (one slot per project — the state just before the last regenerate)

    /// Snapshot a project's pre-regenerate state so a worse new result can be restored. One slot per
    /// project; a new regenerate overwrites it. Written synchronously (it's a rare, deliberate action).
    func backup(_ project: Project) {
        let encoder = JSONEncoder(); encoder.dateEncodingStrategy = .iso8601
        guard let data = try? encoder.encode(project) else { return }
        try? data.write(to: projectDir(project.id).appendingPathComponent("project.backup.json"))
    }

    func loadBackup(_ id: UUID) -> Project? {
        let url = projectDirURL(id).appendingPathComponent("project.backup.json")
        guard let data = try? Data(contentsOf: url) else { return nil }
        let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(Project.self, from: data)
    }

    func hasBackup(_ id: UUID) -> Bool {
        fm.fileExists(atPath: projectDirURL(id).appendingPathComponent("project.backup.json").path)
    }

    func delete(_ id: UUID) {
        // Drop any pending save and remove the folder ON the saver's serial queue, so deletion can
        // never race an in-flight background write (and the disk I/O stays off the main thread).
        ProjectSaver.shared.cancel(id)
        ProjectSaver.shared.removeProject(dir: projectDirURL(id))
    }

    // MARK: Images

    /// Persist a reference product photo (from drag-drop) and return its filename.
    func saveReferenceImage(_ data: Data, projectID: UUID, index: Int) -> String? {
        let name = "ref-\(index)-\(UUID().uuidString.prefix(6)).png"
        guard let png = NSImage(data: data)?.pngData() else { return nil }
        let dir = projectDirURL(projectID).appendingPathComponent("references")
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent(name)
        do { try png.write(to: url); return name } catch { return nil }
    }

    func referenceImageURL(_ filename: String, projectID: UUID) -> URL {
        projectDirURL(projectID).appendingPathComponent("references").appendingPathComponent(filename)
    }

    func referenceImageData(projectID: UUID, filenames: [String]) -> [Data] {
        filenames.compactMap { try? Data(contentsOf: referenceImageURL($0, projectID: projectID)) }
    }

    /// Persist a generated PNG and return its filename. The file is overwritten in place on
    /// regenerate/import, so we evict any stale cached decode for this path.
    func saveGeneratedImage(_ png: Data, projectID: UUID, creativeID: UUID) -> String {
        let name = "\(creativeID.uuidString).png"
        let dir = projectDirURL(projectID).appendingPathComponent("generated")
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent(name)
        try? png.write(to: url, options: .atomic)
        ImageStore.shared.evict(url)
        return name
    }

    func generatedImageURL(_ filename: String, projectID: UUID) -> URL {
        projectDirURL(projectID).appendingPathComponent("generated").appendingPathComponent(filename)
    }

    /// Synchronous, cache-backed load (used by render paths). Off-main callers should prefer
    /// `ImageStore.shared.load(_:)` directly.
    func loadNSImage(_ filename: String?, projectID: UUID) -> NSImage? {
        guard let filename else { return nil }
        return ImageStore.shared.image(at: generatedImageURL(filename, projectID: projectID))
    }
}

/// Serial, debounced, off-main persistence for projects. Many UI mutations can fire in a burst
/// (a drag, a batch of status flips); we keep only the latest snapshot per project and write it
/// once the burst settles, on a utility queue — never on the main thread.
final class ProjectSaver {
    static let shared = ProjectSaver()

    private let queue = DispatchQueue(label: "com.adstudio.projectsaver", qos: .utility)
    private let lock = NSLock()
    private var pending: [UUID: (project: Project, dir: URL)] = [:]
    private var scheduled: Set<UUID> = []
    private let debounce: TimeInterval = 0.25

    /// Stash the latest snapshot and schedule a flush if one isn't already pending for this id.
    func schedule(_ project: Project, dir: URL) {
        lock.lock()
        pending[project.id] = (project, dir)
        let alreadyScheduled = scheduled.contains(project.id)
        scheduled.insert(project.id)
        lock.unlock()
        guard !alreadyScheduled else { return }
        queue.asyncAfter(deadline: .now() + debounce) { [weak self] in self?.flush(project.id) }
    }

    /// Drop any pending save for a deleted project so it isn't recreated after removal.
    func cancel(_ id: UUID) {
        lock.lock(); pending[id] = nil; scheduled.remove(id); lock.unlock()
    }

    /// Remove a project folder on the serial queue — ordered after any in-flight write.
    func removeProject(dir: URL) {
        queue.async { try? FileManager.default.removeItem(at: dir) }
    }

    /// Synchronously write everything still pending (app is terminating).
    func flushAll() {
        lock.lock()
        let snapshots = Array(pending.values)
        pending.removeAll(); scheduled.removeAll()
        lock.unlock()
        for s in snapshots { Self.write(s.project, dir: s.dir) }
    }

    private func flush(_ id: UUID) {
        lock.lock()
        let snapshot = pending[id]
        pending[id] = nil
        scheduled.remove(id)
        lock.unlock()
        guard let snapshot else { return }
        Self.write(snapshot.project, dir: snapshot.dir)
    }

    private static func write(_ project: Project, dir: URL) {
        var p = project
        p.updatedAt = Date()
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.sortedKeys]
        guard let data = try? encoder.encode(p) else { return }
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        try? data.write(to: dir.appendingPathComponent("project.json"), options: .atomic)
    }
}

extension NSImage {
    func pngData() -> Data? {
        guard let tiff = tiffRepresentation, let rep = NSBitmapImageRep(data: tiff) else { return nil }
        return rep.representation(using: .png, properties: [:])
    }
}
