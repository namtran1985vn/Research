import SwiftUI
import AppKit

enum Screen { case input, results }

struct Toast: Identifiable, Equatable {
    let id = UUID()
    var message: String
    var isError: Bool = false
}

/// Central application state: projects, selection, the analyze (OpenAI GPT) flow, and the
/// generation engine wiring. Single source of truth for the whole UI.
@MainActor
final class AppStore: ObservableObject {
    @Published var projects: [Project] = []
    @Published var selectedProjectID: UUID?
    @Published var selectedPersonaID: UUID?
    @Published var selectedCreativeID: UUID?

    @Published var screen: Screen = .input
    @Published var inspectorOpen = true
    @Published var sidebarOpen = true

    /// Whole-UI zoom (Cmd+ / Cmd- / Cmd0). The root is laid out in a logical canvas of
    /// windowSize / uiScale and then scaled back up, so the layout REFLOWS (text & images grow AND
    /// grid columns / wrapping adapt) like browser zoom — not a dumb magnify that clips. Persisted.
    @Published var uiScale: Double = {
        min(1.6, max(0.8, UserDefaults.standard.object(forKey: "uiScale") as? Double ?? 1.0))
    }() {
        didSet { UserDefaults.standard.set(uiScale, forKey: "uiScale") }
    }
    let uiScaleRange: ClosedRange<Double> = 0.8...1.6

    /// Logical (post-zoom) size of the window's content canvas, i.e. device window size / uiScale.
    /// Sheets render inside the scaled coordinate space, so they cap their own width/height against
    /// this to stay within the window at any zoom level. Published from the root GeometryReader.
    @Published var canvasSize: CGSize = CGSize(width: 1320, height: 840)

    func zoomIn()    { setZoom(uiScale + 0.1) }
    func zoomOut()   { setZoom(uiScale - 0.1) }
    func resetZoom() { setZoom(1.0) }
    private func setZoom(_ v: Double) {
        let stepped = (v * 10).rounded() / 10   // avoid float drift (0.7999…)
        uiScale = min(uiScaleRange.upperBound, max(uiScaleRange.lowerBound, stepped))
    }
    @Published var analyzing = false
    @Published var toast: Toast?
    @Published var activeSheet: ActiveSheet?
    /// Copy fields currently being rewritten by the AI, keyed by "creativeID:field".
    @Published var rewriting = InFlightSet<String>()
    /// Ranking-entry IDs currently being generated into personas — tracked per-row so several
    /// adds can run concurrently in the background without locking the whole sheet.
    @Published var addingPersonaIDs = InFlightSet<UUID>()
    /// Project ID for which a brand-new custom persona (bottom control) is being generated, else nil.
    /// Tracked per-project so the loading placeholder row lands in the right campaign.
    @Published var addingCustomPersonaPID: UUID? = nil
    /// True while a brand-new custom persona is being generated (derived; drives the ranking sheet UI).
    var addingCustomPersona: Bool { addingCustomPersonaPID != nil }
    /// Creative IDs whose sample grid is being rebuilt right now (grid/ratio switch) — drives an
    /// instant spinner on the cell so a user click reacts immediately while the recompose runs.
    @Published var rebuildingGrids = InFlightSet<UUID>()
    /// Before/After cells currently running an AI "generate Before from After" job, keyed "cid:index".
    @Published var baGeneratingCells = InFlightSet<CellRef>()
    /// Grid/split cells currently running an AI "Edit with AI" job, keyed "cid:index" — drives the
    /// per-cell "AI editing…" spinner and blocks a second concurrent edit of the same cell.
    @Published var aiEditingCells = InFlightSet<CellRef>()
    /// Whole single images currently running an "Edit with AI" job — drives the inspector/card spinner.
    @Published var aiEditingImages = InFlightSet<UUID>()
    /// Variant-grid cells currently being re-rendered to match an anchor cell, keyed "cid:index" —
    /// drives the per-cell "Varying…" spinner and blocks a second concurrent vary of the same cell.
    @Published var varyingCells = InFlightSet<CellRef>()
    /// App-wide clipboard for a copied on-image object (text / arrow / stamp layer). Set by ⌘C on a
    /// selected layer, consumed by ⌘V — survives across creatives and editor surfaces, though paste
    /// always lands in whichever creative is currently being edited.
    @Published var layerClipboard: TextLayer?
    /// Persona IDs whose copy is being re-written by the AI (right-click → Re-generate) — drives the
    /// row spinner and blocks a second concurrent re-generate of the same persona.
    @Published var regeneratingPersonaIDs = InFlightSet<UUID>()
    /// Any persona generation in flight — drives the shared status line.
    var addingPersona: Bool { !addingPersonaIDs.isEmpty || addingCustomPersona }

    enum ActiveSheet: Identifiable {
        case settings, ranking, regenerateProject(UUID), duplicateProject(UUID)
        case regeneratePersona(project: UUID, persona: UUID)
        var id: String {
            switch self {
            case .settings: return "settings"
            case .ranking: return "ranking"
            case .regenerateProject(let id): return "regen-\(id.uuidString)"
            case .duplicateProject(let id): return "dup-\(id.uuidString)"
            case .regeneratePersona(_, let pid): return "regen-persona-\(pid.uuidString)"
            }
        }
    }

    let settings: AppSettings
    let engine = GenerationEngine()
    private let store = ProjectStore.shared
    private var toastTask: Task<Void, Never>?

    init(settings: AppSettings) {
        self.settings = settings
        self.projects = store.loadAll()
        if let first = projects.first {
            selectedProjectID = first.id
            selectedPersonaID = first.personas.first?.id
            selectedCreativeID = first.personas.first?.creatives.first?.id
            screen = .results
        }
        wireEngine()
        // Saves are debounced off the main thread — flush anything pending before the app exits.
        NotificationCenter.default.addObserver(forName: NSApplication.willTerminateNotification,
                                               object: nil, queue: nil) { _ in
            ProjectStore.shared.flushPendingSaves()
        }
    }

    // MARK: Selection accessors

    var selectedProject: Project? {
        get { projects.first { $0.id == selectedProjectID } }
    }
    var selectedPersona: Persona? {
        selectedProject?.personas.first { $0.id == selectedPersonaID }
            ?? selectedProject?.personas.first
    }
    var selectedCreative: Creative? {
        selectedPersona?.creatives.first { $0.id == selectedCreativeID }
    }

    func projectIndex(_ id: UUID) -> Int? { projects.firstIndex { $0.id == id } }

    // MARK: - Per-project memory

    /// Projects currently being distilled on-device — prevents overlapping compaction runs.
    private var compactingMemory: Set<UUID> = []

    /// Whether on-device (Apple Intelligence) memory distillation can run right now.
    /// CACHED on first read: the live FoundationModels check (`SystemLanguageModel.default.availability`)
    /// costs ~2–15ms and was being called from a SwiftUI body on every Inspector render, stalling the
    /// main thread on each project/persona/creative click. Availability only changes when the user
    /// toggles Apple Intelligence in System Settings — call `refreshLocalMemoryAvailability()` then.
    private lazy var _localMemoryAvailable: Bool = LocalMemory.isAvailable
    var localMemoryAvailable: Bool { _localMemoryAvailable }
    func refreshLocalMemoryAvailability() { _localMemoryAvailable = LocalMemory.isAvailable }

    /// The memory text to inject into THIS project's online prompts (distilled + pending notes).
    private func memoryForPrompt(_ pid: UUID) -> String {
        projects.first { $0.id == pid }?.memoryForPrompt ?? ""
    }

    /// Capture a durable note (feedback / instruction / manual edit) into the project's memory buffer,
    /// then distill on-device once it grows. Cheap and synchronous; distillation runs off the hot path.
    func recordMemory(project pid: UUID, note: String) {
        let n = note.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !n.isEmpty, let idx = projectIndex(pid) else { return }
        let capped = String(n.prefix(220))
        if projects[idx].memoryRaw.last == capped { return }   // skip immediate duplicate
        projects[idx].memoryRaw.append(capped)
        projects[idx].updatedAt = Date()
        store.save(projects[idx])
        compactMemoryIfNeeded(pid)
    }

    /// The user hand-edited the memory (Inspector). The typed text becomes the source of truth.
    func setProjectMemory(project pid: UUID, text: String) {
        guard let idx = projectIndex(pid) else { return }
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard t != projects[idx].memory || !projects[idx].memoryRaw.isEmpty else { return }
        projects[idx].memory = t
        projects[idx].memoryRaw = []
        projects[idx].updatedAt = Date()
        store.save(projects[idx])
    }

    /// Distill memory on-device when the buffer grows past the threshold. Falls back to a trimmed,
    /// deduped tail when Apple Intelligence is unavailable. Never blocks the UI.
    private func compactMemoryIfNeeded(_ pid: UUID) {
        guard let idx = projectIndex(pid) else { return }
        let combinedLen = projects[idx].memory.count + projects[idx].memoryRaw.reduce(0) { $0 + $1.count }
        guard combinedLen > LocalMemory.compactThreshold, !compactingMemory.contains(pid) else { return }
        compactingMemory.insert(pid)
        let existing = projects[idx].memory
        let notes = projects[idx].memoryRaw
        let language = projects[idx].product.contentLanguage
        Task { [weak self] in
            guard let self else { return }
            let distilled = await LocalMemory.distill(existing: existing, notes: notes, language: language)
            defer { self.compactingMemory.remove(pid) }
            guard let i = self.projectIndex(pid) else { return }
            self.projects[i].memory = distilled ?? Self.foldMemoryFallback(existing: existing, notes: notes)
            // Drop only the notes we folded in; anything captured during distillation stays pending.
            if self.projects[i].memoryRaw.count >= notes.count {
                self.projects[i].memoryRaw.removeFirst(notes.count)
            } else {
                self.projects[i].memoryRaw.removeAll()
            }
            self.store.save(self.projects[i])
        }
    }

    /// No-AI fallback: merge distilled memory + notes into a deduped, length-capped bullet list,
    /// keeping the most recent items. Used when on-device distillation is unavailable.
    private static func foldMemoryFallback(existing: String, notes: [String]) -> String {
        var lines = existing.split(separator: "\n", omittingEmptySubsequences: true).map { String($0) }
        lines += notes.map { $0.hasPrefix("- ") ? $0 : "- \($0)" }
        var seen = Set<String>(); var deduped: [String] = []
        for l in lines.reversed() where seen.insert(l.lowercased()).inserted { deduped.append(l) }
        deduped.reverse()
        var out = deduped.suffix(16).joined(separator: "\n")
        if out.count > LocalMemory.targetChars + 300 { out = String(out.suffix(LocalMemory.targetChars + 300)) }
        return out
    }

    // MARK: Toast

    func showToast(_ message: String, isError: Bool = false) {
        toast = Toast(message: message, isError: isError)
        toastTask?.cancel()
        toastTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 2_800_000_000)
            if !Task.isCancelled { self?.toast = nil }
        }
    }

    // MARK: New project

    func startNewProject() { screen = .input }

    // MARK: Analyze (S1 → S2) — real OpenAI GPT call

    /// Create the project IMMEDIATELY (loading state) and switch to results, then do the GPT call
    /// and sample-grid building in the background — keeping the UI fully responsive.
    func analyze(product: Product, referenceImages: [Data], n: Int, m: Int) {
        guard settings.hasOpenAIKey else {
            showToast("Add your OpenAI API key in Settings (⌘,) first.", isError: true)
            return
        }
        settings.contentLanguage = product.contentLanguage   // remember as default for next project

        var pending = Project(name: campaignName(for: product), product: product,
                              personaCount: n, creativesPerPersona: m,
                              offer: .empty, ranking: [], personas: [])
        pending.isAnalyzing = true
        projects.insert(pending, at: 0)
        selectedProjectID = pending.id
        selectedPersonaID = nil
        selectedCreativeID = nil
        screen = .results
        analyzing = false

        runStrategy(projectID: pending.id, product: product, referenceImages: referenceImages, n: n, m: m)
    }

    func retryAnalyze(project pid: UUID) {
        guard let p = projects.first(where: { $0.id == pid }) else { return }
        let refs = store.referenceImageData(projectID: pid, filenames: p.product.imageFilenames)
        if let idx = projectIndex(pid) { projects[idx].isAnalyzing = true; projects[idx].analyzeFailed = false }
        runStrategy(projectID: pid, product: p.product, referenceImages: refs,
                    n: p.personaCount, m: p.creativesPerPersona)
    }

    private func campaignName(for product: Product) -> String {
        product.name.isEmpty ? "New campaign" : "\(product.name) — Campaign"
    }

    /// Duplicate a project into a NEW one (copying kept photos), then generate its strategy.
    func duplicateAndGenerate(from sourcePID: UUID, product baseProduct: Product, feedback: String,
                              n: Int, m: Int, keepFilenames: [String], newImages: [Data]) {
        guard settings.hasOpenAIKey else {
            showToast("Add your OpenAI API key in Settings (⌘,) first.", isError: true); return
        }
        settings.contentLanguage = baseProduct.contentLanguage

        var project = Project(name: "\(campaignName(for: baseProduct)) (copy)", product: baseProduct,
                              personaCount: n, creativesPerPersona: m,
                              offer: .empty, ranking: [], personas: [])
        project.isAnalyzing = true

        // Copy kept reference photos from the source project into the new one, then add new ones.
        var names: [String] = []
        for fn in keepFilenames {
            if let data = try? Data(contentsOf: store.referenceImageURL(fn, projectID: sourcePID)),
               let nm = store.saveReferenceImage(data, projectID: project.id, index: names.count) { names.append(nm) }
        }
        for (i, data) in newImages.enumerated() {
            if let nm = store.saveReferenceImage(data, projectID: project.id, index: 9000 + i) { names.append(nm) }
        }
        project.product.imageFilenames = names

        projects.insert(project, at: 0)
        selectedProjectID = project.id; selectedPersonaID = nil; selectedCreativeID = nil
        screen = .results; activeSheet = nil
        store.save(project)

        let refs = store.referenceImageData(projectID: project.id, filenames: names)
        runStrategy(projectID: project.id, product: project.product, referenceImages: refs, n: n, m: m, feedback: feedback)
    }

    /// Reference photos with their filenames (for the regenerate dialog's editable thumbnails).
    func referenceItems(projectID pid: UUID) -> [(filename: String, image: NSImage)] {
        guard let p = projects.first(where: { $0.id == pid }) else { return [] }
        return p.product.imageFilenames.compactMap { fn in
            guard let data = try? Data(contentsOf: store.referenceImageURL(fn, projectID: pid)),
                  let img = NSImage(data: data) else { return nil }
            return (fn, img)
        }
    }

    /// Fully redo an existing project's strategy. `keepFilenames` are existing photos to retain,
    /// `newImages` are newly added photos to persist; together they become the new reference set.
    func regenerateProject(project pid: UUID, product baseProduct: Product, feedback: String,
                           n: Int, m: Int, keepFilenames: [String], newImages: [Data]) {
        guard settings.hasOpenAIKey else {
            showToast("Add your OpenAI API key in Settings (⌘,) first.", isError: true); return
        }
        guard let idx = projectIndex(pid) else { return }
        settings.contentLanguage = baseProduct.contentLanguage

        var names = keepFilenames
        for (i, data) in newImages.enumerated() {
            if let nm = store.saveReferenceImage(data, projectID: pid, index: 9000 + i) { names.append(nm) }
        }
        var product = baseProduct
        product.imageFilenames = names

        projects[idx].product = product
        projects[idx].personaCount = n
        projects[idx].creativesPerPersona = m
        // Do NOT wipe personas / ranking / offer here. Keep the existing content as a live backup
        // until the new strategy actually succeeds — runStrategy swaps the whole project atomically
        // on success (and never persists this in-between state). So if the app is closed or the
        // generation fails mid-regenerate, the old content survives instead of being lost. The
        // `isAnalyzing` flag shows the AnalyzingView meanwhile, hiding the still-intact old data.
        projects[idx].isAnalyzing = true
        projects[idx].analyzeFailed = false
        projects[idx].analyzeErrorMessage = nil
        selectedProjectID = pid; selectedPersonaID = nil; selectedCreativeID = nil
        screen = .results
        activeSheet = nil
        let refs = store.referenceImageData(projectID: pid, filenames: product.imageFilenames)
        runStrategy(projectID: pid, product: product, referenceImages: refs, n: n, m: m, feedback: feedback)
    }

    /// True when a pre-regenerate backup exists for this project (drives the menu item's visibility).
    func hasBackup(project pid: UUID) -> Bool { store.hasBackup(pid) }

    /// Restore the project to the version saved just before the last successful regenerate.
    func restoreBackup(project pid: UUID) {
        guard let backup = store.loadBackup(pid), let idx = projectIndex(pid) else {
            showToast("No previous version to restore.", isError: true); return
        }
        var restored = backup
        restored.isAnalyzing = false
        restored.analyzeFailed = false
        projects[idx] = restored
        if selectedProjectID == pid {
            selectedPersonaID = restored.personas.first?.id
            selectedCreativeID = restored.personas.first?.creatives.first?.id
        }
        store.save(restored)
        showToast("Restored the version from before the last regenerate.")
    }

    /// Reference photos as NSImages (for the regenerate dialog thumbnails).
    func referenceImages(projectID pid: UUID) -> [NSImage] {
        guard let p = projects.first(where: { $0.id == pid }) else { return [] }
        return store.referenceImageData(projectID: pid, filenames: p.product.imageFilenames).compactMap { NSImage(data: $0) }
    }

    /// Build a strategy client wired to the current settings — one place instead of six identical
    /// construction sites. `language` is the project's content language; `projectMemory` its distilled
    /// per-campaign memory.
    private func makeStrategyClient(language: String, projectMemory: String) -> OpenAIStrategyClient {
        OpenAIStrategyClient(apiKey: settings.effectiveOpenAIKey, model: settings.gptModel,
                             language: language, learnings: settings.adLearnings, projectMemory: projectMemory)
    }

    private func runStrategy(projectID pid: UUID, product: Product, referenceImages: [Data], n: Int, m: Int, feedback: String = "") {
        // A re-generate with feedback is a durable instruction for this campaign — remember it.
        if !feedback.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            recordMemory(project: pid, note: "Campaign feedback: \(feedback)")
        }
        let client = makeStrategyClient(language: product.contentLanguage, projectMemory: memoryForPrompt(pid))
        Task { [weak self] in
            guard let self else { return }
            do {
                // Persist reference photos once (skip on retry — already linked).
                var names = self.projects.first(where: { $0.id == pid })?.product.imageFilenames ?? []
                if names.isEmpty {
                    for (i, data) in referenceImages.enumerated() {
                        if let name = self.store.saveReferenceImage(data, projectID: pid, index: i) { names.append(name) }
                    }
                    if let idx = self.projectIndex(pid) { self.projects[idx].product.imageFilenames = names }
                }

                // Send only a random 1–3 of the uploaded photos to the initial strategy prompt
                // (all photos are still saved and used for sample grids + image generation).
                let promptRefs = Array(referenceImages.shuffled().prefix(min(referenceImages.count, Int.random(in: 1...3))))
                let response = try await client.generateStrategy(
                    product: product, referenceImages: promptRefs, n: n, m: m, feedback: feedback)

                var built = response.makeProject(campaignName: self.campaignName(for: product), product: product, n: n, m: m, ratio: self.settings.defaultRatio)
                built.id = pid
                built.product.imageFilenames = names
                built.isAnalyzing = false
                // Back up the version being replaced (regenerate only — new projects have no prior
                // content) so the user can restore it if the new result turns out worse.
                if let old = self.projects.first(where: { $0.id == pid }), !old.personas.isEmpty {
                    self.store.backup(old)
                }
                if let idx = self.projectIndex(pid) { self.projects[idx] = built } else { self.projects.insert(built, at: 0) }
                if self.selectedProjectID == pid {
                    self.selectedPersonaID = built.personas.first?.id
                    self.selectedCreativeID = built.personas.first?.creatives.first?.id
                }
                self.store.save(built)

                // Build the default 3×3 sample grids OFF the main thread (decode + compose are heavy).
                if !names.isEmpty {
                    for persona in built.personas {
                        for c in persona.creatives {
                            await self.buildSampleGrid(pid: pid, cid: c.id, ratioSize: c.ratio.size, filenames: names, guarded: true)
                        }
                    }
                }

                // The strategy can return a contract-violating persona (no creatives, or no name);
                // makeProject drops those, so we may now have fewer than n. Backfill the shortfall with
                // the single-persona endpoint — a small, reliable call — so a campaign always ends with
                // n well-formed personas and never an empty one.
                await self.backfillPersonas(pid: pid, upTo: n, product: product, m: m, filenames: names)

                let finalCount = self.projects.first(where: { $0.id == pid })?.personas.count ?? built.personas.count
                self.showToast("Strategy ready · \(finalCount) personas · \(finalCount * m) creatives")
            } catch {
                let msg = (error as? APIError)?.errorDescription ?? error.localizedDescription
                if let idx = self.projectIndex(pid) {
                    self.projects[idx].isAnalyzing = false
                    self.projects[idx].analyzeFailed = true
                    self.projects[idx].analyzeErrorMessage = msg
                }
                self.showToast(msg, isError: true)
            }
        }
    }

    private var ensuringGrid: Set<UUID> = []

    /// Lazily build the default 3×3 sample grid for a creative that somehow has no image yet
    /// (e.g. the batch build missed it). Safe to call repeatedly; dedups in-flight work.
    func ensureSampleGrid(project pid: UUID, creative cid: UUID) {
        guard let c = creative(cid, in: pid), c.imageFilename == nil, c.status == .idle,
              !ensuringGrid.contains(cid),
              let project = projects.first(where: { $0.id == pid }),
              !project.product.imageFilenames.isEmpty else { return }
        let filenames = project.product.imageFilenames
        let ratioSize = c.ratio.size
        Task { [weak self] in
            // In-flight dedup is handled inside buildSampleGrid (guarded re-checks the slot is empty).
            await self?.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize, filenames: filenames, guarded: true)
        }
    }

    /// Random indices into a list of `items` reference photos — distinct when possible, sampling
    /// with replacement otherwise. Returning indices lets callers record which reference filenames
    /// (and in what order) went into the grid, so save can recompose it at full resolution.
    nonisolated static func randomPickIndices(count items: Int, pick count: Int) -> [Int] {
        guard items > 0 else { return [] }
        if items >= count { return Array((0..<items).shuffled().prefix(count)) }
        return (0..<count).map { _ in Int.random(in: 0..<items) }
    }

    /// Compose + persist a `cols`×`rows` sample grid (e.g. 2×2, 2×3, 3×3) for one creative from the
    /// project's reference photos, recording which filenames (in grid order) were used so save can
    /// recompose at full resolution. `guarded` re-checks the creative is still an empty idle slot
    /// before writing (used by the lazy builder, where an AI image may have arrived meanwhile).
    private func buildSampleGrid(pid: UUID, cid: UUID, ratioSize: CGSize, filenames: [String],
                                 cols: Int = 3, rows: Int = 3, reuseRefs: [String]? = nil,
                                 offsets: [CGPoint]? = nil, guarded: Bool = false) async {
        // Single in-flight build per creative — prevents the batch builder and the lazy
        // `ensureSampleGrid` from each writing a *different* random pick and leaving the list card and
        // the inspector out of sync.
        if ensuringGrid.contains(cid) { return }
        ensuringGrid.insert(cid)
        defer { ensuringGrid.remove(cid) }
        let cells = cols * rows
        // `reuseRefs` (set on a ratio re-crop) keeps the SAME photos in the SAME order so toggling
        // 4:5 ↔ 1:1 only re-crops; otherwise pick fresh random photos.
        let sourceNames = reuseRefs.map { Array($0.prefix(cells)) } ?? filenames
        // Load each file individually so name↔data stays aligned even if some are unreadable.
        let named: [(name: String, data: Data)] = sourceNames.compactMap { fn in
            store.referenceImageData(projectID: pid, filenames: [fn]).first.map { (fn, $0) }
        }
        guard !named.isEmpty else { return }
        let rs = GridComposer.highResSize(ratioSize)
        let keepOrder = reuseRefs != nil
        let result: (png: Data, names: [String])? = await Task.detached {
            let pairs: [(name: String, img: NSImage)] = named.compactMap { nd in
                NSImage(data: nd.data).map { (nd.name, $0) }
            }
            guard !pairs.isEmpty else { return nil }
            // Reuse → keep exact order; otherwise random pick.
            let idx = keepOrder ? Array(0..<pairs.count) : AppStore.randomPickIndices(count: pairs.count, pick: cells)
            let pickedNames = idx.map { pairs[$0].name }
            let pickedImgs  = idx.map { pairs[$0].img as NSImage? }
            guard let png = (GridComposer.compose(pickedImgs, size: rs, cols: cols, rows: rows, offsets: offsets)
                             ?? GridComposer.compose([pairs[0].img as NSImage?], size: rs, cols: cols, rows: rows, offsets: offsets))?.pngData()
            else { return nil }
            return (png, pickedNames)
        }.value
        guard let result else { return }
        if guarded {
            guard let cur = self.creative(cid, in: pid), cur.imageFilename == nil, cur.status == .idle else { return }
        }
        let name = self.store.saveGeneratedImage(result.png, projectID: pid, creativeID: cid)
        self.mutateCreative(project: pid, creative: cid) {
            $0.imageFilename = name; $0.imageIsPlaceholder = true
            $0.sampleRefs = result.names; $0.sampleCols = cols; $0.sampleRows = rows
            $0.sampleOffsets = offsets ?? []   // fresh build → centered; reuse/pan → keep the panned offsets
            $0.imageVersion += 1   // force every view keyed on imageToken to reload the rewritten file
        }
    }

    /// Re-roll the sample grid: pick fresh random photos from the project's original input images,
    /// recompose at the creative's current cols×rows, and replace its image (turning it back into a
    /// sample placeholder, even if it currently holds an AI/imported image).
    func reSample(project pid: UUID, creative cid: UUID) {
        guard let c = creative(cid, in: pid),
              let project = projects.first(where: { $0.id == pid }) else { return }
        let filenames = project.product.imageFilenames
        guard !filenames.isEmpty else {
            showToast("No input images to sample from.", isError: true); return
        }
        let cols = max(1, c.sampleCols), rows = max(1, c.sampleRows)
        let ratioSize = c.ratio.size
        rebuildingGrids.insert(cid)   // instant feedback while the recompose runs
        Task { [weak self] in
            // No reuseRefs → buildSampleGrid picks a fresh random set each call.
            await self?.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize, filenames: filenames, cols: cols, rows: rows)
            self?.rebuildingGrids.remove(cid)
        }
    }

    /// Switch a placeholder creative's sample-grid layout (cols×rows) and rebuild it.
    func setSampleGrid(project pid: UUID, creative cid: UUID, cols: Int, rows: Int) {
        guard let c = creative(cid, in: pid), c.imageIsPlaceholder, c.type == .grid,
              (c.sampleCols != cols || c.sampleRows != rows),
              let project = projects.first(where: { $0.id == pid }) else { return }
        let filenames = project.product.imageFilenames
        guard !filenames.isEmpty else { return }
        let ratioSize = c.ratio.size
        rebuildingGrids.insert(cid)   // instant feedback while the recompose runs
        Task { [weak self] in
            await self?.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize, filenames: filenames, cols: cols, rows: rows)
            self?.rebuildingGrids.remove(cid)
        }
    }

    /// Set one cell's pan offset (normalized −1…1) for a placeholder sample grid, then recompose the
    /// flat PNG from the SAME photos in the SAME order so the list-card thumbnail and any export stay
    /// in sync with what the inspector's live editor shows. Called on drag-release per cell.
    func setCellOffset(project pid: UUID, creative cid: UUID, index: Int, offset: CGPoint) {
        guard let c = creative(cid, in: pid), c.imageIsPlaceholder, !c.sampleRefs.isEmpty,
              let project = projects.first(where: { $0.id == pid }) else { return }
        let cells = max(1, c.sampleCols * c.sampleRows)
        var offs = c.sampleOffsets
        if offs.count != cells { offs = Array(repeating: .zero, count: cells) }   // normalize length
        guard offs.indices.contains(index) else { return }
        let clamped = CGPoint(x: max(-1, min(1, offset.x)), y: max(-1, min(1, offset.y)))
        guard offs[index] != clamped else { return }
        offs[index] = clamped
        // Reflect the new offset immediately so the live editor holds its position; the recompose
        // below (which also writes sampleOffsets) just brings the flat PNG up to date afterwards.
        mutateCreative(project: pid, creative: cid) { $0.sampleOffsets = offs }
        let ratioSize = c.ratio.size
        // Split grids recompose from their own per-cell photos; normal grids re-crop the reuse set.
        if c.isSplit {
            Task { [weak self] in await self?.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratioSize) }
            return
        }
        let filenames = project.product.imageFilenames
        let cols = c.sampleCols, rows = c.sampleRows, refs = c.sampleRefs
        Task { [weak self] in
            await self?.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize, filenames: filenames,
                                        cols: cols, rows: rows, reuseRefs: refs, offsets: offs)
        }
    }

    /// Re-roll just ONE cell of a placeholder sample grid: pick a fresh random photo for that cell
    /// (preferring a different one than it shows now), recenter it, and recompose the flat PNG. The
    /// other cells keep their current photo and pan. Driven by the per-cell right-click menu.
    func reSampleCell(project pid: UUID, creative cid: UUID, index: Int) {
        guard let c = creative(cid, in: pid), c.imageIsPlaceholder, c.type == .grid,
              let project = projects.first(where: { $0.id == pid }) else { return }
        let pool = project.product.imageFilenames
        guard !pool.isEmpty else { return }
        let cells = max(1, c.sampleCols * c.sampleRows)
        guard index >= 0, index < cells else { return }
        // Normalize refs/offsets to the cell count so indexing is always safe.
        var refs = c.sampleRefs
        if refs.count != cells { refs = (0..<cells).map { refs.indices.contains($0) ? refs[$0] : (pool.randomElement() ?? pool[0]) } }
        var offs = c.sampleOffsets
        if offs.count != cells { offs = Array(repeating: .zero, count: cells) }
        // Pick a new photo, avoiding the current one when the pool has alternatives.
        let candidates = pool.count > 1 ? pool.filter { $0 != refs[index] } : pool
        guard let pick = candidates.randomElement() else { return }
        refs[index] = pick
        offs[index] = .zero   // new photo → start centered
        mutateCreative(project: pid, creative: cid) { $0.sampleRefs = refs; $0.sampleOffsets = offs }
        let ratioSize = c.ratio.size, cols = c.sampleCols, rows = c.sampleRows
        Task { [weak self] in
            await self?.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize, filenames: pool,
                                        cols: cols, rows: rows, reuseRefs: refs, offsets: offs)
        }
    }

    func selectProject(_ id: UUID) {
        selectedProjectID = id
        let persona = projects.first { $0.id == id }?.personas.first
        selectedPersonaID = persona?.id
        selectedCreativeID = persona?.creatives.first?.id   // default-select so the inspector isn't empty
        screen = .results
    }

    /// Select a persona and default to its first creative (keeps the inspector populated).
    func selectPersona(_ personaID: UUID) {
        selectedPersonaID = personaID
        let persona = selectedProject?.personas.first { $0.id == personaID }
        selectedCreativeID = persona?.creatives.first?.id
        screen = .results
    }

    /// Add another persona to a campaign. AI generates it in the same context; if `ranking` is
    /// provided, that not-selected candidate is fleshed out and marked selected.
    func addPersona(project pid: UUID, fromRanking ranking: RankingEntry? = nil, instruction: String = "") {
        guard settings.hasOpenAIKey else {
            showToast("Add your OpenAI API key in Settings (⌘,) first.", isError: true); return
        }
        guard let project = projects.first(where: { $0.id == pid }) else { return }
        if let r = ranking {
            guard !addingPersonaIDs.contains(r.id) else { return }   // already generating this row
            addingPersonaIDs.insert(r.id)
        } else {
            guard !addingCustomPersona else { return }
            addingCustomPersonaPID = pid
        }
        // A user-typed brief for a new persona is durable intent for this campaign — remember it.
        if ranking == nil, !instruction.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            recordMemory(project: pid, note: "Wanted an extra persona: \(instruction)")
        }
        let existing = project.personas.map(\.name)
        let m = project.creativesPerPersona
        let product = project.product
        let offer = project.offer
        let client = makeStrategyClient(language: product.contentLanguage, projectMemory: memoryForPrompt(pid))

        Task { [weak self] in
            guard let self else { return }
            defer {
                if let r = ranking { self.addingPersonaIDs.remove(r.id) }
                else { self.addingCustomPersonaPID = nil }
            }
            do {
                let dto = try await client.generatePersona(
                    product: product, offer: offer, existing: existing, m: m,
                    seedName: ranking?.name, seedDesc: ranking?.why, instruction: instruction)
                let persona = dto.makePersona(m: m, ratio: self.settings.defaultRatio)
                guard persona.isWellFormed else {
                    self.showToast("The model returned an incomplete persona — please try again.", isError: true)
                    return
                }
                guard let idx = self.projectIndex(pid) else { return }
                self.projects[idx].personas.append(persona)
                self.projects[idx].personaCount = self.projects[idx].personas.count
                if let r = ranking, let ri = self.projects[idx].ranking.firstIndex(where: { $0.id == r.id }) {
                    self.projects[idx].ranking[ri].picked = true
                } else {
                    // Custom persona — add a selected ranking row so it shows in the ranking sheet.
                    self.projects[idx].ranking.insert(
                        RankingEntry(name: persona.name, audience: persona.audience, score: persona.score,
                                     picked: true, why: persona.reasonTop), at: 0)
                }
                self.store.save(self.projects[idx])
                if self.selectedProjectID == pid { self.selectedPersonaID = persona.id; self.selectedCreativeID = persona.creatives.first?.id }
                self.showToast("Added persona · \(persona.name)")

                // The real row now exists — drop the loading placeholder immediately so it doesn't
                // double up while the sample grids build in the background below.
                if let r = ranking { self.addingPersonaIDs.remove(r.id) } else { self.addingCustomPersonaPID = nil }

                // Build the sample 3×3 grids OFF the main thread (decode + compose are heavy).
                if !product.imageFilenames.isEmpty {
                    for c in persona.creatives {
                        await self.buildSampleGrid(pid: pid, cid: c.id, ratioSize: c.ratio.size,
                                                   filenames: product.imageFilenames, guarded: true)
                    }
                }
            } catch {
                let msg = (error as? APIError)?.errorDescription ?? error.localizedDescription
                self.showToast(msg, isError: true)
            }
        }
    }

    /// Top a campaign back up to `n` well-formed personas after the strategy dropped malformed ones.
    /// Each missing slot is regenerated with the single-persona endpoint (small, reliable output),
    /// seeded from an unused ranking candidate so it stays consistent with the campaign. A persona is
    /// only appended if it comes back well-formed; the loop is bounded so a persistently-bad model can
    /// never spin forever — we simply land with fewer personas rather than an empty one.
    private func backfillPersonas(pid: UUID, upTo n: Int, product: Product, m: Int, filenames: [String]) async {
        guard settings.hasOpenAIKey else { return }
        let client = makeStrategyClient(language: product.contentLanguage, projectMemory: memoryForPrompt(pid))
        var attempts = 0
        while let idx = projectIndex(pid), projects[idx].personas.count < n, attempts < n + 2 {
            attempts += 1
            let existing = projects[idx].personas.map(\.name)
            let offer = projects[idx].offer
            // Seed from the HIGHEST-SCORED ranking row not already built — so a short campaign is
            // topped up with the genuine next-best personas (the "top n"), not whatever the model
            // happened to list first.
            let seed = projects[idx].ranking
                .filter { r in
                    !r.picked && !existing.contains { StrategyResponse.nameKey($0) == StrategyResponse.nameKey(r.name) }
                }
                .max(by: { $0.score < $1.score })
            do {
                let dto = try await client.generatePersona(
                    product: product, offer: offer, existing: existing, m: m,
                    seedName: seed?.name, seedDesc: seed?.why, instruction: "")
                let persona = dto.makePersona(m: m, ratio: settings.defaultRatio)
                guard persona.isWellFormed, let i = projectIndex(pid) else { continue }
                projects[i].personas.append(persona)
                projects[i].personaCount = projects[i].personas.count
                // Mark the SEED row as picked (by id) so it can't be re-seeded even if the model
                // reworded the name; fall back to a name match for seedless (custom) backfills.
                if let sid = seed?.id, let ri = projects[i].ranking.firstIndex(where: { $0.id == sid }) {
                    projects[i].ranking[ri].picked = true
                } else if let ri = projects[i].ranking.firstIndex(where: {
                    StrategyResponse.nameKey($0.name) == StrategyResponse.nameKey(persona.name)
                }) {
                    projects[i].ranking[ri].picked = true
                }
                store.save(projects[i])
                if selectedProjectID == pid && selectedPersonaID == nil {
                    selectedPersonaID = persona.id
                    selectedCreativeID = persona.creatives.first?.id
                }
                if !filenames.isEmpty {
                    for c in persona.creatives {
                        await buildSampleGrid(pid: pid, cid: c.id, ratioSize: c.ratio.size,
                                              filenames: filenames, guarded: true)
                    }
                }
            } catch {
                break   // network / decode error — stop backfilling and keep what we have
            }
        }
    }

    func deleteProject(_ id: UUID) {
        store.delete(id)
        projects.removeAll { $0.id == id }
        if selectedProjectID == id {
            selectedProjectID = projects.first?.id
            selectedPersonaID = projects.first?.personas.first?.id
            screen = projects.isEmpty ? .input : .results
        }
    }

    /// Pin / unpin a project, then re-sort so pinned projects float to the top of the sidebar.
    func togglePin(_ id: UUID) {
        guard let idx = projectIndex(id) else { return }
        projects[idx].pinned.toggle()
        store.save(projects[idx])
        projects.sort {
            if $0.pinned != $1.pinned { return $0.pinned }   // pinned projects first
            return $0.updatedAt > $1.updatedAt
        }
    }

    // MARK: Persona actions (sidebar right-click)

    /// Remove a persona from its campaign and free its ranking slot so it can be re-added later.
    func removePersona(project pid: UUID, persona personaID: UUID) {
        guard let idx = projectIndex(pid),
              let perIdx = projects[idx].personas.firstIndex(where: { $0.id == personaID }) else { return }
        let removed = projects[idx].personas.remove(at: perIdx)
        projects[idx].personaCount = projects[idx].personas.count
        if let ri = projects[idx].ranking.firstIndex(where: {
            StrategyResponse.nameKey($0.name) == StrategyResponse.nameKey(removed.name)
        }) {
            projects[idx].ranking[ri].picked = false
        }
        store.save(projects[idx])
        if selectedPersonaID == personaID {
            selectedPersonaID = projects[idx].personas.first?.id
            selectedCreativeID = projects[idx].personas.first?.creatives.first?.id
        }
        showToast("Removed persona · \(removed.name)")
    }

    /// Mark a persona as the campaign's winner (exclusive — clears the flag on every other persona).
    /// Toggling the current winner clears it, leaving the campaign with no marked winner.
    func togglePersonaWinner(project pid: UUID, persona personaID: UUID) {
        guard let idx = projectIndex(pid),
              let perIdx = projects[idx].personas.firstIndex(where: { $0.id == personaID }) else { return }
        let makeWinner = !projects[idx].personas[perIdx].winner
        for i in projects[idx].personas.indices { projects[idx].personas[i].winner = false }
        projects[idx].personas[perIdx].winner = makeWinner
        store.save(projects[idx])
    }

    /// Duplicate a persona with all its creatives — independent ids, text layers, and image files so
    /// edits to the copy never touch the original.
    func duplicatePersona(project pid: UUID, persona personaID: UUID) {
        guard let idx = projectIndex(pid),
              let perIdx = projects[idx].personas.firstIndex(where: { $0.id == personaID }) else { return }
        let orig = projects[idx].personas[perIdx]
        var copy = orig
        copy.id = UUID()
        copy.winner = false
        copy.name = orig.name + " (copy)"
        copy.creatives = orig.creatives.map { c in
            var nc = c
            nc.id = UUID()
            nc.textLayers = c.textLayers.map { var l = $0; l.id = UUID(); return l }
            if let fn = c.imageFilename,
               let data = try? Data(contentsOf: store.generatedImageURL(fn, projectID: pid)) {
                nc.imageFilename = store.saveGeneratedImage(data, projectID: pid, creativeID: nc.id)
            }
            return nc
        }
        projects[idx].personas.insert(copy, at: perIdx + 1)
        projects[idx].personaCount = projects[idx].personas.count
        store.save(projects[idx])
        selectedPersonaID = copy.id
        selectedCreativeID = copy.creatives.first?.id
        showToast("Duplicated persona · \(orig.name)")
    }

    /// Re-generate a persona: the AI rewrites every creative's copy (and the persona copy block),
    /// keeping the persona's identity (name/audience/score/lens/winner). Images are NOT AI-generated —
    /// each creative's grid is freshly resampled from the product photos, back to a sample placeholder.
    func regeneratePersona(project pid: UUID, persona personaID: UUID, feedback: String = "") {
        guard settings.hasOpenAIKey else {
            showToast("Add your OpenAI API key in Settings (⌘,) first.", isError: true); return
        }
        guard let project = projects.first(where: { $0.id == pid }),
              let persona = project.personas.first(where: { $0.id == personaID }) else { return }
        guard !regeneratingPersonaIDs.contains(personaID) else { return }   // already running
        regeneratingPersonaIDs.insert(personaID)

        let existing = project.personas.filter { $0.id != personaID }.map(\.name)
        let m = max(1, persona.creatives.count)
        let product = project.product
        let offer = project.offer
        // Base instruction keeps the persona's identity; the user's feedback (if any) is appended so
        // the rewrite honours their new requirements.
        var instruction = "Keep the same persona identity; rewrite fresh, distinct copy for every creative."
        let trimmedFeedback = feedback.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmedFeedback.isEmpty {
            instruction += " Apply this feedback / new requirements: \(trimmedFeedback)"
            recordMemory(project: pid, note: "Persona '\(persona.name)' feedback: \(trimmedFeedback)")
        }
        let client = makeStrategyClient(language: product.contentLanguage, projectMemory: memoryForPrompt(pid))

        Task { [weak self] in
            guard let self else { return }
            defer { self.regeneratingPersonaIDs.remove(personaID) }
            do {
                let dto = try await client.generatePersona(
                    product: product, offer: offer, existing: existing, m: m,
                    seedName: persona.name, seedDesc: persona.desc.isEmpty ? persona.angle : persona.desc,
                    instruction: instruction)
                let fresh = dto.makePersona(m: m, ratio: self.settings.defaultRatio)
                guard fresh.isWellFormed else {
                    self.showToast("The model returned incomplete copy — please try again.", isError: true); return
                }
                guard let i = self.projectIndex(pid),
                      let pj = self.projects[i].personas.firstIndex(where: { $0.id == personaID }) else { return }
                // Keep identity (name/audience/score/lens/winner); swap in the rewritten copy + creatives.
                self.projects[i].personas[pj].copy = fresh.copy
                self.projects[i].personas[pj].creatives = fresh.creatives
                self.store.save(self.projects[i])
                if self.selectedPersonaID == personaID { self.selectedCreativeID = fresh.creatives.first?.id }
                self.showToast("Re-generated persona · \(persona.name)")

                // Resample each grid off the main thread — no AI image generation.
                if !product.imageFilenames.isEmpty {
                    for c in fresh.creatives {
                        await self.buildSampleGrid(pid: pid, cid: c.id, ratioSize: c.ratio.size,
                                                   filenames: product.imageFilenames)
                    }
                }
            } catch {
                let msg = (error as? APIError)?.errorDescription ?? error.localizedDescription
                self.showToast(msg, isError: true)
            }
        }
    }

    // MARK: Mutation helpers

    func mutate(_ projectID: UUID, _ block: (inout Project) -> Void) {
        guard let pi = projectIndex(projectID) else { return }
        block(&projects[pi])
        store.save(projects[pi])
    }

    private func mutateCreative(project pid: UUID, creative cid: UUID, _ block: (inout Creative) -> Void) {
        guard let pi = projectIndex(pid) else { return }
        for personaIdx in projects[pi].personas.indices {
            if let ci = projects[pi].personas[personaIdx].creatives.firstIndex(where: { $0.id == cid }) {
                block(&projects[pi].personas[personaIdx].creatives[ci])
                store.save(projects[pi])
                return
            }
        }
    }

    func creative(_ cid: UUID, in pid: UUID) -> Creative? {
        guard let p = projects.first(where: { $0.id == pid }) else { return nil }
        for persona in p.personas {
            if let c = persona.creatives.first(where: { $0.id == cid }) { return c }
        }
        return nil
    }

    /// Duplicate a creative within its persona — copies everything (variants, layers, image).
    func duplicateCreative(project pid: UUID, persona personaID: UUID, creative cid: UUID) {
        guard let piIdx = projectIndex(pid),
              let perIdx = projects[piIdx].personas.firstIndex(where: { $0.id == personaID }),
              let origIdx = projects[piIdx].personas[perIdx].creatives.firstIndex(where: { $0.id == cid })
        else { return }
        let orig = projects[piIdx].personas[perIdx].creatives[origIdx]

        var copy = orig
        copy.id = UUID()
        copy.textLayers = orig.textLayers.map { var l = $0; l.id = UUID(); return l }   // independent layers
        // Give the copy its own image file so edits don't affect the original.
        if let fn = orig.imageFilename,
           let data = try? Data(contentsOf: store.generatedImageURL(fn, projectID: pid)) {
            copy.imageFilename = store.saveGeneratedImage(data, projectID: pid, creativeID: copy.id)
        }
        copy.rank = (projects[piIdx].personas[perIdx].creatives.map { $0.rank }.max() ?? 0) + 1

        projects[piIdx].personas[perIdx].creatives.insert(copy, at: origIdx + 1)
        store.save(projects[piIdx])
        selectedCreativeID = copy.id
        showToast("Creative duplicated")
    }

    func toggleWinner(project pid: UUID, creative cid: UUID) {
        mutateCreative(project: pid, creative: cid) { $0.winner.toggle() }
    }

    func updateImagePrompt(project pid: UUID, creative cid: UUID, prompt: String) {
        let before = creative(cid, in: pid)?.imagePrompt
        mutateCreative(project: pid, creative: cid) { $0.imagePrompt = prompt }
        // A hand-edited image prompt is a durable styling preference — capture the gist.
        if before != prompt, !prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            recordMemory(project: pid, note: "Hand-edited an image prompt to: \(prompt)")
        }
    }

    /// Commit non-destructive image adjustments to a creative (persisted; applied to preview + export).
    func setAdjustments(project pid: UUID, creative cid: UUID, _ adj: ImageAdjustments) {
        mutateCreative(project: pid, creative: cid) { $0.adjustments = adj }
        previewCache[cid] = nil       // force re-composite with the new adjustments
        adjustedBaseCache[cid] = nil
    }

    /// The RAW base bitmap (no text, no adjustments) — used by the live image editor to preview
    /// the user's in-progress adjustments against the original.
    func rawBaseImage(project pid: UUID, creative cid: UUID) async -> NSImage? {
        guard let c = creative(cid, in: pid), let url = generatedImageURL(for: c, in: pid) else { return nil }
        return await ImageStore.shared.load(url)
    }

    func updateTextLayers(project pid: UUID, creative cid: UUID, layers: [TextLayer]) {
        mutateCreative(project: pid, creative: cid) { $0.textLayers = layers }
    }

    // MARK: Layer clipboard (⌘C / ⌘V / Delete on a selected on-image object)

    /// A pasteable clone of a layer: a fresh identity, nudged down-right by a standard paste offset so
    /// it doesn't sit exactly on the original, and stripped of the auto-managed split-label tag (a
    /// hand-pasted copy must not be swept away when split labels are rebuilt).
    static func pastedCopy(of layer: TextLayer) -> TextLayer {
        var l = layer
        l.id = UUID()
        l.isSplitLabel = false
        l.xFrac = min(0.9, max(0, layer.xFrac + 0.04))
        l.yFrac = min(0.9, max(0, layer.yFrac + 0.04))
        return l
    }

    /// ⌘C — stash a copied layer in the app-wide clipboard.
    func copyLayer(_ layer: TextLayer) { layerClipboard = layer }

    /// ⌘V — drop an offset duplicate of the clipboard layer into the given creative. Returns the new
    /// layer's id so the caller can select it; nil when the clipboard is empty.
    func pasteLayer(project pid: UUID, creative cid: UUID) -> UUID? {
        guard let src = layerClipboard else { return nil }
        let copy = Self.pastedCopy(of: src)
        mutateCreative(project: pid, creative: cid) { $0.textLayers.append(copy) }
        return copy.id
    }

    /// Delete — remove one on-image object by id.
    func deleteLayer(project pid: UUID, creative cid: UUID, layerID: UUID) {
        mutateCreative(project: pid, creative: cid) { $0.textLayers.removeAll { $0.id == layerID } }
    }

    /// Edit the hook text inline (double-click on the image). Updates the layer + the selected hook variant.
    func editHookText(project pid: UUID, creative cid: UUID, layerID: UUID, text: String) {
        mutateCreative(project: pid, creative: cid) {
            if let i = $0.textLayers.firstIndex(where: { $0.id == layerID }) { $0.textLayers[i].text = text }
            if $0.selHook >= 0 && $0.hooks.indices.contains($0.selHook) { $0.hooks[$0.selHook] = text }
        }
    }

    /// Apply a style preset (Editorial / Clean Float / Bold Block / TikTok / Normal 1–5) to every
    /// layer — seeds the explicit colors / box / weight / font so the picker can still override them.
    func setHookStyle(project pid: UUID, creative cid: UUID, style: HookStyle) {
        mutateCreative(project: pid, creative: cid) {
            for i in $0.textLayers.indices {
                $0.textLayers[i].apply(style: style)
            }
        }
    }

    /// Move a single text layer (used by drag-to-reposition on the preview).
    func moveTextLayer(project pid: UUID, creative cid: UUID, layerID: UUID, x: Double, y: Double) {
        mutateCreative(project: pid, creative: cid) {
            if let i = $0.textLayers.firstIndex(where: { $0.id == layerID }) {
                $0.textLayers[i].xFrac = x
                $0.textLayers[i].yFrac = y
            }
        }
    }

    /// Resize a text layer via corner-drag on the preview: set font size and reposition the
    /// top-left so the anchored (opposite) corner stays fixed, like resizing a rectangle.
    func resizeTextLayer(project pid: UUID, creative cid: UUID, layerID: UUID,
                         fontSize: Double, x: Double, y: Double) {
        mutateCreative(project: pid, creative: cid) {
            if let i = $0.textLayers.firstIndex(where: { $0.id == layerID }) {
                $0.textLayers[i].fontSize = fontSize
                $0.textLayers[i].xFrac = x
                $0.textLayers[i].yFrac = y
            }
        }
    }

    // MARK: Regenerate AI content (text fields + images) with a custom instruction

    func rewriteKey(_ creativeID: UUID, _ field: CopyField) -> String { "\(creativeID.uuidString):\(field.rawValue)" }
    func isRewriting(_ creativeID: UUID, _ field: CopyField) -> Bool { rewriting.contains(rewriteKey(creativeID, field)) }

    /// Locate the (persona, creative) pair for a creative id within a project.
    private func locate(project pid: UUID, creative cid: UUID) -> (Persona, Creative)? {
        guard let p = projects.first(where: { $0.id == pid }) else { return nil }
        for persona in p.personas {
            if let c = persona.creatives.first(where: { $0.id == cid }) { return (persona, c) }
        }
        return nil
    }

    /// Select which variant is active for a copy field. Choosing a hook also updates the on-image text.
    func selectVariant(project pid: UUID, creative cid: UUID, field: CopyField, index: Int) {
        mutateCreative(project: pid, creative: cid) {
            switch field {
            case .headline:    if $0.headlines.indices.contains(index) { $0.selHeadline = index }
            case .primaryText: if $0.primaryTexts.indices.contains(index) { $0.selPrimaryText = index }
            case .hook:
                guard $0.hooks.indices.contains(index) else { break }
                let oldHook = $0.hook
                $0.selHook = ($0.selHook == index) ? -1 : index   // tap again to deselect
                let newHook = $0.hook, newHi = $0.highlight
                for i in $0.textLayers.indices where $0.textLayers[i].text == oldHook {
                    $0.textLayers[i].text = newHook
                    $0.textLayers[i].highlightWord = newHi
                }
            }
        }
        // Actively preferring a NON-top variant signals the AI's first option wasn't the best fit —
        // a useful, low-noise preference to remember (index 0 / deselect record nothing).
        guard index > 0, let c = creative(cid, in: pid) else { return }
        let chosen: String?
        switch field {
        case .headline:    chosen = c.selHeadline == index && c.headlines.indices.contains(index) ? c.headlines[index] : nil
        case .primaryText: chosen = c.selPrimaryText == index && c.primaryTexts.indices.contains(index) ? c.primaryTexts[index] : nil
        case .hook:        chosen = c.selHook == index && c.hooks.indices.contains(index) ? c.hooks[index] : nil
        }
        if let chosen, !chosen.isEmpty { recordMemory(project: pid, note: "Preferred \(field.label): \(chosen)") }
    }

    /// Change a creative's output aspect ratio. If it's still the sample grid, rebuild it to fit.
    func setRatio(project pid: UUID, creative cid: UUID, ratio: AdRatio) {
        var rebuild = false
        mutateCreative(project: pid, creative: cid) { $0.ratio = ratio; rebuild = $0.imageIsPlaceholder }
        guard rebuild else { return }
        // Split grids recompose from their own dropped photos (no product-image pool needed).
        if creative(cid, in: pid)?.isSplit == true {
            rebuildingGrids.insert(cid)
            Task { [weak self] in
                await self?.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratio.size)
                self?.rebuildingGrids.remove(cid)
            }
            return
        }
        guard let project = projects.first(where: { $0.id == pid }) else { return }
        let filenames = project.product.imageFilenames
        guard !filenames.isEmpty else { return }
        let cur = creative(cid, in: pid)
        let cols = cur?.sampleCols ?? 3, rows = cur?.sampleRows ?? 3
        let reuse = cur?.sampleRefs   // keep the same photos, just re-crop to the new aspect
        let keepRefs = reuse?.isEmpty == true ? nil : reuse
        let keepOffsets = keepRefs == nil ? nil : cur?.sampleOffsets   // same photos → keep their pans
        rebuildingGrids.insert(cid)   // instant feedback while the re-crop runs
        Task { [weak self] in
            await self?.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratio.size, filenames: filenames,
                                        cols: cols, rows: rows, reuseRefs: keepRefs, offsets: keepOffsets)
            self?.rebuildingGrids.remove(cid)
        }
    }

    // MARK: Before/After grid (2-col Before|After, N rows = N matched pairs)

    /// Number of cells in a Before/After grid with `rows` pairs (always 2 columns).
    /// Cell count for a 2-column split grid. Before/After uses ≥2 rows (pairs); Comparison allows a
    /// single row, so the floor is 1 — `splitRowsClamp` applies the per-mode minimum.
    private static func splitCells(rows: Int) -> Int { 2 * max(1, min(4, rows)) }

    /// Clamp a row count to its mode's range: Comparison 1…4, Before/After 2…4, Problem/Solution 2…3.
    private static func splitRowsClamp(_ rows: Int, type: AdType) -> Int {
        switch type {
        case .comparison:      return max(1, min(4, rows))
        case .problemSolution: return max(2, min(3, rows))
        default:               return max(2, min(4, rows))   // beforeAfter
        }
    }

    /// Build the initial Before/After refs: each After cell (right column) seeded with a random photo
    /// from the user's input images; Before cells (left column) left empty for a drop / AI-generate.
    /// `existing` cells are preserved (used when changing the row count), only empty After cells fill.
    private static func splitSeedRefs(cells: Int, rows: Int, pool: [String], existing: [String]) -> [String] {
        var refs = (0..<cells).map { i in existing.indices.contains(i) ? existing[i] : "" }
        guard !pool.isEmpty else { return refs }
        let emptyAfter = (0..<rows).map { $0 * 2 + 1 }.filter { refs.indices.contains($0) && refs[$0].isEmpty }
        guard !emptyAfter.isEmpty else { return refs }
        let picks = randomPickIndices(count: pool.count, pick: emptyAfter.count).map { pool[$0] }
        for (k, idx) in emptyAfter.enumerated() where k < picks.count { refs[idx] = picks[k] }
        return refs
    }

    /// Switch a creative's image ad type. `grid` keeps the sample-grid behavior; `beforeAfter` and
    /// `comparison` both lock the layout to 2 columns × N rows (each row a left|right pair the user
    /// drops their own photos into), seed the per-row column labels, and compose a divider grid. The
    /// two split modes share one mechanism — they differ only in default labels and whether
    /// before→after arrows are seeded (Before/After only).
    func setAdType(project pid: UUID, creative cid: UUID, type: AdType) {
        guard let c = creative(cid, in: pid), c.type != type else { return }
        if type == .beforeAfter || type == .comparison || type == .problemSolution {
            let rows = Self.splitRowsClamp(c.sampleRows, type: type)
            let cells = Self.splitCells(rows: rows)
            let labels = splitDefaultLabels(pid: pid, type: type)
            let withArrows = type == .beforeAfter
            let pool = projects.first(where: { $0.id == pid })?.product.imageFilenames ?? []
            let seededRefs = Self.splitSeedRefs(cells: cells, rows: rows, pool: pool, existing: [])
            mutateCreative(project: pid, creative: cid) {
                $0.type = type
                // Back to an editable placeholder so the interactive per-cell editor (with drag-drop)
                // shows instead of the static done-state view — even if this was a generated image.
                $0.status = .idle
                $0.errorMessage = nil
                $0.sampleCols = 2; $0.sampleRows = rows
                $0.splitLeftLabel = labels.left; $0.splitRightLabel = labels.right
                // Right column starts with a random input photo (your product / the "After"/"premium"/
                // Solution side); left stays empty for a drop or AI generation. Arrows only for
                // before→after. Problem/Solution tracks each Problem cell's prompt for regeneration.
                $0.sampleRefs = seededRefs
                $0.sampleOffsets = Array(repeating: .zero, count: cells)
                $0.psProblemPrompts = type == .problemSolution ? Array(repeating: "", count: cells) : []
                Self.removeSplitLabels(&$0)
                Self.seedSplitLabels(&$0, rows: rows, left: labels.left, right: labels.right, type: type)
                Self.removeBeforeAfterArrows(&$0)
                if withArrows { Self.seedBeforeAfterArrows(&$0, rows: rows) }
            }
            let ratioSize = c.ratio.size
            rebuildingGrids.insert(cid)
            Task { [weak self] in
                await self?.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratioSize)
                self?.rebuildingGrids.remove(cid)
            }
        } else if type == .variant {
            seedVariantGrid(project: pid, creative: cid)
        } else {
            mutateCreative(project: pid, creative: cid) {
                $0.type = .grid
                $0.variantPatternRefs = []
                $0.psProblemPrompts = []
                Self.removeSplitLabels(&$0)
                Self.removeBeforeAfterArrows(&$0)
            }
            // Rebuild a normal sample grid from the project's reference photos when there are any.
            if let project = projects.first(where: { $0.id == pid }), !project.product.imageFilenames.isEmpty {
                reSample(project: pid, creative: cid)
            }
        }
    }

    // MARK: Variant grid (same-SKU pattern variations + per-cell "Vary")

    /// The grid shapes a Variant grid may take — (rows, cols). Offered as a picker (and used for the
    /// initial random roll). Every cell is the SAME product type, each showing a different pattern.
    static let variantLayouts: [(rows: Int, cols: Int)] = [(3, 1), (3, 2), (2, 2), (3, 3)]

    /// Apply an explicit Variant layout (rows × cols) the user picked, re-seeding patterns for the new
    /// cell count. Same layout re-selected is a no-op (the picker can't re-fire it); use the cell menu's
    /// per-cell pattern swap to refresh individual cells.
    func setVariantGrid(project pid: UUID, creative cid: UUID, rows: Int, cols: Int) {
        guard let c = creative(cid, in: pid), c.isVariant,
              c.sampleRows != rows || c.sampleCols != cols else { return }
        seedVariantGrid(project: pid, creative: cid, rows: rows, cols: cols)
    }

    /// Build (or re-roll) a Variant grid. With an explicit `rows`/`cols` the layout is fixed (user
    /// picker); otherwise a random one from `variantLayouts`. Each cell is filled with a different
    /// random input photo, PINNED into `variantPatternRefs` (the pattern source of truth Vary never
    /// overwrites), then the flat grid is composed. Cells keep their picked order so cell *i* always
    /// maps to pattern *i*. When the user has fewer inputs than cells, patterns cycle.
    func seedVariantGrid(project pid: UUID, creative cid: UUID, rows: Int? = nil, cols: Int? = nil) {
        guard let c = creative(cid, in: pid) else { return }
        let pool = projects.first(where: { $0.id == pid })?.product.imageFilenames ?? []
        guard !pool.isEmpty else {
            showToast("Add input images first to build a variant grid.", isError: true); return
        }
        let roll = Self.variantLayouts.randomElement() ?? (2, 2)
        let rows = (rows.map { max(1, min(3, $0)) }) ?? roll.rows
        let cols = (cols.map { max(1, min(3, $0)) }) ?? roll.cols
        let cells = rows * cols
        let shuffled = pool.shuffled()
        // Distinct patterns where possible; cycle the shuffled pool when inputs < cells.
        let picks = (0..<cells).map { shuffled[$0 % shuffled.count] }
        let offs = Array(repeating: CGPoint.zero, count: cells)
        mutateCreative(project: pid, creative: cid) {
            $0.type = .variant
            $0.status = .idle
            $0.errorMessage = nil
            $0.sampleCols = cols; $0.sampleRows = rows
            $0.sampleRefs = picks
            $0.variantPatternRefs = picks   // pin the ORIGINAL real patterns per cell
            $0.sampleOffsets = offs
            Self.removeSplitLabels(&$0)
            Self.removeBeforeAfterArrows(&$0)
        }
        let ratioSize = c.ratio.size
        rebuildingGrids.insert(cid)
        Task { [weak self] in
            // reuseRefs keeps the picked order (cell i ↔ pattern i); never random re-picks.
            await self?.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize, filenames: picks,
                                        cols: cols, rows: rows, reuseRefs: picks, offsets: offs)
            self?.rebuildingGrids.remove(cid)
        }
    }

    /// Vary the grid around `anchorIndex`: re-render every OTHER cell so its scene/angle/lighting match
    /// the anchor cell, while each cell keeps its OWN pinned pattern (`variantPatternRefs`). The anchor
    /// cell is left untouched, so at least one cell is always a 100%-real photo. Re-running with a
    /// different anchor re-varies from the originals (no generation-to-generation drift).
    func varyVariantGrid(project pid: UUID, creative cid: UUID, anchorIndex: Int) {
        guard let c = creative(cid, in: pid), c.isVariant else { return }
        let cells = max(1, c.sampleCols * c.sampleRows)
        guard anchorIndex >= 0, anchorIndex < cells,
              c.sampleRefs.indices.contains(anchorIndex),
              let anchorData = store.referenceImageData(projectID: pid, filenames: [c.sampleRefs[anchorIndex]]).first else {
            showToast("This cell has no photo to anchor the layout.", isError: true); return
        }
        guard let provider = anyImageProvider() else {
            showToast("Add an OpenAI or Gemini API key in Settings (⌘,) first.", isError: true); return
        }
        // Target = the anchor's own pixel aspect so every re-rendered cell crops identically in the grid.
        let target: CGSize = NSImage(data: anchorData).map { CGSize(width: max(1, $0.pixelWidth), height: max(1, $0.pixelHeight)) }
            ?? c.ratio.size
        // Each cell's pinned pattern, falling back to whatever it currently shows (legacy safety).
        let patternRefs = (0..<cells).map { i -> String in
            if c.variantPatternRefs.indices.contains(i), !c.variantPatternRefs[i].isEmpty { return c.variantPatternRefs[i] }
            return c.sampleRefs.indices.contains(i) ? c.sampleRefs[i] : ""
        }
        // Redraw every cell except the anchor that actually has a pinned pattern and isn't already varying.
        let work = (0..<cells).filter {
            $0 != anchorIndex && !patternRefs[$0].isEmpty && !varyingCells.contains(CellRef(cid, $0))
        }
        guard !work.isEmpty else { return }
        for i in work { varyingCells.insert(CellRef(cid, i)) }
        showToast("Varying \(work.count) cell\(work.count == 1 ? "" : "s") to match cell \(anchorIndex + 1)…")

        let prompt = Self.variantVaryPrompt
        let ratioSize = c.ratio.size, cols = c.sampleCols, rows = c.sampleRows
        Task { [weak self] in
            guard let self else { return }
            // Re-render the cells concurrently; each result drops into its cell as it returns.
            await withTaskGroup(of: (Int, Data?).self) { group in
                for i in work {
                    let patternData = self.store.referenceImageData(projectID: pid, filenames: [patternRefs[i]]).first
                    group.addTask {
                        guard let patternData else { return (i, nil) }
                        // PHOTO 1 = this cell's REAL product (pattern to keep, locked by .product);
                        // PHOTO 2 = the anchor (scene to match). Restage the product into the scene.
                        let png = try? await provider.generate(prompt: prompt,
                                                               references: [patternData, anchorData],
                                                               target: target, fidelity: .product)
                        return (i, png)
                    }
                }
                for await (i, png) in group {
                    defer { self.varyingCells.remove(CellRef(cid, i)) }
                    guard let png, let name = self.store.saveReferenceImage(png, projectID: pid, index: i) else { continue }
                    self.mutateCreative(project: pid, creative: cid) { cr in
                        guard cr.isVariant else { return }
                        let n = max(1, cr.sampleCols * cr.sampleRows)
                        guard i < n else { return }
                        var refs = (0..<n).map { k in cr.sampleRefs.indices.contains(k) ? cr.sampleRefs[k] : "" }
                        refs[i] = name   // only the DISPLAYED photo changes; variantPatternRefs stays pinned
                        cr.sampleRefs = refs
                    }
                }
            }
            // Recompose the flat grid once every cell is placed.
            guard let cur = self.creative(cid, in: pid), cur.isVariant else { return }
            let refs = cur.sampleRefs
            let offs = (0..<max(1, cur.sampleCols * cur.sampleRows)).map { cur.sampleOffsets.indices.contains($0) ? cur.sampleOffsets[$0] : .zero }
            await self.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize, filenames: refs,
                                       cols: cols, rows: rows, reuseRefs: refs, offsets: offs)
            self.showToast("Synced the variant grid to the anchor cell.")
        }
    }

    /// Re-render ONE variant cell to match a chosen anchor cell — the per-cell "fix this cell" path.
    /// Same mechanism as `varyVariantGrid` but for a single target, so the user can repair a cell the
    /// AI mangled without re-rendering the whole grid.
    func varyVariantCell(project pid: UUID, creative cid: UUID, index: Int, anchorIndex: Int) {
        guard let c = creative(cid, in: pid), c.isVariant else { return }
        let cells = max(1, c.sampleCols * c.sampleRows)
        guard index >= 0, index < cells, index != anchorIndex,
              anchorIndex >= 0, anchorIndex < cells,
              c.sampleRefs.indices.contains(anchorIndex),
              let anchorData = store.referenceImageData(projectID: pid, filenames: [c.sampleRefs[anchorIndex]]).first else { return }
        guard let provider = anyImageProvider() else {
            showToast("Add an OpenAI or Gemini API key in Settings (⌘,) first.", isError: true); return
        }
        let patternName = (c.variantPatternRefs.indices.contains(index) && !c.variantPatternRefs[index].isEmpty)
            ? c.variantPatternRefs[index]
            : (c.sampleRefs.indices.contains(index) ? c.sampleRefs[index] : "")
        guard !patternName.isEmpty,
              let patternData = store.referenceImageData(projectID: pid, filenames: [patternName]).first else { return }
        let key = CellRef(cid, index)
        guard !varyingCells.contains(key) else { return }
        varyingCells.insert(key)

        let target: CGSize = NSImage(data: anchorData).map { CGSize(width: max(1, $0.pixelWidth), height: max(1, $0.pixelHeight)) }
            ?? c.ratio.size
        let prompt = Self.variantVaryPrompt
        let ratioSize = c.ratio.size, cols = c.sampleCols, rows = c.sampleRows
        Task { [weak self] in
            defer { self?.varyingCells.remove(key) }
            do {
                // PHOTO 1 = this cell's REAL product (pattern, locked); PHOTO 2 = anchor scene.
                let png = try await provider.generate(prompt: prompt, references: [patternData, anchorData],
                                                      target: target, fidelity: .product)
                guard let self else { return }
                guard let name = self.store.saveReferenceImage(png, projectID: pid, index: index) else {
                    self.showToast("Couldn't save the varied image.", isError: true); return
                }
                guard let cur = self.creative(cid, in: pid), cur.isVariant else { return }
                let n = max(1, cur.sampleCols * cur.sampleRows)
                guard index < n else { return }
                var newRefs: [String] = [], offs: [CGPoint] = []
                self.mutateCreative(project: pid, creative: cid) { cr in
                    var refs = (0..<n).map { k in cr.sampleRefs.indices.contains(k) ? cr.sampleRefs[k] : "" }
                    refs[index] = name
                    cr.sampleRefs = refs
                    newRefs = refs
                    offs = (0..<n).map { k in cr.sampleOffsets.indices.contains(k) ? cr.sampleOffsets[k] : .zero }
                }
                await self.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize, filenames: newRefs,
                                           cols: cols, rows: rows, reuseRefs: newRefs, offsets: offs)
            } catch {
                self?.showToast("Couldn't vary the cell: \(error.localizedDescription)", isError: true)
            }
        }
    }

    /// Swap ONE variant cell's pattern for a different random input photo, re-pinning it so a later
    /// Vary applies the NEW pattern. Mirrors `reSampleCell` but keeps `variantPatternRefs` in sync.
    func reSampleVariantCell(project pid: UUID, creative cid: UUID, index: Int) {
        guard let c = creative(cid, in: pid), c.isVariant,
              let project = projects.first(where: { $0.id == pid }) else { return }
        let pool = project.product.imageFilenames
        guard !pool.isEmpty else { return }
        let cells = max(1, c.sampleCols * c.sampleRows)
        guard index >= 0, index < cells else { return }
        var refs = (0..<cells).map { c.sampleRefs.indices.contains($0) ? c.sampleRefs[$0] : (pool.randomElement() ?? pool[0]) }
        var pats = (0..<cells).map { c.variantPatternRefs.indices.contains($0) ? c.variantPatternRefs[$0] : refs[$0] }
        var offs = (0..<cells).map { c.sampleOffsets.indices.contains($0) ? c.sampleOffsets[$0] : .zero }
        let candidates = pool.count > 1 ? pool.filter { $0 != pats[index] } : pool
        guard let pick = candidates.randomElement() else { return }
        refs[index] = pick; pats[index] = pick; offs[index] = .zero   // show + pin the new pattern, centered
        mutateCreative(project: pid, creative: cid) {
            $0.sampleRefs = refs; $0.variantPatternRefs = pats; $0.sampleOffsets = offs
        }
        let ratioSize = c.ratio.size, cols = c.sampleCols, rows = c.sampleRows
        rebuildingGrids.insert(cid)
        Task { [weak self] in
            await self?.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize, filenames: refs,
                                        cols: cols, rows: rows, reuseRefs: refs, offsets: offs)
            self?.rebuildingGrids.remove(cid)
        }
    }

    /// The Vary prompt, framed as a LOCALIZED EDIT so the anchor scene is preserved exactly while only
    /// the blanket's pattern is swapped. PHOTO 1 = the anchor cell (master scene to keep pixel-stable);
    /// PHOTO 2 = the cell's own pinned pattern (the new surface to apply). Anchor goes FIRST because
    /// multi-reference models lock onto the first image as the base — which is what we want for the
    /// scene. The hard part is forcing the swap (an earlier weaker prompt let the model keep the anchor's
    /// own pattern), so the language is aggressive: "re-skin", "fully replacing", "change nothing else".
    /// `fidelity: nil` — the canned single-product lock is ambiguous with two photos.
    static let variantVaryPrompt = """
    PHOTO 1 shows a real textile product — a bed throw/blanket with a specific woven/printed pattern. \
    PHOTO 2 shows a bedroom scene.
    Re-stage the EXACT product from PHOTO 1 — keeping its pattern, motif, colors, scale, weave and \
    tassels 100% identical — draped over the bed in PHOTO 2's scene.
    CAMERA & FRAMING ARE CRITICAL: match PHOTO 2 exactly — the SAME wide camera distance, angle and \
    crop, pulled back to show the WHOLE bed inside the room (headboard, pillows, both nightstands, \
    floor, rug and the surroundings) just like PHOTO 2. The blanket must occupy the SAME small fraction \
    of the frame as the blanket does in PHOTO 2. Do NOT zoom in, do NOT crop close, do NOT fill the \
    frame with the blanket — the blanket is only one element of a full bedroom photo.
    From PHOTO 2 copy ONLY the room, staging, camera and lighting — NEVER copy or blend PHOTO 2's own \
    blanket pattern. The blanket in the result must show PHOTO 1's pattern exactly, never PHOTO 2's.
    Photorealistic. Reserve calm negative space for text. No text, captions, watermarks, arrows or borders.
    """

    /// Change the number of split pairs/rows (columns stay locked at 2). Existing dropped photos in
    /// surviving cells are preserved; column labels (+ arrows for Before/After) are re-seeded.
    func setSplitRows(project pid: UUID, creative cid: UUID, rows: Int) {
        guard let c = creative(cid, in: pid), c.isSplit else { return }
        let r = Self.splitRowsClamp(rows, type: c.type)
        guard c.sampleRows != r else { return }
        let cells = Self.splitCells(rows: r)
        let labels = splitLabels(for: c, pid: pid)
        let withArrows = c.type == .beforeAfter
        let type = c.type
        let pool = projects.first(where: { $0.id == pid })?.product.imageFilenames ?? []
        mutateCreative(project: pid, creative: cid) { cr in
            let refs = cr.sampleRefs, offs = cr.sampleOffsets, prompts = cr.psProblemPrompts
            cr.sampleCols = 2; cr.sampleRows = r
            // Preserve existing cells; seed any new (empty) right-column cell with a random input photo.
            cr.sampleRefs = Self.splitSeedRefs(cells: cells, rows: r, pool: pool, existing: refs)
            cr.sampleOffsets = (0..<cells).map { i in offs.indices.contains(i) ? offs[i] : .zero }
            if type == .problemSolution {
                cr.psProblemPrompts = (0..<cells).map { i in prompts.indices.contains(i) ? prompts[i] : "" }
            }
            Self.removeSplitLabels(&cr)
            Self.seedSplitLabels(&cr, rows: r, left: labels.left, right: labels.right, type: type)
            Self.removeBeforeAfterArrows(&cr)
            if withArrows { Self.seedBeforeAfterArrows(&cr, rows: r) }
        }
        let ratioSize = c.ratio.size
        rebuildingGrids.insert(cid)
        Task { [weak self] in
            await self?.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratioSize)
            self?.rebuildingGrids.remove(cid)
        }
    }

    /// Update a split layout's editable column labels and re-render the on-image label layers. A blank
    /// field falls back to the mode/language default so the columns are never unlabelled.
    func setSplitLabels(project pid: UUID, creative cid: UUID, left: String, right: String) {
        guard let c = creative(cid, in: pid), c.isSplit else { return }
        let d = splitDefaultLabels(pid: pid, type: c.type)
        let l = left.trimmingCharacters(in: .whitespacesAndNewlines)
        let r = right.trimmingCharacters(in: .whitespacesAndNewlines)
        let lab = (left: l.isEmpty ? d.left : l, right: r.isEmpty ? d.right : r)
        let rows = Self.splitRowsClamp(c.sampleRows, type: c.type)
        let type = c.type
        mutateCreative(project: pid, creative: cid) { cr in
            cr.splitLeftLabel = lab.left; cr.splitRightLabel = lab.right
            Self.removeSplitLabels(&cr)
            Self.seedSplitLabels(&cr, rows: rows, left: lab.left, right: lab.right, type: type)
        }
        let ratioSize = c.ratio.size
        Task { [weak self] in await self?.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratioSize) }
    }

    /// Drop a real photo into one Before/After cell (col 0 = Before, col 1 = After). The image is saved
    /// as a project reference so it survives reload, then the grid is recomposed with it in place.
    /// Replace ONE cell's photo with a user-dropped image and recompose the grid in place. Works for
    /// both split grids (Before/After, Comparison) and regular sample grids (2×2, 3×3, …); only the
    /// dropped cell changes, every other cell's photo + pan offset is preserved. Mirrors the per-cell
    /// recompose path of `adjustCellImage` so a drop never replaces the whole creative with one image.
    func setCellImage(project pid: UUID, creative cid: UUID, index: Int, image: NSImage) {
        guard let c = creative(cid, in: pid), c.imageIsPlaceholder else { return }
        let cells = c.isSplit ? Self.splitCells(rows: c.sampleRows) : max(1, c.sampleCols * c.sampleRows)
        guard index >= 0, index < cells else { return }
        guard let data = image.pngData(), let name = store.saveReferenceImage(data, projectID: pid, index: index) else {
            showToast("Couldn't read that image.", isError: true); return
        }
        let isSplit = c.isSplit, ratioSize = c.ratio.size, cols = c.sampleCols, rows = c.sampleRows
        let pool = projects.first(where: { $0.id == pid })?.product.imageFilenames
        var newRefs: [String] = [], newOffs: [CGPoint] = []
        mutateCreative(project: pid, creative: cid) { cr in
            let oldRefs = cr.sampleRefs, oldOffs = cr.sampleOffsets
            var refs = (0..<cells).map { i in oldRefs.indices.contains(i) ? oldRefs[i] : "" }
            var offs = (0..<cells).map { i in oldOffs.indices.contains(i) ? oldOffs[i] : .zero }
            refs[index] = name; offs[index] = .zero   // new photo → start centered
            cr.sampleRefs = refs; cr.sampleOffsets = offs
            newRefs = refs; newOffs = offs
        }
        rebuildingGrids.insert(cid)
        Task { [weak self] in
            if isSplit {
                await self?.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratioSize)
            } else {
                await self?.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize,
                                            filenames: pool ?? newRefs, cols: cols, rows: rows,
                                            reuseRefs: newRefs, offsets: newOffs)
            }
            self?.rebuildingGrids.remove(cid)
        }
    }

    /// True while a given Before/After cell is having its Before generated by AI.
    func isGeneratingCell(_ cid: UUID, index: Int) -> Bool { baGeneratingCells.contains(CellRef(cid, index)) }

    /// True while a given grid/split cell is being edited by AI ("Edit with AI").
    func isEditingCell(_ cid: UUID, index: Int) -> Bool { aiEditingCells.contains(CellRef(cid, index)) }

    /// True while a given variant-grid cell is being re-rendered to match the anchor cell ("Vary").
    func isVaryingCell(_ cid: UUID, index: Int) -> Bool { varyingCells.contains(CellRef(cid, index)) }

    /// Overlay label for a busy cell (AI generate, AI edit, or Vary), or nil when the cell is idle.
    func cellBusyLabel(_ cid: UUID, index: Int) -> String? {
        if isGeneratingCell(cid, index: index) { return "Generating…" }
        if isEditingCell(cid, index: index) { return "AI editing…" }
        if isVaryingCell(cid, index: index) { return "Varying…" }
        return nil
    }

    /// True while a whole single image (generated/imported) is being edited by AI.
    func isEditingImage(_ cid: UUID) -> Bool { aiEditingImages.contains(cid) }

    /// AI-generate the BEFORE photo for a Before/After row from its AFTER photo: edit the After image
    /// (product removed, same room / angle / lighting / framing) and drop the result into the row's
    /// left cell. `afterIndex` must be a right-column (After) cell that already holds a photo.
    func generateBeforeFromAfter(project pid: UUID, creative cid: UUID, afterIndex: Int, note: String = "") {
        guard let c = creative(cid, in: pid), c.isBeforeAfter else { return }
        let cols = 2, rows = max(2, min(4, c.sampleRows)), cells = cols * rows
        guard afterIndex >= 0, afterIndex < cells, afterIndex % cols == 1 else { return }   // must be an After cell
        let beforeIndex = afterIndex - 1
        guard c.sampleRefs.indices.contains(afterIndex), !c.sampleRefs[afterIndex].isEmpty,
              let afterData = store.referenceImageData(projectID: pid, filenames: [c.sampleRefs[afterIndex]]).first else {
            showToast("Add an After photo to this cell first.", isError: true); return
        }
        guard let provider = anyImageProvider() else {
            showToast("Add an OpenAI or Gemini API key in Settings (⌘,) first.", isError: true); return
        }
        let key = CellRef(cid, beforeIndex)
        guard !baGeneratingCells.contains(key) else { return }   // already in flight
        baGeneratingCells.insert(key)

        let product = projects.first(where: { $0.id == pid })?.product.name.trimmingCharacters(in: .whitespaces) ?? ""
        let subject = product.isEmpty ? "the advertised product" : product
        // An optional user note steers what the empty "before" scene should look like (e.g. "messy
        // room", "old worn rug instead"). Appended as an explicit instruction the model must follow.
        let trimmedNote = note.trimmingCharacters(in: .whitespacesAndNewlines)
        let noteLine = trimmedNote.isEmpty ? "" :
            "\n\nUSER NOTE (follow this for the BEFORE scene): \(trimmedNote)"
        let prompt = """
        You are given the AFTER image of a before/after comparison. Create the BEFORE image: the SAME \
        room and scene, SAME camera angle and lens, SAME furniture and layout, SAME lighting and SAME \
        framing — but with \(subject) removed, showing the space in its plain original state before \
        \(subject) was added (e.g. a bare bed with only a plain fitted sheet, or the empty surface). \
        Change nothing else. Photorealistic, identical perspective. No text, no watermark, no arrows.\(noteLine)
        """
        // Match the After's aspect so both cells crop identically in the grid.
        let target: CGSize = NSImage(data: afterData).map { CGSize(width: max(1, $0.pixelWidth), height: max(1, $0.pixelHeight)) }
            ?? c.ratio.size
        let ratioSize = c.ratio.size

        Task { [weak self] in
            defer { self?.baGeneratingCells.remove(key) }
            do {
                let png = try await provider.generate(prompt: prompt, references: [afterData], target: target)
                guard let self else { return }
                guard let name = self.store.saveReferenceImage(png, projectID: pid, index: beforeIndex) else {
                    self.showToast("Couldn't save the generated image.", isError: true); return
                }
                // Re-check the row still exists / is before/after, then place + recompose.
                guard let cur = self.creative(cid, in: pid), cur.isBeforeAfter else { return }
                let n = Self.splitCells(rows: cur.sampleRows)
                guard beforeIndex < n else { return }
                self.mutateCreative(project: pid, creative: cid) { cr in
                    var refs = (0..<n).map { i in cr.sampleRefs.indices.contains(i) ? cr.sampleRefs[i] : "" }
                    var offs = (0..<n).map { i in cr.sampleOffsets.indices.contains(i) ? cr.sampleOffsets[i] : .zero }
                    refs[beforeIndex] = name; offs[beforeIndex] = .zero
                    cr.sampleRefs = refs; cr.sampleOffsets = offs
                }
                await self.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratioSize)
                self.showToast("Generated the Before image with AI.")
            } catch {
                self?.showToast("Couldn't generate the Before image: \(error.localizedDescription)", isError: true)
            }
        }
    }

    /// The currently saved Problem prompt for a Problem/Solution row's Solution cell (so the cell menu
    /// can pre-fill the sheet when regenerating). `solutionIndex` is the right-column cell; the prompt
    /// is stored against the Problem cell beside it (`solutionIndex - 1`).
    func problemPrompt(_ cid: UUID, in pid: UUID, solutionIndex: Int) -> String {
        guard let c = creative(cid, in: pid) else { return "" }
        let problemIndex = solutionIndex - 1
        return c.psProblemPrompts.indices.contains(problemIndex) ? c.psProblemPrompts[problemIndex] : ""
    }

    /// AI-generate the PROBLEM photo for a Problem/Solution row from its SOLUTION photo: using the
    /// Solution image as the reference SCENE (same room / angle / lighting), depict the "problem /
    /// before" state the user describes — the SAME setting but WITHOUT the product present — and drop
    /// the result into the row's left (Problem) cell. `solutionIndex` must be a right-column cell that
    /// already holds a real product photo. The user prompt is saved so the cell can be regenerated.
    ///
    /// Unlike a normal reference render this passes `fidelity: nil`: the Problem cell must NOT reproduce
    /// the product (it's the "before" with no solution), so the product-lock suffix is deliberately
    /// omitted and the prompt itself enforces "without our product".
    func generateProblemCell(project pid: UUID, creative cid: UUID, solutionIndex: Int, prompt userPrompt: String) {
        guard let c = creative(cid, in: pid), c.isProblemSolution else { return }
        let cols = 2, rows = Self.splitRowsClamp(c.sampleRows, type: c.type), cells = cols * rows
        guard solutionIndex >= 0, solutionIndex < cells, solutionIndex % cols == 1 else { return }   // must be a Solution cell
        let problemIndex = solutionIndex - 1
        let trimmed = userPrompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            showToast("Describe the problem situation first.", isError: true); return
        }
        guard c.sampleRefs.indices.contains(solutionIndex), !c.sampleRefs[solutionIndex].isEmpty,
              let solutionData = store.referenceImageData(projectID: pid, filenames: [c.sampleRefs[solutionIndex]]).first else {
            showToast("Add a Solution photo to this cell first.", isError: true); return
        }
        guard let provider = anyImageProvider() else {
            showToast("Add an OpenAI or Gemini API key in Settings (⌘,) first.", isError: true); return
        }
        let key = CellRef(cid, problemIndex)
        guard !baGeneratingCells.contains(key) else { return }   // already in flight
        baGeneratingCells.insert(key)

        let prompt = Self.problemScenePrompt(trimmed)
        // Match the Solution's aspect so both cells crop identically in the grid.
        let target: CGSize = NSImage(data: solutionData).map { CGSize(width: max(1, $0.pixelWidth), height: max(1, $0.pixelHeight)) }
            ?? c.ratio.size
        let ratioSize = c.ratio.size

        Task { [weak self] in
            defer { self?.baGeneratingCells.remove(key) }
            do {
                // fidelity: nil — the Problem scene must NOT reproduce the product (it's the "before").
                let png = try await provider.generate(prompt: prompt, references: [solutionData],
                                                      target: target, fidelity: nil)
                guard let self else { return }
                guard let name = self.store.saveReferenceImage(png, projectID: pid, index: problemIndex) else {
                    self.showToast("Couldn't save the generated image.", isError: true); return
                }
                guard let cur = self.creative(cid, in: pid), cur.isProblemSolution else { return }
                let n = Self.splitCells(rows: cur.sampleRows)
                guard problemIndex < n else { return }
                self.mutateCreative(project: pid, creative: cid) { cr in
                    var refs = (0..<n).map { i in cr.sampleRefs.indices.contains(i) ? cr.sampleRefs[i] : "" }
                    var offs = (0..<n).map { i in cr.sampleOffsets.indices.contains(i) ? cr.sampleOffsets[i] : .zero }
                    var prompts = (0..<n).map { i in cr.psProblemPrompts.indices.contains(i) ? cr.psProblemPrompts[i] : "" }
                    refs[problemIndex] = name; offs[problemIndex] = .zero
                    prompts[problemIndex] = trimmed
                    cr.sampleRefs = refs; cr.sampleOffsets = offs; cr.psProblemPrompts = prompts
                }
                await self.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratioSize)
                self.showToast("Generated the Problem scene with AI.")
            } catch {
                self?.showToast("Couldn't generate the Problem image: \(error.localizedDescription)", isError: true)
            }
        }
    }

    /// Prompt for the AI Problem scene of a Problem/Solution row. Reference 1 = the Solution photo,
    /// used ONLY for the room/scene/angle/lighting so the pair reads as the same place. The user's
    /// description drives WHICH problem to show; the product is deliberately absent ("before" state).
    static func problemScenePrompt(_ userPrompt: String) -> String {
        """
        Using reference image 1 as the SAME room/scene/context, camera angle and lighting, depict the \
        "before / problem" state: \(userPrompt).
        Show the pain/problem clearly and realistically, in the SAME setting as image 1 but WITHOUT our \
        finished product/solution present. Tasteful and believable, not exaggerated or gross. Reserve \
        calm negative space for text. Write NO text, captions, watermarks, arrows or borders.
        """
    }

    /// "Edit with AI" for ONE grid/split cell: send the cell's current photo + the user's instruction
    /// to the image backend, save the edited result as the cell's new reference photo, and recompose
    /// the grid. Works for plain grids and split (Before/After · Comparison) cells alike. Overwrites
    /// the target cell in place (no undo); other cells are untouched.
    func editCellWithAI(project pid: UUID, creative cid: UUID, index: Int, prompt: String) {
        let instruction = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !instruction.isEmpty else { return }
        guard let c = creative(cid, in: pid), c.imageIsPlaceholder else { return }
        let cells = c.isSplit ? Self.splitCells(rows: c.sampleRows) : max(1, c.sampleCols * c.sampleRows)
        guard index >= 0, index < cells else { return }
        guard c.sampleRefs.indices.contains(index), !c.sampleRefs[index].isEmpty,
              let srcData = store.referenceImageData(projectID: pid, filenames: [c.sampleRefs[index]]).first else {
            showToast("This cell has no photo to edit yet.", isError: true); return
        }
        guard let provider = anyImageProvider() else {
            showToast("Add an OpenAI or Gemini API key in Settings (⌘,) first.", isError: true); return
        }
        let key = CellRef(cid, index)
        guard !aiEditingCells.contains(key) else { return }   // already editing this cell
        aiEditingCells.insert(key)

        // Preserve the cell photo's own pixel aspect so the edit drops back in without re-cropping.
        let target: CGSize = NSImage(data: srcData).map { CGSize(width: max(1, $0.pixelWidth), height: max(1, $0.pixelHeight)) }
            ?? c.ratio.size
        let isSplit = c.isSplit
        let ratioSize = c.ratio.size
        let cols = c.sampleCols, rows = c.sampleRows
        let project = projects.first(where: { $0.id == pid })

        Task { [weak self] in
            defer { self?.aiEditingCells.remove(key) }
            do {
                let png = try await provider.editImage(prompt: instruction, image: srcData, target: target)
                guard let self else { return }
                guard let name = self.store.saveReferenceImage(png, projectID: pid, index: index) else {
                    self.showToast("Couldn't save the edited image.", isError: true); return
                }
                guard let cur = self.creative(cid, in: pid), cur.imageIsPlaceholder else { return }
                let n = cur.isSplit ? Self.splitCells(rows: cur.sampleRows) : max(1, cur.sampleCols * cur.sampleRows)
                guard index < n else { return }
                var newRefs: [String] = []
                self.mutateCreative(project: pid, creative: cid) { cr in
                    var refs = (0..<n).map { i in cr.sampleRefs.indices.contains(i) ? cr.sampleRefs[i] : "" }
                    var offs = (0..<n).map { i in cr.sampleOffsets.indices.contains(i) ? cr.sampleOffsets[i] : .zero }
                    refs[index] = name; offs[index] = .zero   // edited photo → start centered
                    cr.sampleRefs = refs; cr.sampleOffsets = offs
                    newRefs = refs
                }
                if isSplit {
                    await self.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratioSize)
                } else {
                    let pool = project?.product.imageFilenames ?? newRefs
                    await self.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize, filenames: pool,
                                               cols: cols, rows: rows, reuseRefs: newRefs)
                }
                self.showToast("Edited the photo with AI.")
            } catch {
                self?.showToast("Couldn't edit the image: \(error.localizedDescription)", isError: true)
            }
        }
    }

    /// "Edit with AI" for a whole single (generated/imported) image: send the current image + the
    /// user's instruction to the backend and overwrite the generated PNG in place. The creative's text
    /// layers are NOT part of the bitmap (they render on top), so they survive untouched.
    func editImageWithAI(project pid: UUID, creative cid: UUID, prompt: String) {
        let instruction = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !instruction.isEmpty else { return }
        guard let c = creative(cid, in: pid), let url = generatedImageURL(for: c, in: pid),
              let srcData = try? Data(contentsOf: url) else {
            showToast("There's no image to edit yet.", isError: true); return
        }
        guard let provider = anyImageProvider() else {
            showToast("Add an OpenAI or Gemini API key in Settings (⌘,) first.", isError: true); return
        }
        guard !aiEditingImages.contains(cid) else { return }   // already editing this image
        aiEditingImages.insert(cid)

        let target: CGSize = NSImage(data: srcData).map { CGSize(width: max(1, $0.pixelWidth), height: max(1, $0.pixelHeight)) }
            ?? c.ratio.size

        Task { [weak self] in
            defer { self?.aiEditingImages.remove(cid) }
            do {
                let png = try await provider.editImage(prompt: instruction, image: srcData, target: target)
                guard let self else { return }
                let name = self.store.saveGeneratedImage(png, projectID: pid, creativeID: cid)
                self.mutateCreative(project: pid, creative: cid) {
                    $0.imageFilename = name
                    $0.imageIsPlaceholder = false   // an AI-edited image is a real single image, not a sample grid
                    $0.imageVersion += 1            // force every view keyed on imageToken to reload the rewritten file
                }
                self.showToast("Edited the image with AI.")
            } catch {
                self?.showToast("Couldn't edit the image: \(error.localizedDescription)", isError: true)
            }
        }
    }

    /// "Adjust" for ONE grid/split cell: bake non-destructive photo adjustments (brightness, shadows,
    /// saturation, clarity) into the cell's reference photo and recompose the grid. Like Edit-with-AI
    /// and Re-sample this replaces the cell's photo in place; the cell's pan offset is preserved (an
    /// adjustment changes tone, not framing). A no-op when the adjustment is neutral.
    func adjustCellImage(project pid: UUID, creative cid: UUID, index: Int, _ adj: ImageAdjustments) {
        guard !adj.isIdentity else { return }
        guard let c = creative(cid, in: pid), c.imageIsPlaceholder else { return }
        let cells = c.isSplit ? Self.splitCells(rows: c.sampleRows) : max(1, c.sampleCols * c.sampleRows)
        guard index >= 0, index < cells else { return }
        guard c.sampleRefs.indices.contains(index), !c.sampleRefs[index].isEmpty,
              let srcData = store.referenceImageData(projectID: pid, filenames: [c.sampleRefs[index]]).first,
              let srcImg = NSImage(data: srcData) else {
            showToast("This cell has no photo to adjust yet.", isError: true); return
        }
        guard let adjusted = ImageAdjust.apply(srcImg, adj), let png = adjusted.pngData(),
              let name = store.saveReferenceImage(png, projectID: pid, index: index) else {
            showToast("Couldn't apply the adjustment.", isError: true); return
        }
        let isSplit = c.isSplit, ratioSize = c.ratio.size, cols = c.sampleCols, rows = c.sampleRows
        let pool = projects.first(where: { $0.id == pid })?.product.imageFilenames
        // Keep ALL pan offsets, including this cell's — adjusting tone must not re-center the photo.
        let offs = (0..<cells).map { i in c.sampleOffsets.indices.contains(i) ? c.sampleOffsets[i] : .zero }
        var newRefs: [String] = []
        mutateCreative(project: pid, creative: cid) { cr in
            var refs = (0..<cells).map { i in cr.sampleRefs.indices.contains(i) ? cr.sampleRefs[i] : "" }
            refs[index] = name
            cr.sampleRefs = refs; cr.sampleOffsets = offs
            newRefs = refs
        }
        rebuildingGrids.insert(cid)
        Task { [weak self] in
            if isSplit {
                await self?.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratioSize)
            } else {
                await self?.buildSampleGrid(pid: pid, cid: cid, ratioSize: ratioSize,
                                            filenames: pool ?? newRefs, cols: cols, rows: rows,
                                            reuseRefs: newRefs, offsets: offs)
            }
            self?.rebuildingGrids.remove(cid)
        }
    }

    /// Re-roll one split-grid right-column cell (the After / "ours" side) with a different random photo
    /// from the project's input pool, avoiding the current one when alternatives exist. Mirrors
    /// `reSampleCell` for the grid; only the right column re-samples (left cells are user-dropped).
    func reSampleAfterCell(project pid: UUID, creative cid: UUID, index: Int) {
        guard let c = creative(cid, in: pid), c.isSplit,
              let project = projects.first(where: { $0.id == pid }) else { return }
        let cells = Self.splitCells(rows: c.sampleRows)
        guard index >= 0, index < cells, index % 2 == 1 else { return }   // must be an After cell
        let pool = project.product.imageFilenames
        guard !pool.isEmpty else { return }
        let current = c.sampleRefs.indices.contains(index) ? c.sampleRefs[index] : ""
        let candidates = pool.count > 1 ? pool.filter { $0 != current } : pool
        guard let pick = candidates.randomElement() else { return }
        mutateCreative(project: pid, creative: cid) { cr in
            var refs = (0..<cells).map { i in cr.sampleRefs.indices.contains(i) ? cr.sampleRefs[i] : "" }
            var offs = (0..<cells).map { i in cr.sampleOffsets.indices.contains(i) ? cr.sampleOffsets[i] : .zero }
            refs[index] = pick; offs[index] = .zero   // new photo → start centered
            cr.sampleRefs = refs; cr.sampleOffsets = offs
        }
        let ratioSize = c.ratio.size
        Task { [weak self] in await self?.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratioSize) }
    }

    /// Clear one Before/After cell back to empty (the divider/labels stay; user can re-drop).
    func clearCellImage(project pid: UUID, creative cid: UUID, index: Int) {
        guard let c = creative(cid, in: pid), c.isSplit else { return }
        let cells = Self.splitCells(rows: c.sampleRows)
        guard index >= 0, index < cells, c.sampleRefs.indices.contains(index), !c.sampleRefs[index].isEmpty else { return }
        mutateCreative(project: pid, creative: cid) {
            var refs = $0.sampleRefs; var offs = $0.sampleOffsets
            refs[index] = ""
            if offs.indices.contains(index) { offs[index] = .zero }
            $0.sampleRefs = refs; $0.sampleOffsets = offs
        }
        let ratioSize = c.ratio.size
        Task { [weak self] in await self?.buildSplitGrid(pid: pid, cid: cid, ratioSize: ratioSize) }
    }

    /// Compose + persist a split grid (2 × `sampleRows`, Before/After or Comparison) from the
    /// creative's own per-cell dropped photos. Empty cells stay blank; the composer draws the
    /// vertical/row seams. Unlike `buildSampleGrid` this never random-picks — cell order is exactly
    /// `sampleRefs` so each left|right pair is fixed.
    private func buildSplitGrid(pid: UUID, cid: UUID, ratioSize: CGSize) async {
        guard let c = creative(cid, in: pid), c.isSplit else { return }
        let cols = 2, rows = Self.splitRowsClamp(c.sampleRows, type: c.type), cells = cols * rows
        let refs = (0..<cells).map { c.sampleRefs.indices.contains($0) ? c.sampleRefs[$0] : "" }
        let offs = (0..<cells).map { c.sampleOffsets.indices.contains($0) ? c.sampleOffsets[$0] : .zero }
        // Load each filled cell aligned to its index (empty → nil), so the composite keeps cell order.
        let datas: [Data?] = refs.map { $0.isEmpty ? nil : store.referenceImageData(projectID: pid, filenames: [$0]).first }
        let rs = GridComposer.highResSize(ratioSize)
        let png: Data? = await Task.detached {
            let imgs: [NSImage?] = datas.map { d in d.flatMap { NSImage(data: $0) } }
            let gap: CGFloat = max(8, (rs.width * 0.006).rounded())
            return GridComposer.compose(imgs, size: rs, gap: gap, cols: cols, rows: rows,
                                        offsets: offs, split: true)?.pngData()
        }.value
        guard let png else { return }
        let name = self.store.saveGeneratedImage(png, projectID: pid, creativeID: cid)
        self.mutateCreative(project: pid, creative: cid) {
            $0.imageFilename = name; $0.imageIsPlaceholder = true
            $0.sampleCols = cols; $0.sampleRows = rows
            $0.sampleRefs = refs; $0.sampleOffsets = offs
            $0.imageVersion += 1
        }
    }

    // MARK: Split column labels (seeded as ordinary text layers so they render + export + stay editable)

    /// Default column labels for a split mode, localized to the project's content language. This is AD
    /// CONTENT (rendered onto the exported image), so it follows the content-language setting.
    private func splitDefaultLabels(pid: UUID, type: AdType) -> (left: String, right: String) {
        let lang = (projects.first { $0.id == pid }?.product.contentLanguage ?? "English").lowercased()
        let vn = lang.contains("viet") || lang.contains("việt")
        switch type {
        case .comparison:
            return vn ? ("Phổ thông trên thị trường", "Cao cấp bên mình")
                      : ("Common on the market", "Premium — ours")
        case .problemSolution:
            return vn ? ("Vấn đề", "Giải pháp") : ("Problem", "Solution")
        default:   // beforeAfter
            return vn ? ("Trước", "Sau") : ("Before", "After")
        }
    }

    /// Resolve a creative's split labels: its stored (editable) labels, falling back to the defaults.
    private func splitLabels(for c: Creative, pid: UUID) -> (left: String, right: String) {
        let d = splitDefaultLabels(pid: pid, type: c.type)
        let l = c.splitLeftLabel.trimmingCharacters(in: .whitespacesAndNewlines)
        let r = c.splitRightLabel.trimmingCharacters(in: .whitespacesAndNewlines)
        return (l.isEmpty ? d.left : l, r.isEmpty ? d.right : r)
    }

    /// Seed two small column labels per row, positioned at each row's top-left / top-right. Tagged
    /// `isSplitLabel` so they're removed cleanly on type/row/label change even after the user edits them.
    private static func seedSplitLabels(_ c: inout Creative, rows: Int, left: String, right: String, type: AdType) {
        let r = splitRowsClamp(rows, type: type)
        let rowH = 1.0 / Double(r)
        // Comparison labels are longer phrases → smaller font + wider box so they don't clip.
        let font: Double = type == .comparison ? 22 : 30
        let widthFrac: Double = type == .comparison ? 0.45 : 0.42
        var labels: [TextLayer] = []
        for row in 0..<r {
            let yTop = Double(row) * rowH + rowH * 0.04   // small inset below the row's top edge
            labels.append(splitLabel(text: left, xFrac: 0.035, yFrac: yTop, widthFrac: widthFrac, fontSize: font))
            labels.append(splitLabel(text: right, xFrac: 0.515, yFrac: yTop, widthFrac: widthFrac, fontSize: font))
        }
        // Keep any user layers first; append the labels so they sit on top.
        c.textLayers.append(contentsOf: labels)
    }

    /// Remove the auto-seeded split labels. Matches the `isSplitLabel` tag, plus the legacy known-text
    /// set so Before/After projects saved before the tag existed still get cleaned up.
    private static let legacySplitLabelTexts: Set<String> = ["Trước", "Sau", "Before", "After"]
    private static func removeSplitLabels(_ c: inout Creative) {
        c.textLayers.removeAll { $0.isSplitLabel || legacySplitLabelTexts.contains($0.text) }
    }

    /// A small, tasteful column label (white text on a soft dark scrim) — not a big banner.
    private static func splitLabel(text: String, xFrac: Double, yFrac: Double, widthFrac: Double, fontSize: Double) -> TextLayer {
        var l = TextLayer(text: text, xFrac: xFrac, yFrac: yFrac, widthFrac: widthFrac, fontSize: fontSize, alignment: "leading")
        l.apply(style: .boldBlock)
        l.isSplitLabel = true
        return l
    }

    /// Seed one arrow layer per row, centred on the Before→After seam at the row's vertical centre.
    /// Arrows are ordinary (image) text layers, so they move/resize/delete like any block afterwards.
    private static func seedBeforeAfterArrows(_ c: inout Creative, rows: Int) {
        let r = max(2, min(4, rows))
        let canvasH = Double(c.ratio.size.height)        // 1280 (4:5) or 1024 (1:1)
        let font: Double = 28
        let wFrac = (font * Double(HookText.arrowWidthPerFont)) / 1024.0
        let hFrac = (font * Double(HookText.arrowWidthPerFont) * Double(HookText.arrowAspect)) / canvasH
        var arrows: [TextLayer] = []
        for row in 0..<r {
            let rowCenter = (Double(row) + 0.5) / Double(r)
            var l = TextLayer(text: "")
            l.isArrow = true
            l.fontSize = font
            l.xFrac = max(0, 0.5 - wFrac / 2)
            l.yFrac = max(0, rowCenter - hFrac / 2)
            arrows.append(l)
        }
        c.textLayers.append(contentsOf: arrows)
    }

    private static func removeBeforeAfterArrows(_ c: inout Creative) {
        c.textLayers.removeAll { $0.isArrow }
    }

    func selectImagePrompt(project pid: UUID, creative cid: UUID, index: Int) {
        mutateCreative(project: pid, creative: cid) { if $0.imagePrompts.indices.contains(index) { $0.selImagePrompt = index } }
    }

    func isRegeneratingImagePrompts(_ cid: UUID) -> Bool { rewriting.contains("\(cid.uuidString):imagePrompts") }

    /// Regenerate a copy field. `.hook` → one fresh line; `.headline`/`.primaryText` → 4 fresh variants.
    func regenerateCopy(project pid: UUID, creative cid: UUID, field: CopyField, instruction: String) {
        guard settings.hasOpenAIKey else {
            showToast("Add your OpenAI API key in Settings (⌘,) first.", isError: true); return
        }
        guard let product = projects.first(where: { $0.id == pid })?.product,
              let (persona, creative) = locate(project: pid, creative: cid) else { return }
        if !instruction.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            recordMemory(project: pid, note: "\(field.label.capitalized) feedback: \(instruction)")
        }
        let key = rewriteKey(cid, field)
        rewriting.insert(key)
        let client = makeStrategyClient(language: product.contentLanguage, projectMemory: memoryForPrompt(pid))
        Task { [weak self] in
            guard let self else { return }
            defer { self.rewriting.remove(key) }
            do {
                let variants = try await client.copyVariants(field: field, count: 4, instruction: instruction,
                                                             product: product, persona: persona, creative: creative)
                self.mutateCreative(project: pid, creative: cid) {
                    switch field {
                    case .headline: $0.headlines = variants; $0.selHeadline = 0
                    case .primaryText: $0.primaryTexts = variants; $0.selPrimaryText = 0
                    case .hook:
                        let oldHook = $0.hook
                        $0.hooks = variants; $0.selHook = 0; $0.highlights = []
                        let newHook = $0.hook
                        for i in $0.textLayers.indices where $0.textLayers[i].text == oldHook {
                            $0.textLayers[i].text = newHook
                            $0.textLayers[i].highlightWord = ""
                        }
                    }
                }
                self.showToast("\(field.label.capitalized): \(variants.count) new options")
            } catch {
                let msg = (error as? APIError)?.errorDescription ?? error.localizedDescription
                self.showToast(msg, isError: true)
            }
        }
    }

    /// Regenerate 4 fresh image-prompt variants to choose from.
    func regenerateImagePromptVariants(project pid: UUID, creative cid: UUID, instruction: String) {
        guard settings.hasOpenAIKey else {
            showToast("Add your OpenAI API key in Settings (⌘,) first.", isError: true); return
        }
        guard let product = projects.first(where: { $0.id == pid })?.product,
              let (persona, creative) = locate(project: pid, creative: cid) else { return }
        if !instruction.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            recordMemory(project: pid, note: "Image-prompt feedback: \(instruction)")
        }
        let key = "\(cid.uuidString):imagePrompts"
        rewriting.insert(key)
        let client = makeStrategyClient(language: product.contentLanguage, projectMemory: memoryForPrompt(pid))
        Task { [weak self] in
            guard let self else { return }
            defer { self.rewriting.remove(key) }
            do {
                let variants = try await client.imagePromptVariants(count: 4, instruction: instruction,
                                                                    product: product, persona: persona, creative: creative)
                self.mutateCreative(project: pid, creative: cid) { $0.imagePrompts = variants; $0.selImagePrompt = 0 }
                self.showToast("Image prompt: \(variants.count) new options")
            } catch {
                let msg = (error as? APIError)?.errorDescription ?? error.localizedDescription
                self.showToast(msg, isError: true)
            }
        }
    }

    /// Regenerate the image; an optional instruction is appended to the image prompt before generating.
    func regenerateImage(project pid: UUID, persona personaID: UUID, creative cid: UUID, instruction: String) {
        let trimmed = instruction.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty {
            mutateCreative(project: pid, creative: cid) {
                // Replace a previous adjustment block rather than stacking them.
                var base = $0.imagePrompt
                if let r = base.range(of: "\n\nAdjustment:") { base = String(base[..<r.lowerBound]) }
                $0.imagePrompt = base + "\n\nAdjustment: \(trimmed)"
            }
            recordMemory(project: pid, note: "Image adjustment: \(trimmed)")
        }
        generateOne(project: pid, persona: personaID, creative: cid)
    }

    /// Render the ad (base + text layers) to a bitmap. The ONLY rasterizer — both the on-screen
    /// preview and the exported file go through this, so they're identical. `scale` controls
    /// resolution: export uses 2× for crisp output; the on-screen preview uses 1× (the card/inspector
    /// are small, and 1024px is plenty) which is 4× cheaper per composite.
    private func renderAd(_ c: Creative, in pid: UUID, scale: CGFloat = 2) -> CGImage? {
        guard let base = generatedImage(for: c, in: pid) else { return nil }
        return renderComposite(c, base: base, size: c.ratio.size, scale: scale)
    }

    /// Rasterize `base` + the creative's text layers at `size`, scaled by `scale`. Text positions
    /// (fractions) and font sizes (scaled by size.width/1024) track `size`, so any canvas works.
    private func renderComposite(_ c: Creative, base: NSImage, size: CGSize, scale: CGFloat) -> CGImage? {
        // Apply non-destructive photo adjustments to the base before compositing text — so the on-screen
        // preview, the clipboard copy and the exported file all reflect them identically.
        let adjBase = c.adjustments.isIdentity ? base : (ImageAdjust.apply(base, c.adjustments) ?? base)
        let renderer = ImageRenderer(content: AdCanvas(baseImage: adjBase, layers: c.textLayers, size: size))
        renderer.scale = scale
        return renderer.cgImage
    }

    // Adjusted-base cache for the no-text display path (keyed by imageToken, which includes the
    // adjustments) so scrolling/selection don't re-run Core Image every frame.
    private var adjustedBaseCache: [UUID: (token: Int, image: NSImage)] = [:]
    private func adjustedBaseCached(_ raw: NSImage?, for c: Creative) -> NSImage? {
        guard let raw else { return nil }
        guard !c.adjustments.isIdentity else { return raw }
        let token = c.imageToken
        if let hit = adjustedBaseCache[c.id], hit.token == token { return hit.image }
        let out = ImageAdjust.apply(raw, c.adjustments) ?? raw
        adjustedBaseCache[c.id] = (token, out)
        return out
    }

    /// True when the creative has at least one non-empty text layer worth compositing.
    private func hasVisibleText(_ c: Creative) -> Bool {
        c.textLayers.contains { $0.isArrow || !CopyText.clean($0.text).isEmpty }
    }

    // Cache of rendered preview bitmaps, invalidated when the image/layers/ratio change.
    private var previewCache: [UUID: (sig: Int, image: NSImage)] = [:]

    private func previewSignature(_ c: Creative) -> Int {
        var hasher = Hasher()
        // Composite identity = base-bitmap identity (imageToken) + the text baked on top.
        hasher.combine(c.imageToken); hasher.combine(c.textLayers)
        return hasher.finalize()
    }

    /// The exact rendered ad bitmap for on-screen display. Skips the composite entirely when there's
    /// no text to draw (the bitmap would just equal the base image), which is the common case for
    /// sample grids and freshly generated cards — that's what made project/persona switches stutter.
    func previewImage(for c: Creative, in pid: UUID) -> NSImage? {
        guard hasVisibleText(c) else { return adjustedBaseCached(generatedImage(for: c, in: pid), for: c) }
        let sig = previewSignature(c)
        if let cached = previewCache[c.id], cached.sig == sig { return cached.image }
        guard let cg = renderAd(c, in: pid, scale: 1) else { return nil }
        let img = NSImage(cgImage: cg, size: c.ratio.size)
        previewCache[c.id] = (sig, img)
        return img
    }

    /// Async display image for a creative — composites text when `showText`, otherwise the bare
    /// base image. Called from view `.task`s so the disk read / `ImageRenderer` composite happens
    /// off SwiftUI's synchronous `body`/layout pass and the grid scrolls smoothly.
    func displayImage(for c: Creative, in pid: UUID, showText: Bool) async -> NSImage? {
        // No text to bake → just the base image (no ImageRenderer). Covers sample grids & idle cards.
        guard showText, hasVisibleText(c) else {
            guard let url = generatedImageURL(for: c, in: pid) else { return nil }
            return adjustedBaseCached(await ImageStore.shared.load(url), for: c)
        }
        // Fast path: a cache hit returns instantly without re-rendering.
        if let cached = previewCache[c.id], cached.sig == previewSignature(c) { return cached.image }
        // Warm the base image off-main first so the @MainActor render below doesn't block on I/O.
        if let url = generatedImageURL(for: c, in: pid) { _ = await ImageStore.shared.load(url) }
        return previewImage(for: c, in: pid)
    }

    /// The cached composited preview if it's already rendered — used to show the right bitmap
    /// instantly on switch without kicking off a render.
    func cachedPreview(for c: Creative) -> NSImage? {
        guard hasVisibleText(c), let cached = previewCache[c.id], cached.sig == previewSignature(c)
        else { return nil }
        return cached.image
    }

    /// Composite NSImage (for clipboard). Nil if no image yet.
    func compositedImage(project pid: UUID, creative cid: UUID) -> NSImage? {
        guard let c = creative(cid, in: pid), let cg = renderAd(c, in: pid) else { return nil }
        return NSImage(cgImage: cg, size: c.ratio.size)
    }

    /// Max-quality JPEG for saving/exporting — built WITHOUT blocking the UI on the heavy steps.
    /// • Placeholder sample grids → recompose from the original item photos at native cell resolution
    ///   (no downscaling of the small images) and render 1:1.
    /// • Generated/imported creatives → render at 4× (≈4096×5120) for maximum detail.
    ///
    /// Only the (comparatively cheap) `ImageRenderer` rasterization touches the main actor; the
    /// reference decode + grid compose and the JPEG encode (the expensive parts at 4096px) run
    /// off-main, so Save/Export never freezes the window.
    func compositedJPEG(project pid: UUID, creative cid: UUID, quality: CGFloat = 1.0) async -> Data? {
        guard let c = creative(cid, in: pid) else { return nil }
        // Off-main: recompose the hi-fi sample base from the original item photos (placeholder only).
        var hiFiBase: NSImage?
        if c.imageIsPlaceholder, !c.sampleRefs.isEmpty {
            let refs = c.sampleRefs, ratio = c.ratio.size, cols = c.sampleCols, rows = c.sampleRows
            let offsets = c.sampleOffsets   // keep the export's per-cell crop matching the panned preview
            let split = c.isSplit
            // Load aligned to cells so empty split cells stay nil (not collapsed away).
            let datas: [Data?] = refs.map { $0.isEmpty ? nil : store.referenceImageData(projectID: pid, filenames: [$0]).first }
            hiFiBase = await Task.detached {
                let imgs: [NSImage?] = datas.map { d in d.flatMap { NSImage(data: $0) } }
                let present = imgs.compactMap { $0 }
                guard !present.isEmpty else { return nil as NSImage? }
                let size = GridComposer.highFidelitySize(for: present, ratio: ratio, cols: cols, rows: rows)
                let gap: CGFloat = split ? max(8, (size.width * 0.006).rounded()) : 12
                return GridComposer.compose(imgs, size: size, gap: gap, cols: cols, rows: rows,
                                            offsets: offsets, split: split)
            }.value
        }
        // Main actor: rasterize the composite (ImageRenderer is @MainActor; this is fast).
        let cg: CGImage?
        if let base = hiFiBase {
            cg = renderComposite(c, base: base, size: CGSize(width: base.size.width, height: base.size.height), scale: 1)
        } else {
            cg = renderAd(c, in: pid, scale: 4)
        }
        guard let cg else { return nil }
        // Off-main: JPEG encode (the expensive step at this resolution).
        return await Task.detached {
            NSBitmapImageRep(cgImage: cg).representation(using: .jpeg, properties: [.compressionFactor: quality])
        }.value
    }

    /// Save the composited image to disk via a save panel (used by the right-click menu and buttons).
    func saveImageToDisk(project pid: UUID, creative cid: UUID) {
        guard let (persona, c) = locate(project: pid, creative: cid), c.imageFilename != nil else {
            showToast("No image to save yet.", isError: true); return
        }
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.jpeg]
        panel.nameFieldStringValue = "\(persona.name.slug)-rank\(c.rank).jpg"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        showToast("Saving image…")
        Task { [weak self] in
            guard let self, let data = await self.compositedJPEG(project: pid, creative: cid) else {
                self?.showToast("Couldn't render image.", isError: true); return
            }
            let ok = await Task.detached { (try? data.write(to: url)) != nil }.value
            self.showToast(ok ? "Saved image" : "Couldn't save image", isError: !ok)
        }
    }

    /// Quick-save: write the composited image straight into the configured Output folder
    /// (no save dialog). Auto-names the file and avoids overwriting existing ones.
    func quickSaveImage(project pid: UUID, creative cid: UUID) {
        guard let (persona, c) = locate(project: pid, creative: cid), c.imageFilename != nil else {
            showToast("No image to save yet.", isError: true); return
        }
        let folder = settings.exportFolder()   // never nil — falls back to Desktop
        let base = "\(persona.name.slug)-rank\(c.rank)"
        showToast("Saving…")
        Task { [weak self] in
            guard let self, let data = await self.compositedJPEG(project: pid, creative: cid) else {
                self?.showToast("Couldn't render image.", isError: true); return
            }
            let saved: String? = await Task.detached {
                let didScope = folder.startAccessingSecurityScopedResource()
                defer { if didScope { folder.stopAccessingSecurityScopedResource() } }
                let fm = FileManager.default
                try? fm.createDirectory(at: folder, withIntermediateDirectories: true)
                var url = folder.appendingPathComponent("\(base).jpg")
                var n = 2
                while fm.fileExists(atPath: url.path) {
                    url = folder.appendingPathComponent("\(base)-\(n).jpg"); n += 1
                }
                return (try? data.write(to: url)) != nil ? url.lastPathComponent : nil
            }.value
            if let saved { self.showToast("Saved to \(folder.lastPathComponent)/\(saved)") }
            else { self.showToast("Couldn't save image", isError: true) }
        }
    }

    /// Copy the composited image to the clipboard.
    func copyImage(project pid: UUID, creative cid: UUID) {
        guard let composited = compositedImage(project: pid, creative: cid) else {
            showToast("No image to copy yet.", isError: true); return
        }
        NSPasteboard.general.clearContents()
        NSPasteboard.general.writeObjects([composited])
        showToast("Image copied")
    }

    func copyToPasteboard(_ text: String, kind: String) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(text, forType: .string)
        showToast("\(kind) copied")
    }

    // MARK: Generation

    private func jobs(for personaID: UUID, in project: Project, onlyNeedsGeneration: Bool) -> [GenerationEngine.Job] {
        guard let persona = project.personas.first(where: { $0.id == personaID }) else { return [] }
        return persona.creatives
            .filter { onlyNeedsGeneration ? $0.status.needsGeneration : true }
            .map { GenerationEngine.Job(projectID: project.id, personaID: personaID, creativeID: $0.id) }
    }

    func generateOne(project pid: UUID, persona personaID: UUID, creative cid: UUID) {
        syncEngine()
        engine.enqueue([GenerationEngine.Job(projectID: pid, personaID: personaID, creativeID: cid)])
    }

    func generatePersona(project pid: UUID, persona personaID: UUID) {
        guard let project = projects.first(where: { $0.id == pid }) else { return }
        syncEngine()
        engine.enqueue(jobs(for: personaID, in: project, onlyNeedsGeneration: true))
    }

    func generateAll() {
        guard let project = selectedProject else { return }
        guard settings.hasImageKey else {
            let need = settings.imageBackend == .nanoBanana ? "Gemini" : "OpenAI"
            showToast("Add your \(need) API key in Settings (⌘,) to generate images.", isError: true)
            return
        }
        syncEngine()
        var all: [GenerationEngine.Job] = []
        for persona in project.personas {
            all += jobs(for: persona.id, in: project, onlyNeedsGeneration: true)
        }
        guard !all.isEmpty else { showToast("All images already generated."); return }
        engine.enqueue(all)
        showToast("Generating \(all.count) images · up to \(settings.concurrency) in parallel")
    }

    func retryAll() {
        guard let project = selectedProject else { return }
        syncEngine()
        var failed: [GenerationEngine.Job] = []
        for persona in project.personas {
            for c in persona.creatives where c.status == .error {
                failed.append(GenerationEngine.Job(projectID: project.id, personaID: persona.id, creativeID: c.id))
            }
        }
        engine.enqueue(failed)
    }

    func cancelBatch() {
        engine.cancelAll()
        showToast("Batch cancelled", isError: true)
    }

    /// Import one user-supplied image (e.g. generated manually in ChatGPT) as a creative's image.
    func importImage(project pid: UUID, persona personaID: UUID, creative cid: UUID, data: Data) {
        guard let img = NSImage(data: data) else {
            showToast("That file isn't a readable image.", isError: true); return
        }
        importImages(project: pid, persona: personaID, creative: cid, images: [img])
    }

    /// Import several images at once: one image is used as-is; multiple are auto-composited into a
    /// square-ish grid (4 → 2×2, 9 → 3×3, …). Always normalised to the 1024×1280 canvas.
    func importImages(project pid: UUID, persona personaID: UUID, creative cid: UUID, images: [NSImage]) {
        guard !images.isEmpty else { return }
        // If a generation is in flight for this creative, stop it first.
        engine.cancelOne(GenerationEngine.Job(projectID: pid, personaID: personaID, creativeID: cid))

        let target = creative(cid, in: pid)?.ratio.size ?? CGSize(width: 1024, height: 1280)
        let png: Data
        var note = "Image imported"
        if images.count == 1 {
            guard let base = images[0].pngData() else { showToast("Couldn't read that image.", isError: true); return }
            png = ImageCrop.normalizeToTarget(base, target: target) ?? base
        } else {
            let (cols, rows) = GridComposer.gridDims(images.count)
            guard let grid = GridComposer.compose(images.map { $0 as NSImage? }, size: target), let data = grid.pngData() else {
                showToast("Couldn't build the grid image.", isError: true); return
            }
            png = data
            note = "Imported \(images.count) images as a \(cols)×\(rows) grid"
        }
        let name = store.saveGeneratedImage(png, projectID: pid, creativeID: cid)
        mutateCreative(project: pid, creative: cid) {
            $0.imageFilename = name
            $0.imageIsPlaceholder = false
            $0.status = .done
            $0.errorMessage = nil
            $0.imageVersion += 1
            if $0.textLayers.isEmpty { $0.textLayers = [TextLayer.seed(from: $0)] }
        }
        showToast(note)
    }

    // MARK: Export (images + copy.csv)

    func exportAll() {
        guard screen == .results, let project = selectedProject else { return }
        let folder = settings.exportFolder()   // never nil — falls back to Desktop
        let total = project.personas.reduce(0) { $0 + $1.creatives.count }
        guard total > 0 else { showToast("Nothing to export yet."); return }
        showToast("Exporting \(total) images…")
        // Renders + encodes happen off-main inside compositedJPEG; the awaits here keep the window
        // responsive (and let the user keep working) while a large batch exports.
        Task { [weak self] in
            guard let self else { return }
            let fm = FileManager.default
            let stamp = self.exportFolderName(for: project)
            var rows = [["Persona", "Set", "Rank", "Score", "Style", "Hook", "Headline", "CTA", "Primary text", "Image file"]]
            var images: [(name: String, data: Data)] = []

            for persona in project.personas {
                for c in persona.creatives {
                    var imageName = ""
                    if let data = await self.compositedJPEG(project: project.id, creative: c.id) {
                        imageName = "\(persona.name.slug)-rank\(c.rank).jpg"
                        images.append((imageName, data))
                        self.showToast("Exporting… \(images.count)/\(total)")
                    }
                    rows.append([persona.name, persona.audience, "\(c.rank)", "\(c.score)",
                                 ImageStyleMeta.label(c.style), c.hook, c.headline, persona.copy.cta,
                                 c.primaryText, imageName])
                }
            }
            let csv = rows.map { $0.map(Self.csvEscape).joined(separator: ",") }.joined(separator: "\n")
            // Off-main: write all files in one batch.
            let count = await Task.detached { () -> Int in
                let didScope = folder.startAccessingSecurityScopedResource()
                defer { if didScope { folder.stopAccessingSecurityScopedResource() } }
                let outDir = folder.appendingPathComponent(stamp, isDirectory: true)
                try? fm.createDirectory(at: outDir, withIntermediateDirectories: true)
                for img in images { try? img.data.write(to: outDir.appendingPathComponent(img.name)) }
                try? csv.data(using: .utf8)?.write(to: outDir.appendingPathComponent("copy.csv"))
                return images.count
            }.value
            self.showToast("Exported \(count) images + copy.csv")
        }
    }

    private func exportFolderName(for project: Project) -> String {
        let fmt = DateFormatter(); fmt.dateFormat = "yyyy-MM-dd"
        return "\(project.name.slug)-\(fmt.string(from: Date()))"
    }

    private static func csvEscape(_ s: String) -> String {
        if s.contains(",") || s.contains("\"") || s.contains("\n") {
            return "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\""
        }
        return s
    }

    private func syncEngine() {
        engine.concurrency = settings.concurrency
        engine.autoRetry = settings.autoRetry
    }

    // MARK: Engine wiring

    /// Build the image provider for the current backend (nil if its API key is missing). Shared by the
    /// batch engine and one-off edits (e.g. Before/After's AI "generate Before from After").
    func imageProvider() -> ImageProvider? {
        switch settings.imageBackend {
        case .nanoBanana:
            guard settings.hasGeminiKey else { return nil }
            return NanoBananaImageProvider(apiKey: settings.effectiveGeminiKey)
        case .openAI:
            guard settings.hasOpenAIKey else { return nil }
            return OpenAIImageProvider(apiKey: settings.effectiveOpenAIKey)
        }
    }

    /// Like `imageProvider()` but for one-off edits (e.g. Before/After AI): prefer the selected
    /// backend, then fall back to whichever OTHER backend has a key — so a mismatched backend
    /// selection doesn't block a single edit when the user does have *a* working key.
    func anyImageProvider() -> ImageProvider? {
        if let p = imageProvider() { return p }
        if settings.hasGeminiKey { return NanoBananaImageProvider(apiKey: settings.effectiveGeminiKey) }
        if settings.hasOpenAIKey { return OpenAIImageProvider(apiKey: settings.effectiveOpenAIKey) }
        return nil
    }

    private func wireEngine() {
        engine.makeProvider = { [weak self] in self?.imageProvider() }
        engine.missingKeyProvider = { [weak self] in
            self?.settings.imageBackend == .nanoBanana ? "Gemini" : "OpenAI"
        }
        engine.promptFor = { [weak self] job in
            guard let self, let c = self.creative(job.creativeID, in: job.projectID) else { return nil }
            let cols = max(1, c.sampleCols), rows = max(1, c.sampleRows)
            let cells = cols * rows
            // Single-cell sample → no grid framing; just the plain scene prompt.
            guard cells > 1 else { return c.imagePrompt }
            // Redraw-the-grid mode (Cách A): the model restyles the whole sample grid in ONE request,
            // keeping the user-chosen N×M layout (2×2 / 2×3 / 3×3 — dynamic, never hardcoded). The grid
            // mandate MUST dominate the prompt: c.imagePrompt describes a single scene, so if it leads
            // the model treats the whole output as one composition and collapses the grid into one image.
            // We therefore put the layout contract first and demote the scene prompt to a per-cell note.
            // Product wording stays generic (no "mat"/"weave") so it fits whatever the references show.
            return """
            OUTPUT FORMAT — READ FIRST. Return ONE image that is a \(cols)×\(rows) grid of exactly \
            \(cells) separate panels, in the SAME rows and columns as the reference image, with the \
            same cell boundaries and gaps. This is a grid of \(cells) independent product shots, NOT a \
            single scene. Treat every panel separately.

            PER PANEL: the reference's matching cell holds its own distinct product (its own pattern, \
            colors, motif, shape and proportions). In each output panel reproduce THAT cell's product \
            exactly and pixel-faithfully — do not unify the panels, do not copy one panel's product \
            onto another, do not invent products, and do not merge, drop, reorder or add panels.

            STYLING — apply independently INSIDE EACH panel, changing only the scene, background and \
            lighting around that panel's product: \(c.imagePrompt)

            Keep the \(cols)×\(rows) grid intact. Do NOT collapse the grid into a single image.
            """
        }
        engine.targetFor = { [weak self] job in
            self?.creative(job.creativeID, in: job.projectID)?.ratio.size ?? CGSize(width: 1024, height: 1280)
        }
        engine.referencesFor = { [weak self] job in
            guard let self, let project = self.projects.first(where: { $0.id == job.projectID }) else { return [] }
            // Cách A: send the creative's CURRENT sample-grid composite as the reference, so the model
            // redraws the whole grid in one shot — keeping the chosen N×M layout and each cell's pattern.
            if let c = self.creative(job.creativeID, in: job.projectID), let fn = c.imageFilename,
               let data = try? Data(contentsOf: self.store.generatedImageURL(fn, projectID: job.projectID)) {
                return [data]
            }
            // Fallback (grid not composed yet): one random product photo.
            guard let pick = project.product.imageFilenames.randomElement(),
                  let data = try? Data(contentsOf: self.store.referenceImageURL(pick, projectID: project.id))
            else { return [] }
            return [data]
        }
        engine.onStatus = { [weak self] job, status, error in
            self?.mutateCreative(project: job.projectID, creative: job.creativeID) {
                $0.status = status
                $0.errorMessage = error
                if status == .generating { $0.attempt += 1 }
            }
            if status == .error, let error { self?.showToast(error, isError: true) }
        }
        engine.onImage = { [weak self] job, png in
            guard let self else { return }
            let name = self.store.saveGeneratedImage(png, projectID: job.projectID, creativeID: job.creativeID)
            self.mutateCreative(project: job.projectID, creative: job.creativeID) {
                $0.imageFilename = name
                $0.imageIsPlaceholder = false   // AI image replaces the sample grid
                $0.imageVersion += 1
                if $0.textLayers.isEmpty { $0.textLayers = [TextLayer.seed(from: $0)] }
            }
        }
    }

    // MARK: Image loading

    func generatedImage(for creative: Creative, in projectID: UUID) -> NSImage? {
        store.loadNSImage(creative.imageFilename, projectID: projectID)
    }
    func generatedImageURL(for creative: Creative, in projectID: UUID) -> URL? {
        creative.imageFilename.map { store.generatedImageURL($0, projectID: projectID) }
    }
}

extension TextLayer {
    /// Auto-seed a headline text block in the negative space the AI reserved (top-left).
    /// The look is driven by the user's "New project defaults" — `defaultHookStyle` picks the
    /// preset and `defaultFont` the typeface (a preset that mandates its own font wins). Read
    /// straight from UserDefaults so this stays a context-free static factory (it's called from
    /// strategy parsing where no AppSettings instance is in scope).
    static func seed(from creative: Creative) -> TextLayer {
        let defaults = UserDefaults.standard
        let style = (defaults.string(forKey: "defaultHookStyle")).flatMap(HookStyle.init(rawValue:)) ?? .normal1
        let font = defaults.string(forKey: "defaultFont") ?? "SF Pro Display"

        let text = creative.hook.isEmpty ? creative.headline : creative.hook
        var layer = TextLayer(text: CopyText.clean(text),
                              xFrac: 0.08, yFrac: 0.08, widthFrac: 0.64,
                              fontSize: 48, highlightWord: CopyText.clean(creative.highlight))
        layer.apply(style: style)
        // Premium presets (Editorial/Clean Float/Bold Block) carry a deliberate font; for the
        // plain "Normal" presets, fall back to the user's default text font.
        if style.preferredFont.isEmpty { layer.fontName = font }
        return layer
    }
}
