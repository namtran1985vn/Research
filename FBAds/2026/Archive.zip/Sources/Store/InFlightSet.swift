import Foundation

/// A set of identifiers for work currently in flight (generation / edit / rewrite / persona jobs).
/// Replaces the several ad-hoc `Set<…>` "busy" trackers on `AppStore` with one named concept whose
/// API mirrors `Set`, so existing call sites that insert / remove / test membership read unchanged.
/// Being a value type, mutating one held in an `@Published` property publishes a change just like a
/// plain `Set` did — so the spinners that observe these trackers keep updating.
struct InFlightSet<ID: Hashable> {
    private var ids: Set<ID> = []

    init() {}

    var isEmpty: Bool { ids.isEmpty }
    var count: Int { ids.count }
    func contains(_ id: ID) -> Bool { ids.contains(id) }

    mutating func insert(_ id: ID) { ids.insert(id) }
    mutating func remove(_ id: ID) { ids.remove(id) }
}

/// Identifies one cell inside a creative's grid (a before/after pair, split column, or variant tile),
/// replacing the stringly-typed `"\(creativeID):\(index)"` keys the in-flight cell trackers used to
/// build by hand — those were easy to mis-format and impossible to type-check.
struct CellRef: Hashable {
    let creative: UUID
    let index: Int
    init(_ creative: UUID, _ index: Int) {
        self.creative = creative
        self.index = index
    }
}
