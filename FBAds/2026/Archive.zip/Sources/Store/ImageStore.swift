import AppKit

/// Process-wide cache of decoded `NSImage`s keyed by file path, with off-main-thread loading.
///
/// SwiftUI evaluates a view's `body` constantly (scroll, hover, selection, every drag frame).
/// Reading `NSImage(contentsOf:)` there hits the disk on the main thread each time and is the
/// single biggest source of UI lag in this app. This cache turns repeat reads into an in-memory
/// lookup and pushes the first decode onto a background task.
///
/// Generated image files are overwritten in place on regenerate/import, so callers that rewrite
/// a path MUST call `evict(_:)` for it (see `ProjectStore.saveGeneratedImage`).
final class ImageStore {
    static let shared = ImageStore()

    private let cache = NSCache<NSString, NSImage>()   // NSCache is thread-safe

    private init() {
        cache.countLimit = 300   // plenty for a results grid + inspector; evicts oldest under pressure
    }

    /// Cache-only lookup. Returns immediately, never touches the disk. Use in synchronous paths
    /// where a miss can fall back to the bare placeholder until the async load lands.
    func cached(_ url: URL) -> NSImage? {
        cache.object(forKey: url.path as NSString)
    }

    /// Synchronous load: cache hit, or decode on the calling thread and cache. Prefer `load(_:)`
    /// from view code so the decode happens off the main thread.
    @discardableResult
    func image(at url: URL) -> NSImage? {
        if let hit = cache.object(forKey: url.path as NSString) { return hit }
        guard let img = NSImage(contentsOf: url) else { return nil }
        img.prepareForDisplay()
        cache.setObject(img, forKey: url.path as NSString)
        return img
    }

    /// Async load: returns the cached image, otherwise decodes off the main thread and caches it.
    func load(_ url: URL) async -> NSImage? {
        if let hit = cache.object(forKey: url.path as NSString) { return hit }
        let img = await Task.detached(priority: .userInitiated) { () -> NSImage? in
            guard let img = NSImage(contentsOf: url) else { return nil }
            img.prepareForDisplay()   // force the bitmap decode off the main thread
            return img
        }.value
        if let img { cache.setObject(img, forKey: url.path as NSString) }
        return img
    }

    /// Drop a path from the cache — call whenever the file at that path is overwritten.
    func evict(_ url: URL) {
        cache.removeObject(forKey: url.path as NSString)
    }
}

private extension NSImage {
    /// Force the underlying bitmap to decode now (on whatever thread we're on) so the main thread
    /// doesn't pay the decode cost on first draw. Best-effort.
    func prepareForDisplay() {
        _ = cgImage(forProposedRect: nil, context: nil, hints: nil)
    }
}
