import Foundation

/// Stores the API key in the app's PRIVATE sandbox container (Application Support), not the system
/// Keychain. Rationale: dev/ad-hoc builds are re-signed every build, so the Keychain treats each
/// build as a different app and re-prompts for the login password ("Always Allow" never sticks).
/// The container file is readable only by this sandboxed app, set to complete file protection —
/// so the key is entered once and never prompts again. (`Secrets.openAIKey` still overrides it.)
enum Keychain {
    private static var fileURL: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
            .appendingPathComponent("AdCreativeStudio", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("credentials.json")
    }

    private static func load() -> [String: String] {
        guard let data = try? Data(contentsOf: fileURL),
              let dict = try? JSONDecoder().decode([String: String].self, from: data) else { return [:] }
        return dict
    }

    static func set(_ value: String, for account: String) {
        var dict = load()
        if value.isEmpty { dict[account] = nil } else { dict[account] = value }
        if let data = try? JSONEncoder().encode(dict) {
            try? data.write(to: fileURL, options: [.atomic, .completeFileProtection])
        }
    }

    static func get(_ account: String) -> String? { load()[account] }

    enum Account {
        static let openai = "openai-api-key"
        static let gemini = "gemini-api-key"
    }
}
