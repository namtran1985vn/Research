import SwiftUI

/// The five visual states a creative's image can be in.
enum CreativeStatus: String, Codable, Hashable {
    case idle        // not generated
    case queued      // waiting in the generation queue
    case generating  // image in flight
    case done        // image ready
    case error       // generation failed

    var label: String {
        switch self {
        case .idle: return "Not generated"
        case .queued: return "Queued"
        case .generating: return "Generating"
        case .done: return "Ready"
        case .error: return "Failed"
        }
    }

    var color: Color {
        switch self {
        case .idle: return Theme.ink3
        case .queued: return Theme.queue
        case .generating: return Theme.run
        case .done: return Theme.ok
        case .error: return Theme.err
        }
    }
    var bg: Color {
        switch self {
        case .idle: return Theme.surface2
        case .queued: return Theme.queueBg
        case .generating: return Theme.runBg
        case .done: return Theme.okBg
        case .error: return Theme.errBg
        }
    }
    var line: Color {
        switch self {
        case .idle: return Theme.border
        case .queued: return Theme.queueLine
        case .generating: return Theme.runLine
        case .done: return Theme.okLine
        case .error: return Theme.errLine
        }
    }

    /// Transient states are reset to `idle` when a batch is cancelled or the app relaunches.
    var isInFlight: Bool { self == .queued || self == .generating }
    /// Whether this creative still needs an image generated.
    var needsGeneration: Bool { self == .idle || self == .error }
}
