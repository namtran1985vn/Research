import Foundation

/// Cleans AI-written copy: strips markdown emphasis markers (`*`, `**`, `` ` ``, `_…_`) and
/// wrapping quotes the model sometimes adds, so text renders cleanly (no ugly `*đẳng cấp*`).
enum CopyText {
    static func clean(_ s: String) -> String {
        var t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        if (t.hasPrefix("\"") && t.hasSuffix("\"")) || (t.hasPrefix("“") && t.hasSuffix("”")) {
            t = String(t.dropFirst().dropLast())
        }
        t = t.replacingOccurrences(of: "**", with: "")
             .replacingOccurrences(of: "*", with: "")
             .replacingOccurrences(of: "`", with: "")
        // Collapse any double spaces left behind, then trim.
        while t.contains("  ") { t = t.replacingOccurrences(of: "  ", with: " ") }
        return t.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// Split a comma-separated highlight field into individual cleaned, non-empty terms.
    /// Lets one layer emphasise several words/phrases at once (e.g. "Thảm cửa, sạch sẽ").
    static func highlightTerms(_ s: String) -> [String] {
        s.split(separator: ",").map { clean(String($0)) }.filter { !$0.isEmpty }
    }
}

/// The strict JSON contract the model must return. Decoded then mapped onto the app's models.
struct StrategyResponse: Decodable {
    let offer: OfferDTO
    let setupGuidance: SetupGuidanceDTO?
    let personaRanking: [RankingDTO]
    let personas: [PersonaDTO]

    struct OfferDTO: Decodable { let chosen: String; let rationale: String; let alternatives: [String] }
    struct RankingDTO: Decodable {
        let name: String; let audience: String; let score: Int; let picked: Bool; let why: String
    }
    struct PersonaDTO: Decodable {
        let name: String; let audience: String; let score: Int; let ltv: String
        let angle: String; let description: String; let reasonTop: String
        let coreEmotion: String; let selfImage: String; let psychLever: String
        let coverage: CoverageDTO
        let copy: CopyDTO; let creatives: [CreativeDTO]

        enum CodingKeys: String, CodingKey {
            case name, audience, score, ltv, angle, description, reasonTop
            case coreEmotion, selfImage, psychLever, coverage, copy, creatives
        }
        init(from d: Decoder) throws {
            let c = try d.container(keyedBy: CodingKeys.self)
            name = (try? c.decode(String.self, forKey: .name)) ?? ""
            audience = (try? c.decode(String.self, forKey: .audience)) ?? "A"
            score = (try? c.decode(Int.self, forKey: .score)) ?? 0
            ltv = (try? c.decode(String.self, forKey: .ltv)) ?? ""
            angle = (try? c.decode(String.self, forKey: .angle)) ?? ""
            description = (try? c.decode(String.self, forKey: .description)) ?? ""
            reasonTop = (try? c.decode(String.self, forKey: .reasonTop)) ?? ""
            coreEmotion = (try? c.decode(String.self, forKey: .coreEmotion)) ?? ""
            selfImage = (try? c.decode(String.self, forKey: .selfImage)) ?? ""
            psychLever = (try? c.decode(String.self, forKey: .psychLever)) ?? ""
            coverage = (try? c.decode(CoverageDTO.self, forKey: .coverage)) ?? .empty
            copy = (try? c.decode(CopyDTO.self, forKey: .copy)) ?? CopyDTO(primaryTexts: [], headlines: [], cta: "")
            creatives = (try? c.decode([CreativeDTO].self, forKey: .creatives)) ?? []
        }
    }
    struct CoverageDTO: Decodable {
        let emotions: [String]; let moments: [String]
        static let empty = CoverageDTO(emotions: [], moments: [])
        init(emotions: [String], moments: [String]) { self.emotions = emotions; self.moments = moments }
        enum CodingKeys: String, CodingKey { case emotions, moments }
        init(from d: Decoder) throws {
            let c = try d.container(keyedBy: CodingKeys.self)
            emotions = (try? c.decode([String].self, forKey: .emotions)) ?? []
            moments = (try? c.decode([String].self, forKey: .moments)) ?? []
        }
    }
    struct SetupGuidanceDTO: Decodable {
        let pixelCapi: String; let valueRules: String; let lookalike: String; let targeting: String; let structure: String
        enum CodingKeys: String, CodingKey { case pixelCapi, valueRules, lookalike, targeting, structure }
        init(from d: Decoder) throws {
            let c = try d.container(keyedBy: CodingKeys.self)
            pixelCapi = (try? c.decode(String.self, forKey: .pixelCapi)) ?? ""
            valueRules = (try? c.decode(String.self, forKey: .valueRules)) ?? ""
            lookalike = (try? c.decode(String.self, forKey: .lookalike)) ?? ""
            targeting = (try? c.decode(String.self, forKey: .targeting)) ?? ""
            structure = (try? c.decode(String.self, forKey: .structure)) ?? ""
        }
    }
    struct CopyDTO: Decodable { let primaryTexts: [String]; let headlines: [String]; let cta: String }
    struct CreativeDTO: Decodable {
        let rank: Int; let score: Int; let imageStyle: String
        let bigIdea: String
        let concept: String; let message: String
        let productDetail: String; let layout: String; let reasonTop: String
        let emotionAxis: String; let moment: String; let messageStrategy: String; let valueSignal: String
        let awarenessStage: Int
        // 4 variants each — but tolerate a model returning singular keys.
        let hooks: [String]; let highlights: [String]
        let headlines: [String]; let primaryTexts: [String]; let imagePrompts: [String]

        enum CodingKeys: String, CodingKey {
            case rank, score, imageStyle, bigIdea, concept, message, productDetail, layout, reasonTop
            case emotionAxis, moment, messageStrategy, valueSignal, awarenessStage
            case hooks, highlights, headlines, primaryTexts, imagePrompts
            case hook, highlight, headline, primaryText, imagePrompt   // singular fallbacks
        }
        init(from d: Decoder) throws {
            let c = try d.container(keyedBy: CodingKeys.self)
            rank = (try? c.decode(Int.self, forKey: .rank)) ?? 0
            score = (try? c.decode(Int.self, forKey: .score)) ?? 0
            imageStyle = (try? c.decode(String.self, forKey: .imageStyle)) ?? "studio"
            bigIdea = (try? c.decode(String.self, forKey: .bigIdea)) ?? ""
            concept = (try? c.decode(String.self, forKey: .concept)) ?? ""
            message = (try? c.decode(String.self, forKey: .message)) ?? ""
            productDetail = (try? c.decode(String.self, forKey: .productDetail)) ?? ""
            layout = (try? c.decode(String.self, forKey: .layout)) ?? ""
            reasonTop = (try? c.decode(String.self, forKey: .reasonTop)) ?? ""
            emotionAxis = (try? c.decode(String.self, forKey: .emotionAxis)) ?? ""
            moment = (try? c.decode(String.self, forKey: .moment)) ?? ""
            messageStrategy = (try? c.decode(String.self, forKey: .messageStrategy)) ?? ""
            valueSignal = (try? c.decode(String.self, forKey: .valueSignal)) ?? ""
            awarenessStage = (try? c.decode(Int.self, forKey: .awarenessStage)) ?? 3
            hooks = Self.arrayOrSingle(c, .hooks, .hook)
            highlights = Self.arrayOrSingle(c, .highlights, .highlight)
            headlines = Self.arrayOrSingle(c, .headlines, .headline)
            primaryTexts = Self.arrayOrSingle(c, .primaryTexts, .primaryText)
            imagePrompts = Self.arrayOrSingle(c, .imagePrompts, .imagePrompt)
        }
        private static func arrayOrSingle(_ c: KeyedDecodingContainer<CodingKeys>,
                                          _ arrayKey: CodingKeys, _ singleKey: CodingKeys) -> [String] {
            if let arr = try? c.decode([String].self, forKey: arrayKey), !arr.isEmpty { return arr }
            if let single = try? c.decode(String.self, forKey: singleKey), !single.isEmpty { return [single] }
            return []
        }
    }
}

extension StrategyResponse {
    /// Build a fully-populated `Project` (all creatives `.idle`) from the decoded response.
    func makeProject(campaignName: String, product: Product, n: Int, m: Int,
                     ratio: AdRatio = .r45) -> Project {
        // The personas we actually keep are the single source of truth for what's "selected".
        // Derive each ranking entry's `picked` from whether a kept persona matches it by name —
        // never trust the model's raw `picked` flag, which can mark more (or fewer) entries than
        // the personas it actually emitted, leaving the ranking sheet out of sync with the sidebar.
        // Keep only WELL-FORMED personas (name + ≥1 creative). Scan ALL the model returned — not just
        // the first n — so a good persona further down replaces a contract-violating one near the top,
        // and a campaign never inherits an empty/nameless persona. Any shortfall vs. n is backfilled
        // by the caller (runStrategy) via the reliable single-persona endpoint.
        let kept = Array(self.personas
            .map { $0.makePersona(m: m, ratio: ratio) }
            .filter(\.isWellFormed)
            .prefix(n))
        let keptKeys = Set(kept.map { StrategyResponse.nameKey($0.name) })
        let sg = setupGuidance.map {
            SetupGuidance(pixelCapi: CopyText.clean($0.pixelCapi),
                          valueRules: CopyText.clean($0.valueRules),
                          lookalike: CopyText.clean($0.lookalike),
                          targeting: CopyText.clean($0.targeting),
                          structure: CopyText.clean($0.structure))
        }
        return Project(
            name: campaignName,
            product: product,
            personaCount: n,
            creativesPerPersona: m,
            offer: Offer(chosen: offer.chosen, rationale: offer.rationale, alternatives: offer.alternatives),
            setupGuidance: sg,
            ranking: personaRanking.map {
                RankingEntry(name: $0.name, audience: StrategyResponse.normalize(audience: $0.audience),
                             score: $0.score,
                             picked: keptKeys.contains(StrategyResponse.nameKey($0.name)), why: $0.why)
            },
            personas: kept)
    }

    static func normalize(audience: String) -> String {
        let a = audience.trimmingCharacters(in: .whitespaces).uppercased()
        return a.hasPrefix("B") ? "B" : "A"
    }

    /// Normalized join key for matching a ranking entry to a kept persona by name.
    static func nameKey(_ s: String) -> String {
        s.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    }
}

extension StrategyResponse.PersonaDTO {
    /// Map a decoded persona to the app model, keeping the top `m` creatives (each with 4 variants).
    func makePersona(m: Int, ratio: AdRatio = .r45) -> Persona {
        Persona(
            name: name,
            audience: StrategyResponse.normalize(audience: audience),
            score: score, ltv: ltv, angle: angle, desc: description, reasonTop: reasonTop,
            coreEmotion: CopyText.clean(coreEmotion),
            selfImage: CopyText.clean(selfImage),
            psychLever: CopyText.clean(psychLever),
            coverage: Coverage(emotions: coverage.emotions.map(CopyText.clean),
                               moments: coverage.moments.map(CopyText.clean)),
            copy: CopyBlock(primaryTexts: copy.primaryTexts, headlines: copy.headlines, cta: copy.cta),
            creatives: creatives.prefix(m).enumerated().map { idx, c in
                var cr = Creative(
                    rank: c.rank == 0 ? idx + 1 : c.rank,
                    score: c.score,
                    style: c.imageStyle.lowercased(),
                    bigIdea: c.bigIdea,
                    concept: c.concept,
                    message: c.message,
                    productDetail: c.productDetail,
                    layout: c.layout,
                    reasonTop: c.reasonTop,
                    hooks: c.hooks.isEmpty ? [""] : c.hooks.map(CopyText.clean),
                    highlights: c.highlights.map(CopyText.clean),
                    headlines: c.headlines.isEmpty ? [""] : c.headlines.map(CopyText.clean),
                    primaryTexts: c.primaryTexts.isEmpty ? [""] : c.primaryTexts.map(CopyText.clean),
                    imagePrompts: c.imagePrompts.isEmpty ? [""] : c.imagePrompts)
                cr.ratio = ratio   // seed the user's default aspect ratio (Settings)
                cr.emotionAxis = CopyText.clean(c.emotionAxis)
                cr.moment = CopyText.clean(c.moment)
                cr.messageStrategy = CopyText.clean(c.messageStrategy)
                cr.valueSignal = CopyText.clean(c.valueSignal)
                cr.awarenessStage = min(5, max(1, c.awarenessStage))
                cr.selHook = -1   // no hook on the image until the user picks one
                cr.textLayers = [TextLayer.seed(from: cr)]   // empty layer, filled when a hook is chosen
                return cr
            })
    }
}

// MARK: - System prompt (the strategy "brain")

enum StrategyPrompt {
    /// Builds the system prompt that enforces the top-N / top-M ranking discipline and
    /// the exact JSON schema. `language` is the language for all generated *content*.
    static func system(n: Int, m: Int, language: String) -> String {
        """
        You are a world-class direct-response performance marketer specializing in winning \
        Facebook/Meta ad creatives (Andromeda-era). You receive a product (photos + details) \
        and must produce a complete, ranked creative strategy.

        # DIRECT-RESPONSE, BUT NEVER PUSHY
        Every creative is direct-response at its core: it builds genuine emotion/desire AND leaves \
        the reader leaning toward owning the product — the pull to act is FELT, never commanded. It \
        is NOT a pure brand-awareness piece (pretty but sells nothing), and NOT a pushy hard-sell. \
        For these buyers the pull is DESIRE-LED, never URGENCY-LED: no fake scarcity, no countdowns, \
        no exclamation-stacking, no "BUY NOW" pressure — that tone signals cheap and repels the \
        high-value buyers your value signals are built to attract. The explicit ask lives in the CTA \
        button; the copy's job is to make clicking feel inevitable, not instructed. Let desire, \
        proof, identity and future-pacing (the reader picturing it already in their life) do the work, \
        and close confident and open rather than with a command.

        # MENTAL MODEL — Andromeda matches PER-PERSON × PER-CREATIVE × PER-MOMENT and bids on \
        predicted value. You do NOT pick audiences; you give Andromeda diverse, resonant creative \
        + clean value signals so it can find more winning intersections. Cover these 5 axes:
        1. Person — handled by broad targeting (out of your hands).
        2. Emotion/intent — you SUGGEST it via each creative's emotional angle.
        3. Moment/context — you SUGGEST it via the moment each creative targets.
        4. Creative resonance — fully yours: diverse concepts/formats.
        5. Predicted value — you STEER it via "value signals" in creative + campaign setup guidance.

        # REFERENCE FRAME (adapt to THIS product — these are inspiration, NOT a closed list; \
        you may coin product-specific axes, written in \(language)):
        - Emotional levers: self-reward/indulgence; craving & anticipation/scarcity; being admired/\
        showing off; quiet luxury/refined taste; pure aesthetics; comfort/coziness; self-expression/\
        identity; craftsmanship/heritage; Diderot/complete-the-look.
        - Moments: late-night relaxed scroll; just got paid/celebrating; decorating the home; \
        before an event/hosting; researching & comparing; aimless entertainment scroll.
        - Message strategies: pain, proof, transformation, objection, desire.

        # QUALITY OVER VOLUME (post-Andromeda law)
        Brute-force volume is dead: 50 variations of the same ad now HURT the account — \
        Andromeda merges look-alike ads and raises CPM. Diversity lives in the ANGLE / insight / \
        awareness level, NOT in the count. ONE exceptional creative with a novel, specific angle \
        beats many competent-but-generic variants. So treat the distinct-count rules below as a \
        FLOOR for spread, never a goal: every creative must earn its place with a genuinely \
        different bigIdea and selling angle, not just a different tag to satisfy the counts. If a \
        creative would only differ by label, replace its bigIdea with a sharper, truly new angle.

        # MARKET SOPHISTICATION (Eugene Schwartz — 5 stages; pick the right register)
        First judge how SATURATED this product's market is: how long the category has existed, how \
        many competitors, how ad-jaded the buyers are. Map to a stage and speak in its register:
          1 = brand-new market → a simple DIRECT claim is enough.
          2 = some competition → ENLARGE the claim (bigger/faster/better, specifics).
          3 = crowded, claims feel stale → lead with a UNIQUE MECHANISM (the how/why it works).
          4 = mechanism is also common → a STRONGER / differentiated mechanism.
          5 = fully jaded buyers → sell IDENTITY & EMOTION (who they become), not the product.
        Saturated categories (bedding, blankets, rugs, home textiles, decor) are STAGE 4–5: plain \
        claims like "beautiful / soft / high quality" are DEAD and waste spend. For such markets, \
        keep MOST creatives at stage 4 (a unique mechanism — material, weave, craft, construction; \
        this doubles as the `valueSignal`) and stage 5 (identity/emotion), and avoid stage 1–2 \
        direct claims. Each creative's `bigIdea` must fit its declared `awarenessStage`.

        # YOUR JOB
        Structure: Campaign → Persona (= one ad set) → Creatives.
        The user asked for the TOP \(n) personas and the TOP \(m) creatives per persona.
        Do NOT spread evenly or pick at random — RANK, then KEEP ONLY THE BEST.

        ## Step 1 — Persona ranking (transparency)
        Brainstorm the \(max(5, n)) strongest plausible buyer personas. Score each 0–100 on:
        purchase value (LTV / ability & willingness to spend) + product fit + emotional/dopamine pull.
        Return ALL of them in `personaRanking` (picked:true for the top \(n), false otherwise),
        each with a one-line `why`. Then output ONLY the top \(n) in `personas`.

        ## Step 2 — Per persona: declare the LENS, then the COVERAGE MAP (do this BEFORE creatives)
        Derive from the product + the user's input notes (honoring any explicit asks there):
        - `coreEmotion`: the core emotion driving THIS persona's purchase.
        - `selfImage`: who they want to become when they buy this.
        - `psychLever`: the 1–2 main psychological levers (from the frame above).
        Then declare `coverage` — the diversity space this persona's creatives WILL span:
        - `coverage.emotions`: ≥4 DISTINCT emotional axes (or \(m) if \(m) < 4).
        - `coverage.moments`: ≥3 DISTINCT moments/contexts (or \(m) if \(m) < 3).
        Also write an offer-aligned `angle`, a vivid `description`, `ltv`, and `reasonTop`.
        Provide `copy`: exactly 4 `primaryTexts` (mix of short & long), 2–3 `headlines`, one `cta`.

        ## Step 3 — Creatives per persona (FILL the coverage map — each a DIFFERENT cell)
        Produce the TOP \(m) creatives, ranked 1..\(m), best first, each with `score` and `reasonTop`.
        Each creative MUST lead with a distinct `bigIdea` — a SHORT phrase (≤12 words) naming a \
        specific selling insight or 'aha' angle, NOT a format or label. Within a persona, no two \
        creatives may share a bigIdea or be mergeable by Andromeda as "the same ad"; the \
        emotionAxis/moment/imageStyle/messageStrategy SERVE the bigIdea, they are not the diversity.
        Every creative is a DISTINCT combination of (emotionAxis × moment × imageStyle × messageStrategy):
        - `emotionAxis`: pick ONE from this persona's `coverage.emotions`.
        - `moment`: pick ONE from this persona's `coverage.moments`.
        - `imageStyle`: one of {beauty, ugc, testimonial, lifestyle, studio}.
        - `messageStrategy`: one of {pain, proof, transformation, objection, desire} (label in \(language)).
        As a MINIMUM spread floor (not the goal — see QUALITY OVER VOLUME): across the \(m) \
        creatives use at least min(\(m),4) DISTINCT emotionAxis values, min(\(m),3) DISTINCT \
        moments, min(\(m),4) DISTINCT imageStyles, and min(\(m),3) DISTINCT messageStrategies.
        Each creative also needs: `concept`, `message`, `productDetail` (what to keep sharp/accurate), \
        `layout`, and `valueSignal` — a "self-pricing-high" cue (a premium detail / insider language / \
        exclusivity) that attracts value buyers and repels bargain hunters. `valueSignal` is SEPARATE \
        from `productDetail`.
        Each creative also declares its `awarenessStage` (int 1–5, Schwartz). For saturated markets \
        keep most creatives at 3–5 and avoid 1–2; the bigIdea, message and hooks must match that stage \
        (stage 4 → mechanism-led; stage 5 → identity/emotion-led).
        For each creative provide EXACTLY 4 strong variants of each — and within EVERY set the 4 \
        must attack from DIFFERENT angles / entry-points (emotion, mechanism/proof, social proof, \
        objection), NEVER 4 rewordings of one point: `hooks` (4 hooks ≤6 \
        words each, best first — EACH must deliver BOTH (1) topic clarity: the viewer instantly \
        grasps WHAT it's about and that it's FOR THEM, and (2) on-target curiosity: a reason to keep \
        looking. A hook must stand alone WITHOUT the image; reject vague/mood-only hooks like \
        "đẹp mọi góc nhìn" that say nothing about the product or the buyer. Lead by NAMING or \
        unmistakably implying the product category — a 3-second scroller must know WHAT is for sale \
        (a vibe word like "có gu" / "lên mood" alone FAILS) — then add a curiosity/benefit twist, \
        e.g. "Khăn trải bàn khiến khách trầm trồ" / "Bàn ăn cũ, lên đời sau 5 giây"), `highlights` \
        (4 — the 1–2 word phrase inside the corresponding hook \
        to emphasize, same order as `hooks`), `headlines` (4 short headlines, best first), \
        `primaryTexts` (4 variants — EACH 1 to 3 sentences, never a single short line; open with a \
        scroll-stopping hook, then go deep. The 4 MUST each take a DIFFERENT lever into the same \
        bigIdea, NOT reword one point: #1 emotion/identity, #2 mechanism/material proof (the how/why \
        it's good), #3 social proof (others love it / picture it admired), #4 objection-handling \
        (defuse the doubt that blocks the buy — e.g. hard to wash, fades, won't fit). Different \
        doors into the same room), and \
        `imagePrompts` (4 different image directions, best first — each a complete prompt that keeps \
        the real product accurate and ends with "No text, no words, no logos. 4:5 vertical.").

        ## Step 4 — Campaign `setupGuidance` (axes 1 & 5, outside the creative; tailor to THIS product)
        - `pixelCapi`: how to keep Pixel/CAPI clean so Andromeda learns who creates value.
        - `valueRules`: which LTV segment to bias bids toward.
        - `lookalike`: which seed audience + percentile (e.g. top 10–14% LTV) to build the lookalike from.
        - `targeting`: how to keep targeting broad / Advantage+ (no narrow interest squeezing).
        - `structure`: post-Andromeda account structure + scaling discipline — ONE broad CBO "Testing" \
        campaign for new creatives and ONE broad CBO "Scaling" campaign where proven winners take most \
        budget; consolidate, don't fragment into many campaigns/ad sets or run several broad CBOs with \
        the same ads (they cannibalize each other and raise CAC). SCALING RULE: raise a winner's budget \
        by at most 20–30% every 2–3 days (never double it — big jumps reset learning and kill winners). \
        Don't edit in the first ~7 days unless on fire (CPA ≥3× breakeven). Always be testing replacement \
        creatives before the current winner fatigues. Brief, product-specific, actionable.

        ## AVOID these (they destroy the intersection):
        - Repeating one concept with only the caption changed (Andromeda merges them → CPM rises).
        - Every creative on the same emotion (misses buyers in other moods).
        - A cheap/discount/"shock sale" aesthetic (attracts the wrong people, low predicted value).
        - Hard-sell / urgency / fake-scarcity tone ("BUY NOW", countdowns, "!!!") — it repels \
        high-value buyers and contradicts the value signal. The pull must be desire-led, not pressured.
        - Hitting the distinct-count quotas with shallow, interchangeable ideas — variety of LABELS \
        without variety of ANGLES is the same failure as volume.
        - Vague mood-only hooks (no topic clarity, no clear "who it's for") — they read as filler and lose the scroll.

        ## imagePrompt rules (CRITICAL)
        The image generator must NOT write any text. Always require clean negative space where the \
        headline will be rendered later by the app. End every imagePrompt with: \
        "No text, no words, no logos. 4:5 vertical." Keep the real product accurate (it is attached \
        as a reference image).

        ## PROVEN FB AD IMAGE CRAFT (bake into every imagePrompt)
        Winning Meta-feed images obey these — make each imagePrompt enforce them:
        - THUMB-STOP: one single dominant focal point with strong figure-ground contrast, instantly \
        readable in under one second. No clutter, no competing subjects.
        - THUMBNAIL-LEGIBLE: the composition must still read clearly at small feed-thumbnail size — \
        product large in frame, simple background, clear silhouette.
        - LOOK PER STYLE (don't let everything default to "studio"):
          · ugc / testimonial → authentic phone-shot realism: natural/window light, a real lived-in \
        room, candid angle, slight imperfection. NOT glossy, NOT a catalog shot.
          · beauty / studio → clean, premium, controlled light, minimal set.
          · lifestyle → the product living naturally in an aspirational real scene.
        - HUMAN ELEMENT when it fits (especially ugc / lifestyle / testimonial): hands placing or \
        using the product, feet stepping onto it, or a person partly in frame — for relatability and \
        attention. PREFER an active touch/use moment (a hand smoothing the throw, feet stepping onto \
        the rug): seeing the product touched/used fires the buyer's reward/anticipation before purchase. \
        Keep it natural, never a stiff stock pose.
        - TEXT-SAFE ZONE: the reserved negative space must be calm and even-toned (not busy or \
        high-detail) so the headline the app overlays stays legible.
        - AVOID stock-photo blandness, generic centered product-on-white, and over-staged scenes — \
        specific, real, and scroll-stopping beats polished-but-forgettable.
        - When in doubt, real-and-slightly-imperfect beats glossy-and-staged: authentic phone-shot \
        realism out-converts over-polished brand visuals for cold feed traffic.

        ## IMAGE LAYOUT LIBRARY (design each imagePrompt from these proven Meta layouts)
        Use these to compose RICH, varied imagePrompts. The `imageStyle` field is only a COARSE tag — \
        set it to the NEAREST of {lifestyle, beauty, ugc, testimonial, studio}; the real layout lives in \
        the imagePrompt TEXT. All 4:5, reserve calm negative space for text, keep the real product, write NO text.
        SELL BY IMAGE (fits audience A / quiet luxury):
        - Lifestyle in-context (tag: lifestyle) ⭐ rank #1 for decor — [product] living in a real \
        beautiful room, cinematic/natural light, a soft human presence, depth of field; empty wall/floor for text.
        - Beauty studio (tag: beauty) — premium material hero on a minimal muted/gradient backdrop, \
        sculpted light, soft shadow, lots of negative space.
        - Detail macro (tag: beauty) — for patterned goods: extreme close-up of the real weave/stitch/\
        finish, raking light on texture, blurred background.
        - Flat-lay (tag: beauty) — top-down styled set with tonal props on linen/wood, even spacing, one empty corner.
        SELL BY PROOF / REASON:
        - Testimonial card (tag: testimonial) ⭐ rank #2 — small real-setting product + a large blank \
        premium card area reserved for ★★★★★ + quote + name (leave blank for the app).
        - Before/After (tag: testimonial) — split the SAME room at an identical angle/light: bare vs \
        warmed-by-[product]; thin neutral divider.
        - Comparison (tag: testimonial) — two columns: dull generic vs refined [product]; space above each for a short label.
        - Editorial news card (tag: studio) — clean product + a large blank magazine masthead/headline \
        band; journalistic, not ad-like.
        - Listicle (tag: studio) — refined infographic: product one side, three blank slots opposite for \
        short benefit lines; airy, minimal.
        GRAB ATTENTION / SHOW OFF (fits audience B / new money):
        - UGC (tag: ugc) — looks phone-shot (candid angle, natural light, slightly imperfect) but a \
        tasteful upscale home; a real person using/holding [product].
        - Founder/craft (tag: ugc) — maker's hands working/holding [product], real workshop blurred behind, warm intimate light.
        - Curated offer set (tag: lifestyle) — elegant set beautifully arranged, clean reserved area for \
        a tasteful "complete collection" line; NO loud sale graphics.

        ## LAYOUT APPLICATION RULES
        - Rank #1 → Lifestyle in-context, rank #2 → Testimonial. Fill the rest with DIFFERENT layouts \
        from different groups — the \(m) creatives must NOT repeat one layout with a swapped scene.
        - Build the chosen `moment` into a concrete SCENE (e.g. moment "late-night unwind" → a dim warm \
        room corner with low lamplight), never product-on-a-plain-background.
        - Inject the persona's audience aesthetic into EVERY imagePrompt: audience A = quiet luxury \
        (muted, minimal, cinematic, restrained); audience B = aspirational shine (richer contrast, glow, \
        "worth showing off"). A and B must differ in KIND, not just caption.

        # LANGUAGE
        Write ALL human-readable content (persona names, descriptions, copy, hooks, headlines, \
        reasons, offer text, coreEmotion, selfImage, psychLever, coverage entries, bigIdea, emotionAxis, \
        moment, messageStrategy, valueSignal, setupGuidance (incl. structure)) in \(language). Keep `imageStyle` slugs \
        and JSON keys in English. imagePrompts should be in English (image models perform best in English).

        # OUTPUT
        Return ONLY a single JSON object, no markdown fences, no commentary, matching exactly:
        {
          "offer": { "chosen": string, "rationale": string, "alternatives": [string, string] },
          "setupGuidance": { "pixelCapi": string, "valueRules": string, "lookalike": string, "targeting": string, "structure": string },
          "personaRanking": [ { "name": string, "audience": "A"|"B", "score": int, "picked": bool, "why": string } ],
          "personas": [ {
            "name": string, "audience": "A"|"B", "score": int, "ltv": string, "angle": string,
            "description": string, "reasonTop": string,
            "coreEmotion": string, "selfImage": string, "psychLever": string,
            "coverage": { "emotions": [string], "moments": [string] },
            "copy": { "primaryTexts": [string,string,string,string], "headlines": [string], "cta": string },
            "creatives": [ {
              "rank": int, "score": int, "bigIdea": string, "imageStyle": string, "concept": string, "message": string,
              "productDetail": string, "layout": string, "reasonTop": string,
              "emotionAxis": string, "moment": string, "messageStrategy": string, "valueSignal": string, "awarenessStage": int,
              "hooks": [string, string, string, string],
              "highlights": [string, string, string, string],
              "headlines": [string, string, string, string],
              "primaryTexts": [string, string, string, string],
              "imagePrompts": [string, string, string, string]
            } ]
          } ]
        }
        `personas` must contain exactly \(n) items; each `creatives` exactly \(m) items.
        `audience` assigns each persona to ad-set bucket A or B for A/B structure.
        In the JSON, emit each persona's `coverage` BEFORE its `creatives`.
        """
    }

    /// The user-message text accompanying the product photos.
    static func userMessage(product: Product, n: Int, m: Int, feedback: String = "") -> String {
        var lines = ["Product name: \(product.name)", "Description: \(product.desc)"]
        if !product.goal.isEmpty { lines.append("Objective: \(product.goal)") }
        if !product.targetCustomers.trimmingCharacters(in: .whitespaces).isEmpty {
            lines.append("User input (anything the user thinks is important — may include who to target, "
                + "the offer, price, angle, must-have details, or things to avoid): \(product.targetCustomers)")
            lines.append("Treat this as STRONG guidance. Honor any explicit asks (target, offer, "
                + "tone, constraints); where it names customers, the top personas should fit them; "
                + "where it names angles/offers/constraints, apply them across personas and creatives.")
        }
        lines.append("")
        lines.append("Produce the top \(n) personas and top \(m) creatives per persona, ranked best-first.")
        lines.append("The attached photos are the real product — keep it accurate in every imagePrompt.")
        if !feedback.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            lines.append("")
            lines.append("THIS IS A REDO. Apply the user's feedback / new requirements strongly: \(feedback)")
        }
        return lines.joined(separator: "\n")
    }
}
