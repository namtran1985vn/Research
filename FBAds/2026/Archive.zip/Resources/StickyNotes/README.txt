Sticky-note paper assets for the "Sticky Note" hook style.

Drop 4–6 PNG files of REAL photographed/scanned sticky notes here, e.g.:
    note1.png  note2.png  note3.png  ...

Requirements for each PNG (so the result looks authentic, not fake):
  • Transparent background (alpha) — only the paper + its soft shadow are opaque.
  • A real photo or high-res scan of an actual paper note (slight wrinkles,
    curled edge, soft natural shadow). Avoid flat vector/clip-art.
  • Roughly square-ish, generous blank writing area in the center.
  • Each note shot at a slightly different angle/curl so they vary.
  • ~1024px on the long edge is plenty.

The app loads every *.png in this folder automatically (no Xcode changes
needed — this is a folder reference). It picks one deterministically per
text layer, draws it as the paper, then renders the Vietnamese handwriting
(Patrick Hand) on top. Until you add PNGs here, the style falls back to a
plain note-yellow card so the app still works.
