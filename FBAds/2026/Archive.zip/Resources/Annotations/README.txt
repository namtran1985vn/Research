Hand-drawn annotation marks for the "Annotation" hook style.
Files are looked up BY NAME, one per kind:
  underline.png  – wavy underline drawn beneath the text
  circle.png     – scribbled ellipse drawn around the text
  arrow.png      – arrow beside the text, pointing up-right at a detail
Use transparent PNGs of real hand-drawn strokes. To swap a look, replace
the matching file. The editor's "Annotation mark" picker chooses the kind.
