Craft-stamp / badge / hang-tag PNGs for the "Stamp" hook style.
Drop transparent PNGs here (stamp4.png, ...). Each should have a blank
centre for the text. The app picks one per text layer (by seed), draws
it tilted with a soft shadow, and centres the (short) text on it.
Aspect ratio is preserved (no distortion). ~1024px is plenty.
Bundled: stamp1 (red ink stamp), stamp2 (kraft badge), stamp3 (hang tag).
